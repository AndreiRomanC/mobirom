const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const apiUrl = () => new URL('api/api.php', window.location.href);
const api = async (action, params={}) => {
  if (window.location.protocol === 'file:') {
    throw new Error('Pagina este deschisă direct din Finder. Pentru date live, deschide prin http://localhost:8000/ după ce pornești serverul PHP (php -S localhost:8000).');
  }
  const url = apiUrl();
  url.searchParams.set('action', action);
  Object.entries(params).forEach(([k,v]) => url.searchParams.set(k, v));
  let res;
  try {
    res = await fetch(url.toString(), { cache: 'no-store' });
  } catch (err) {
    throw new Error('Nu pot ajunge la api/api.php. Verifică serverul PHP și testează: ' + apiUrl().toString() + '?action=diagnostics');
  }
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); }
  catch (err) {
    const preview = text.replace(/\s+/g, ' ').slice(0, 160);
    throw new Error(`API a răspuns non-JSON (${res.status}). PHP nu rulează sau a întors HTML. Preview: ${preview || 'gol'}`);
  }
  if (!res.ok || json.error) throw new Error(json.detail || json.message || json.error || 'API error');
  return json;
};

/* ---------- formatting ---------- */
const curSym = (c) => ({USD:'$',EUR:'€',GBP:'£'})[c] || '';
const isNum = (n) => !(n === null || n === undefined || Number.isNaN(Number(n)));
const fmt = (n, d=2) => !isNum(n) ? '—' : Number(n).toLocaleString('ro-RO', {maximumFractionDigits:d});
const pct = (n) => !isNum(n) ? '—' : `${Number(n).toFixed(2)}%`;
function money(n, cur='USD'){
  if (!isNum(n)) return '—';
  const v = Number(n).toLocaleString('ro-RO', {maximumFractionDigits:2});
  if (cur === 'GBp') return `${v} p`;
  const s = curSym(cur);
  return s ? `${s}${v}` : `${v} ${cur}`;
}
function compactMoney(n, cur='USD'){
  if (!isNum(n)) return '—';
  n = Number(n); const abs = Math.abs(n); const s = curSym(cur) || '';
  if (abs >= 1e12) return `${s}${(n/1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${s}${(n/1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${s}${(n/1e6).toFixed(2)}M`;
  return money(n, cur);
}
const scoreClass = (n) => n >= 62 ? 'good' : n >= 48 ? 'mid' : 'bad';
const toast = (msg) => { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'), 3000); };

/* ---------- tooltips ---------- */
const TIP = {
  price:'Ultimul preț tranzacționat al unei acțiuni.',
  marketCap:'Capitalizarea = preț × număr de acțiuni. Cât valorează toată firma la bursă. Mare = de obicei mai stabilă; mică = mai volatilă.',
  change:'Cât s-a mișcat prețul față de închiderea de ieri, în procente. E doar zgomotul unei zile — pe termen lung contează trendul și fundamentele, nu variația zilnică. O singură zi roșie nu spune nimic despre o firmă bună.',
  volume:'Numărul de acțiuni tranzacționate azi. Volum MARE confirmă o mișcare (mulți cumpărători/vânzători reali) și înseamnă lichiditate — poți intra/ieși ușor. Volum MIC = greu de vândut la preț corect, spread mai mare, risc ascuns. Reper: caută volum constant, nu sărituri izolate.',
  yield:'Dividend yield = dividend anual ÷ preț, în %. Cât primești pe an doar din dividende, indiferent de mișcarea prețului. Exemplu: 4% = ~400/an la 10.000 investiți. Reper: 2–5% sănătos, 5–8% generos (verifică sustenabilitatea), peste 9% adesea semn că prețul a căzut, nu că firma e generoasă.',
  pos52:'Unde e prețul azi între minimul și maximul ultimului an. 0% = exact la minim (ieftin relativ — dar verifică DE CE a căzut), 100% = la maxim (în forță, dar potențial scump). Cumpărarea aproape de minim cere ca firma să fie sănătoasă; cumpărarea la maxim cere convingere în creșterea viitoare.',
  quality:'Cât de bună e afacerea în sine: marja de profit și ROE din rapoartele oficiale SEC. Scor mare = firmă eficientă, cu putere de preț, care transformă veniturile în profit real. O firmă de calitate rezistă mai bine în crize și compune valoarea în timp.',
  valuation:'Cât de scump plătești pentru ce primești (profit, active, vânzări), pe baza P/E și P/B. Scor mare = evaluare atractivă (ieftin relativ). Important: o firmă scumpă (P/E mare) poate merita dacă crește rapid; una ieftină poate fi o „capcană de valoare" dacă e în declin.',
  growth:'Cât de repede cresc veniturile de la o perioadă la alta. Creșterea e motorul principal al prețului pe termen lung. Reper: caută creștere CONSTANTĂ pe mai mulți ani, nu o singură explozie. Venituri în scădere = red flag major.',
  health:'Soliditatea financiară, măsurată prin datorii ÷ capital propriu. Datorii mici = firmă rezistentă la crize și la dobânzi mari. Datorii uriașe = vulnerabilă dacă afacerea încetinește. Excepție: băncile și utilitățile au datorii mari prin natura lor.',
  momentum:'Forța trendului actual: poziția prețului față de mediile mobile (MA50/MA200), poziția în intervalul de 52 săptămâni și variația pe ~90 de zile. Momentum mare = cumpărătorii dețin controlul. Util pentru sincronizare, dar nu înlocuiește calitatea firmei.',
  dividend:'Cât de atractiv e profilul de venit pasiv, din yield-ul real (plățile ultimelor 12 luni). Scor mare = dividend consistent și generos. Verifică mereu și payout-ul: un yield mare cu payout peste 100% e nesustenabil și poate fi tăiat.',
  risk:'Penalizare care se SCADE din scorul final. Crește la: volum prea mic (lichiditate slabă), RSI extrem (mișcare exagerată pe termen scurt) sau profitabilitate negativă în ultimul raport. Cu cât mai mare, cu atât profilul risc/randament e mai prost.',
  confidence:'Cât de complete sunt datele pe care se bazează scorul. Mic = lipsesc fundamentele oficiale (tipic la REIT-uri europene și ETF-uri, unde nu există rapoarte SEC). Un scor cu confidence mic se sprijină mai mult pe preț și trend decât pe fundamente.',
  ma50:'Media prețurilor din ultimele 50 de zile — trendul pe termen SCURT. Se recalculează zilnic („alunecă"), netezind zgomotul. Preț peste MA50 = impuls pozitiv recent; sub ea = slăbiciune pe termen scurt.',
  ma200:'Media prețurilor din ultimele 200 de zile — trendul pe termen LUNG, reperul „sănătății" de fond. Când MA50 urcă peste MA200 = „golden cross" (semn bun); când coboară sub = „death cross" (semn slab).',
  rsi:'RSI(14) măsoară dacă prețul a urcat/coborât prea repede recent, pe o scară 0–100. Peste 70 = supra-cumpărat (posibil prea scump pe moment, risc de corecție); sub 30 = supra-vândut (posibil ieftin, dar poate continua să scadă). Între 30–70 = neutru.',
  score:'Scorul general 0–100: o medie ponderată a calității, evaluării, creșterii, sănătății, momentumului și dividendului, din care se scade penalizarea de risc. Mai mare = profil mai bun. E un punct de pornire pentru cercetare, NU un ordin de cumpărare.',
  revenue:'Veniturile totale (cifra de afaceri) pe ultimul an fiscal — cât a încasat firma din vânzări, înainte de orice cheltuieli. Baza de la care pornește totul; urmărește dacă cresc an de an.',
  netIncome:'Profitul net — banii rămași după TOATE cheltuielile, dobânzile și taxele. „Linia de jos" a firmei. Profit net în creștere constantă = afacere sănătoasă.',
  profitMargin:'Marja de profit = profit net ÷ venituri × 100. Cât din fiecare leu încasat rămâne profit. Exemplu: 100 venituri și 20 profit → 20%. Marjă mare și stabilă = avantaj competitiv. Reper: peste 15% foarte bun, sub 0% = pierdere.',
  roe:'ROE (Return on Equity) = profit net ÷ capitalul acționarilor × 100. Cât profit produce firma din banii proprietarilor. Reper: peste 15% e sănătos. Atenție: un ROE umflat de datorii multe nu e calitate reală — verifică și datoriile.',
  debtEquity:'Datorie financiară (credite + obligațiuni + leasinguri) ÷ capital propriu = Total Debt ÷ Equity. Arată cât de îndatorată e firma. Reper: sub 1 = conservator, 1–2 = acceptabil, peste 2 = îndatorare mare și risc ridicat la crize/dobânzi. La bănci și utilități valorile mari sunt normale.',
  revenueGrowth:'Cu cât au crescut veniturile față de perioada anterioară, în %. Crescătoare = sănătate și cerere reală. În scădere = red flag. Ideal: creștere însoțită și de creșterea profitului, nu vânzări „cumpărate" în pierdere.',
  ebitMargin:'Marjă operațională = EBIT ÷ venituri × 100. Cât profit scoate firma din activitatea de bază, înainte de dobânzi și taxe. Mai „curată" decât marja netă. Reper: peste 15% = solid.',
  netDebtEbitda:'Net Debt / EBITDA = (datorii − cash) ÷ EBITDA. De câți ani de profit operațional ar avea nevoie firma ca să-și plătească datoria netă. Reper: sub 3 = confortabil, peste 4 = datorie grea.',
  equityRatio:'Equity ratio = capital propriu ÷ total active × 100. Cât din active e finanțat din bani proprii, nu din datorii. Reper: peste 50% = solid; sub 30% = îndatorare mare.',
  assets:'Active totale = tot ce deține firma: fabrici, utilaje, stocuri, cash, brevete. Una dintre cele 3 cărămizi ale bilanțului. Active = Datorii totale + Capital propriu.',
  liabilities:'Datorii totale (obligații) = tot ce datorează firma: credite, obligațiuni, furnizori, salarii, taxe. Dacă SEC nu o raportează direct, o calculez ca Active − Capital propriu.',
  equity:'Capital propriu (equity) = ce rămâne acționarilor după ce scazi datoriile din active. Active − Datorii. Cu cât e mai mare față de active, cu atât firma e mai solidă.',
  cash:'Numerarul și echivalentele de numerar din bilanț — banii pe care firma îi are disponibili imediat. Folosit la calculul datoriei nete (Net Debt = datorii − cash).',
  ebitda:'EBITDA = profit operațional (EBIT) + amortizare. Aproximează cash-ul brut din operațiuni, înainte de dobânzi, taxe și amortizare. E numitorul din Net Debt/EBITDA.',
  netDebt:'Net Debt (datorie netă) = datorii financiare totale − cash. Datoria „reală" rămasă dacă firma și-ar folosi tot numerarul. Valoare negativă = firma are mai mult cash decât datorii.',
  totalDebt:'Total Debt (datorie financiară totală) = credite + obligațiuni + leasinguri (scurt + lung termen). NU include furnizori/salarii/taxe — alea sunt în Total Liabilities. Net Debt = Total Debt − Cash.',
  pe:'P/E (Price/Earnings) = capitalizare ÷ profit net. Tip: GAAP TTM (profit net contabil din ultimele 12 luni / ultimul an fiscal), NU adjusted sau forward. Capitalizarea e validată cu sursa de piață (Yahoo). Câți ani de profit „plătești": sub 15 = ieftin, 15–25 = normal, peste 30 = scump. Compară în același sector.',
  pb:'P/B (Price/Book) = preț ÷ valoarea contabilă. Sub 1 = plătești sub valoarea din acte. Util la bănci și REIT-uri.',
  ps:'P/S (Price/Sales) = capitalizare ÷ venituri anuale. Util când firma nu are profit încă. Mai mic = mai ieftin pe vânzări.',
  evEbitda:'EV/EBITDA = (capitalizare + datorii − cash) ÷ EBITDA. Alternativă la P/E care ține cont și de datorii și care funcționează chiar și când firma e pe pierdere. Reper general: sub ~10 = ieftin, peste ~15 = scump (depinde de sector).',
  ffo:'FFO (Funds From Operations) ≈ Profit net + Amortizare. Cea mai importantă măsură de profitabilitate la REIT-uri: corectează profitul net pentru amortizarea contabilă uriașă a imobilelor (care nu e o cheltuială reală în cash). Înlocuiește profitul net pentru decizii.',
  ffoPerShare:'FFO pe acțiune = FFO ÷ număr de acțiuni. Echivalentul EPS pentru REIT-uri. Urmărește trendul pe ani — FFO/share în creștere = REIT sănătos.',
  pFfo:'P/FFO = capitalizare ÷ FFO. Echivalentul P/E pentru REIT-uri (la REIT, P/E e înșelător din cauza amortizării). Reper: sub ~13 = ieftin, 13–18 = corect, peste ~22 = scump.',
  ffoPayout:'FFO Payout = dividend ÷ FFO pe acțiune × 100. Cât din cash-flow-ul real e plătit ca dividend. Cel mai important test de sustenabilitate a dividendului la REIT. Reper: sub 90% = confortabil, peste 100% = nesustenabil. (Payout-ul pe profit net e mereu >100% la REIT — de aceea nu se folosește.)',
  interestCoverage:'Interest Coverage = EBIT ÷ cheltuiala cu dobânda. De câte ori își acoperă firma dobânzile din profitul operațional. Important la REIT-uri (îndatorate). Reper: peste 3–4 = confortabil, sub 1,5 = risc mare.',
  fcfYield:'Free Cash Flow yield = numerar liber generat ÷ capitalizare. Peste 5% = firma produce mult cash real față de preț. (Nu se aplică bine la bănci.)',
  payout:'Payout ratio = dividend ÷ profit. Sub 60% = dividend confortabil; peste 100% = plătește mai mult decât câștigă (nesustenabil).',
  fcf:'Free Cash Flow = numerarul rămas după investiții (operating cash flow − capex). „Banii adevărați" pe care firma îi poate folosi pentru dividende, recumpărări sau reducerea datoriei.',
  pattern:'Detectez pattern-uri tehnice clasice și verific pe istoricul propriu al acțiunii ce s-a întâmplat după ~2 luni de fiecare dată când au apărut. Statistici, nu predicții — eșantion mic, trecutul nu garantează viitorul.',
  benchmark:'Compar indicatorii companiei cu mediana sectorului ei (doar companii SUA cu fundamente SEC). Un P/E mic e „ieftin" doar dacă e sub media sectorului — fiecare industrie are normalul ei.',
};
const tipPop = (()=>{ const d=document.createElement('div'); d.className='tip-pop'; document.body.appendChild(d); return d; })();
function positionTip(el){
  const r = el.getBoundingClientRect(), tw = tipPop.offsetWidth, th = tipPop.offsetHeight;
  let x = r.left + r.width/2 - tw/2, y = r.top - th - 10;
  if (y < 8) y = r.bottom + 10;
  x = Math.max(8, Math.min(window.innerWidth - tw - 8, x));
  tipPop.style.left = x+'px'; tipPop.style.top = y+'px';
}
function openTip(el){ tipPop.textContent = el.getAttribute('data-tip'); tipPop.classList.add('show'); positionTip(el); }
document.addEventListener('mouseover', e => { const el = e.target.closest('[data-tip]'); if(el) openTip(el); });
document.addEventListener('mouseout', e => { if(e.target.closest('[data-tip]')) tipPop.classList.remove('show'); });
// tap/click toggle for touch devices (no hover)
document.addEventListener('click', e => {
  const el = e.target.closest('[data-tip]');
  if (el){ e.stopPropagation(); openTip(el); }
  else tipPop.classList.remove('show');
});
const INFO_SVG = '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="6.7" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="8" cy="5.1" r="1" fill="currentColor"/><rect x="7.25" y="6.9" width="1.5" height="4.8" rx="0.75" fill="currentColor"/></svg>';
const tipIco = (key) => `<span class="tip-ico" data-tip="${(TIP[key]||'').replace(/"/g,'&quot;')}">${INFO_SVG}</span>`;
const metricTip = (label, value, key, extraClass='') => `<div class="metric"><span>${label}${tipIco(key)}</span><strong class="${extraClass}">${value}</strong></div>`;

let universe = [];
let watch = JSON.parse(localStorage.getItem('investiq_watchlist') || '[]');

/* ---------- views ---------- */
function setView(id){
  $$('.view').forEach(v => v.classList.toggle('active', v.id === id));
  $$('.nav, .bn').forEach(b => b.classList.toggle('active', b.dataset.view === id));
  window.scrollTo({top:0, behavior:'smooth'});
  if (id === 'portfolio') renderWatchView();
}
$$('.nav, .bn, .footlink').forEach(b => b.addEventListener('click', () => setView(b.dataset.view)));
/* logo -> home (prima pagină) */
$('#brandHome')?.addEventListener('click', () => { if(location.hash) location.hash=''; setView('ideas'); });

/* ---------- init ---------- */
async function init(){
  const pill = $('#statusPill');
  try {
    const s = await api('status');
    pill.textContent = `Live · ${s.universeCount} active · Yahoo + SEC`;
    pill.classList.add('ok');
  } catch(e) {
    pill.textContent = e.message.includes('Finder') ? 'Deschis local — pornește PHP' : 'API indisponibil';
    pill.classList.add('err');
  }
  try {
    const u = await api('universe');
    universe = u.data || [];
    const sectors = [...new Set(universe.map(x=>x.sector).filter(Boolean))].sort();
    $('#sectorFilter').innerHTML = '<option value="all">Toate</option>' + sectors.map(s=>`<option value="${s}">${s}</option>`).join('');
    renderWatchlist();
    renderUniverseInfo();
  } catch(e) {}
}

function renderUniverseInfo(){
  const pill = $('#uniTotalPill'), grid = $('#uniBreakdown');
  if (!universe.length) return;
  const us = universe.filter(x=>(x.country||'US')==='US').length;
  const eu = universe.length - us;
  if (pill) pill.textContent = `${universe.length} companii`;
  if (!grid) return;
  const c = {};
  universe.forEach(x=>{ const s=x.sector||'—'; c[s]=(c[s]||0)+1; });
  const items = Object.entries(c).sort((a,b)=>b[1]-a[1])
    .map(([s,n])=>`<div class="uni-cell"><b>${n}</b><span>${s}</span></div>`).join('');
  grid.innerHTML = items + `<div class="uni-cell src"><b>SUA ${us} · EU ${eu}</b><span>S&P 500 + adăugate</span></div>`;
}

/* ---------- skeleton loaders (anti-CLS: reserve the space before data arrives) ---------- */
const sk = (w,h,extra='') => `<div class="skel" style="width:${w};height:${h};${extra}"></div>`;
function ideasSkeleton(n=6){
  const card = `<div class="pick">${sk('45%','20px')}${sk('70%','13px','margin-top:9px')}${sk('100%','1px','margin:14px 0;opacity:.5')}${sk('100%','58px','border-radius:12px')}${sk('90%','38px','margin-top:12px')}${sk('100%','44px','margin-top:14px;border-radius:10px')}</div>`;
  return Array(n).fill(card).join('');
}
function companySkeleton(){
  const metrics = Array(6).fill(sk('100%','64px','border-radius:12px')).join('');
  const bars = Array(7).fill(sk('100%','16px','margin-top:14px')).join('');
  return `<div class="co-header">
    <div class="card">${sk('45%','30px')}${sk('72%','14px','margin-top:12px')}${sk('100%','58px','margin-top:18px;border-radius:12px')}<div class="metric-grid m3" style="margin-top:16px">${metrics}</div></div>
    <div class="card">${sk('55%','18px')}${bars}</div>
  </div>
  <div class="card">${sk('35%','18px')}${sk('100%','340px','margin-top:14px;border-radius:12px')}</div>`;
}

/* ---------- asset tags ---------- */
function typeTag(r){
  const t = r.assetType || '';
  if (t === 'REIT') return '<span class="tag reit">REIT</span>';
  if (t === 'ETF') return '<span class="tag etf">ETF</span>';
  return '';
}
function regionTag(r){
  const eu = r.currency && r.currency !== 'USD';
  return eu ? `<span class="tag eu">Europa</span>` : '';
}

/* ===================== IDEAS ===================== */
const GOALS = {
  opportunity:{strategy:'opportunity',sort:'score', label:'Oportunități — ieftine cu perspectivă'},
  balanced:   {strategy:'balanced',  sort:'score',  label:'Cele mai bune (scor general)'},
  dividends:  {strategy:'balanced',  sort:'yield',  label:'Dividende mari', yield:true},
  value52:    {strategy:'balanced',  sort:'low52',  label:'Ieftine — aproape de minim 52s'},
  breakout52: {strategy:'momentum',  sort:'high52', label:'În forță — aproape de maxim 52s'},
  defensive:  {strategy:'defensive', sort:'score',  label:'Defensive — stabile & solide'},
  momentum:   {strategy:'momentum',  sort:'score',  label:'Creștere — momentum puternic'},
  realestate: {strategy:'realestate',sort:'score',  label:'Imobiliare & REIT'},
};
function toggleYieldField(){ $('#yieldField').style.display = (GOALS[$('#ideaGoal').value]||{}).yield ? '' : 'none'; }
let lastIdeaRows = [];
// Build a plain-text, one-company-per-line export with ALL scanned data (Yahoo + SEC) + the app's score
function buildListText(rows, title){
  if(!rows || !rows.length) return '';
  const cm = (x,c) => isNum(x) ? compactMoney(x, c) : '—';
  const p1 = (x) => isNum(x) ? Number(x).toFixed(1)+'%' : '—';
  const x1 = (x) => isNum(x) ? Number(x).toFixed(1)+'×' : '—';
  const n2 = (x) => isNum(x) ? Number(x).toFixed(2) : '—';
  const lines = rows.map((r,i) => {
    const s = r.score || {}, v = s.verdict || {}, m = r.metrics || {};
    const cur = r.currency || m.currency || 'USD';
    const ch = isNum(r.changePct) ? `${r.changePct>=0?'+':''}${Number(r.changePct).toFixed(2)}%` : '—';
    // identity + price + app score (with component breakdown)
    const seg = [];
    seg.push(`${i+1}. ${r.symbol} | ${r.name||''} | ${r.assetType||'Stock'} | ${r.sector||'—'} | ${(r.country||'')||(cur!=='USD'?'EU':'US')}`);
    seg.push(`${money(r.price,cur)} (${ch}) · MktCap ${cm(r.marketCap,cur)}`);
    seg.push(`SCOR ${fmt(s.final,0)}/100${s.uncertain?' ⚠INCERT':''} "${v.label||'—'}" [Q${fmt(s.quality,0)} Val${fmt(s.valuation,0)} Cr${fmt(s.growth,0)} San${fmt(s.health,0)} Mom${fmt(s.momentum,0)} Div${fmt(s.dividend,0)} risc${fmt(s.riskPenalty,0)} conf${fmt(s.confidence,0)}]`);
    // valuation — P/FFO only for REITs; P/FCF for normal companies
    const isReitRow = m.isReit || r.assetType === 'REIT' || (r.sector||'').toLowerCase() === 'real estate';
    const peShown = isNum(m.pe) ? (n2(m.pe) + (m.peConflict ? `(conflict, SEC ${n2(m.peSec)})` : '')) : (m.marketLoss ? '—(pierdere TTM)' : (m.peNeg ? '—(pierdere)' : '—'));
    const valSeg = [`P/E ${peShown}`, `P/B ${n2(m.pb)}`, `P/S ${n2(m.ps)}`, `EV/EBITDA ${x1(m.evEbitda)}`];
    if (isReitRow) {
      if (isNum(m.pFfo)) valSeg.push(`P/FFO ${x1(m.pFfo)}`);
      if (isNum(m.ffoPayout)) valSeg.push(`FFOpay ${p1(m.ffoPayout)}`);
    } else if (isNum(m.pFcf)) valSeg.push(`P/FCF ${x1(m.pFcf)}`);
    valSeg.push(`FCFy ${p1(m.fcfYield)}`);
    seg.push(valSeg.join(' '));
    // fundamentals
    seg.push([`Rev ${cm(m.revenue,cur)}`, `NI ${cm(m.netIncome,cur)}`, `Marja ${p1(m.profitMargin)}`, `EBITm ${p1(m.ebitMargin)}`, `ROE ${p1(m.roe)}`, `Growth ${p1(m.revenueGrowth)}`, `FCF ${cm(m.freeCashFlow,cur)}`, `EBITDA ${cm(m.ebitda,cur)}`].join(' '));
    // balance sheet + leverage
    seg.push([`Active ${cm(m.assets,cur)}`, `Datorii ${cm(m.liabilities,cur)}`, `Equity ${cm(m.equity,cur)}`, `EqRatio ${p1(m.equityRatio)}`, `Debt ${cm(m.totalDebt,cur)}`, `NetDebt ${cm(m.netDebt,cur)}`, `D/E ${n2(m.debtEquity)}`, `NetDebt/EBITDA ${x1(m.netDebtEbitda)}`, `IntCov ${x1(m.interestCoverage)}`].join(' '));
    // technicals + income + source
    seg.push([`RSI ${fmt(m.rsi14,0)}`, `52s ${fmt(r.position52w,0)}%`, `${m.aboveMA50?'>MA50':'<MA50'}`, `${m.aboveMA200?'>MA200':'<MA200'}`, `1an ${isNum(m.momentum1y)?(m.momentum1y>=0?'+':'')+fmt(m.momentum1y,0)+'%':'—'}`, `yield ${isNum(r.dividendYield)?pct(r.dividendYield):'—'}`, `payout ${p1(m.payout)}`, `sursa ${m.fundSource||(m.fundAvailable?'?':'fără fundamente')}${m.period?' '+m.period:''}`].join(' '));
    return seg.join(' || ');
  });
  const head = `${title || 'Listă InvestIQ'} — ${rows.length} companii — ${new Date().toLocaleString('ro-RO')}`;
  const legend = 'Legendă: SCOR=scorul InvestIQ 0-100 [Q=calitate Val=evaluare Cr=creștere San=sănătate Mom=momentum Div=dividend]. Date live Yahoo Finance + SEC EDGAR.';
  return head + '\n' + legend + '\n\n' + lines.join('\n');
}
async function copyToClipboard(text, btn){
  if(!text){ toast('Nimic de copiat'); return; }
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; }
  catch(e){
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try { ok = document.execCommand('copy'); } catch(_){}
    document.body.removeChild(ta);
  }
  if(btn){ const t = btn.textContent; btn.textContent = ok ? '✓ Copiat!' : '✗ Eroare'; setTimeout(()=>btn.textContent = t, 1600); }
  toast(ok ? 'Copiat în clipboard' : 'Nu am putut copia');
}
async function findIdeas(){
  const goal = $('#ideaGoal').value, region = $('#ideaRegion').value;
  const g = GOALS[goal] || GOALS.balanced;
  const limit = $('#ideaLimit').value, minPrice = $('#ideaMinPrice').value;
  const params = {strategy:g.strategy, sort:g.sort, region, limit, minPrice, sector:'all'};
  if (g.yield) params.minYield = $('#ideaMinYield').value;
  $('#ideaMeta').textContent = g.yield ? 'Caut companii după dividend (poate dura câteva secunde la prima rulare)…' : 'Scanez și calculez scorul complet (preț, fundamente, trend)…';
  $('#ideaResults').innerHTML = ideasSkeleton(Math.min(parseInt(limit)||9, 9));
  try {
    const data = await api('screener', params);
    const rows = data.data || [];
    $('#ideaMeta').textContent = `${rows.length} idei din ${data.scanned} scanate · metodă: ${g.label} · ${regionLabel(region)} · live Yahoo Finance`;
    if (!rows.length){ $('#ideaResults').innerHTML = '<div class="card"><p class="muted">Nicio idee pentru filtrele alese. Încearcă altă metodă, altă regiune sau scade pragurile.</p></div>'; $('#copyIdeas').hidden = true; return; }
    lastIdeaRows = rows;
    $('#ideaResults').innerHTML = rows.map(r=>pickCard(r, goal)).join('');
    $$('#ideaResults .pick-btn').forEach(b => b.addEventListener('click', () => loadCompany(b.dataset.symbol)));
    $('#copyIdeas').hidden = false;
  } catch(e){
    $('#ideaMeta').textContent = e.message;
    $('#ideaResults').innerHTML = `<div class="card warning"><p>${e.message}</p></div>`;
  }
}
const regionLabel = (r) => ({all:'toate regiunile',us:'SUA',eu:'Europa'})[r] || r;

function pickCard(r, goal){
  const s = r.score || {}, v = s.verdict || {};
  const cls = scoreClass(s.final||0);
  const ch = r.changePct;
  const reasons = buildReasons(r, goal);
  let hi = '';
  if (isNum(r.dividendYield)) hi = `<span class="tag reit">${pct(r.dividendYield)} yield</span>`;
  else if ((goal==='value52'||goal==='breakout52') && isNum(r.position52w)) hi = `<span class="tag eu">${fmt(r.position52w,0)}% în 52s</span>`;
  return `<div class="pick">
    <div class="pick-top">
      <div class="pick-id">
        <div class="tk">${r.symbol}</div>
        <div class="nm">${r.name || ''}</div>
      </div>
      <div class="pick-price">
        <div class="p">${money(r.price, r.currency)}</div>
        <div class="${ch>=0?'positive':'negative'}">${pct(ch)}</div>
      </div>
    </div>
    <div class="pick-tags">
      <span class="tag">${r.sector||'—'}</span>${typeTag(r)}${regionTag(r)}${hi}
    </div>
    <div class="pick-score-row">
      <div class="bigscore s-${cls}">${fmt(s.final,0)}<small>/100</small>${s.uncertain?'<span class="unc-badge" title="Unele date-cheie sunt incerte sau lipsă">⚠ incert</span>':''}</div>
      <div class="verdict v-${v.tone||cls}">${v.label||'—'}<small>${v.text||''}</small></div>
    </div>
    <div class="pick-reasons">${reasons}</div>
    <div class="pick-actions">
      <button class="ghost pick-btn" data-symbol="${r.symbol}">Analiză detaliată →</button>
      ${goal==='watch' ? `<button class="ghost pick-rm" data-rmwatch="${r.symbol}" title="Scoate din watchlist">×</button>` : ''}
    </div>
  </div>`;
}
function buildReasons(r, goal){
  const s = r.score || {};
  const out = [];
  if (isNum(r.dividendYield) && r.dividendYield >= 3) out.push(['Dividend ~'+pct(r.dividendYield)+' pe an', false]);
  if (goal==='value52' && isNum(r.position52w)) out.push(['La doar '+fmt(r.position52w,0)+'% peste minimul de 52s', false]);
  if (goal==='breakout52' && isNum(r.position52w)) out.push(['Aproape de maximul de 52s ('+fmt(r.position52w,0)+'%)', false]);
  if ((s.momentum||0) >= 60) out.push(['Trend pozitiv (momentum '+fmt(s.momentum,0)+')', false]);
  if ((s.health||0) >= 62) out.push(['Sănătate financiară bună', false]);
  if ((s.quality||0) >= 62) out.push(['Calitate ridicată', false]);
  (s.flags||[]).slice(0,1).forEach(f => out.push([f, true]));
  if (!out.length) out.push(['Profil mediu, fără semnale puternice', false]);
  return out.slice(0,4).map(([t,bad]) => `<div class="reason${bad?' bad':''}"><span class="dot">${bad?'!':'✓'}</span><span>${t}</span></div>`).join('');
}

/* ===================== SCANNER ===================== */
async function runScan(opts={}){
  setView('scanner');
  if (opts.strategy) $('#strategyFilter').value = opts.strategy;
  $('#scanMeta').textContent = 'Scanez companiile prin mod rapid batch (Yahoo Finance)…';
  $('#scanTable tbody').innerHTML = '<tr><td colspan="10" class="empty">Se încarcă date live…</td></tr>';
  try {
    const data = await api('screener', {
      sector: $('#sectorFilter').value,
      strategy: $('#strategyFilter').value,
      region: $('#regionFilter').value,
      limit: $('#limitFilter').value,
      minPrice: $('#minPrice').value
    });
    scanRows = data.data || [];
    scanSort = {key:null, dir:-1};
    $$('#scanTable th.sortable').forEach(th=>th.classList.remove('asc','desc'));
    $('#scanMeta').textContent = `${scanRows.length} rezultate · ${data.scanned} scanate · ${data.source}`;
    renderScan(scanRows);
  } catch(e) {
    $('#scanMeta').textContent = e.message;
    $('#scanTable tbody').innerHTML = `<tr><td colspan="10" class="empty">Eroare: ${e.message}</td></tr>`;
  }
}
let scanRows = [];
let scanSort = {key:null, dir:-1};
function scanSortVal(r, key){
  if (key==='symbol') return r.symbol || '';
  if (key==='price') return Number(r.price)||0;
  if (key==='changePct') return Number(r.changePct)||0;
  if (key==='score') return Number(r.score?.final)||0;
  if (key==='risk') return Number(r.score?.riskPenalty)||0;
  return 0;
}
function applyScanSort(key){
  if (!scanRows.length) return;
  if (scanSort.key === key) scanSort.dir *= -1; else { scanSort.key = key; scanSort.dir = key==='symbol' ? 1 : -1; }
  scanRows.sort((a,b)=>{
    const va = scanSortVal(a,key), vb = scanSortVal(b,key);
    return typeof va === 'string' ? scanSort.dir*va.localeCompare(vb) : scanSort.dir*(va-vb);
  });
  $$('#scanTable th.sortable').forEach(th=>{ th.classList.remove('asc','desc'); if(th.dataset.key===key) th.classList.add(scanSort.dir>0?'asc':'desc'); });
  renderScan(scanRows);
}
function renderScan(rows){
  const cb = $('#copyScan'); if(cb) cb.hidden = !rows.length;
  if (!rows.length) { $('#scanTable tbody').innerHTML = '<tr><td colspan="10" class="empty">Nu s-au găsit rezultate.</td></tr>'; return; }
  $('#scanTable tbody').innerHTML = rows.map(r => {
    const s = r.score || {}, v = s.verdict || {};
    const cls = scoreClass(s.final || 0); const ch = r.changePct;
    return `<tr>
      <td><strong>${r.symbol}</strong></td>
      <td>${r.name || ''}</td>
      <td>${(r.assetType||'Stock')}${r.currency&&r.currency!=='USD'?' · EU':''}</td>
      <td>${r.sector || ''}</td>
      <td>${money(r.price, r.currency)}</td>
      <td class="${ch>=0?'positive':'negative'}">${pct(ch)}</td>
      <td><span class="score s-${cls}">${fmt(s.final,0)}</span></td>
      <td class="vchip v-${v.tone||cls}">${v.label||'—'}</td>
      <td>${fmt(s.riskPenalty,0)}</td>
      <td><button class="linkbtn" data-symbol="${r.symbol}">Analiză</button></td>
    </tr>`;
  }).join('');
  $$('#scanTable .linkbtn').forEach(b => b.addEventListener('click', () => loadCompany(b.dataset.symbol)));
}

/* ===================== COMPANY ===================== */
async function loadCompany(symbol){
  setView('company');
  const sym = (symbol || $('#symbolInput').value || 'AAPL').trim().toUpperCase();
  $('#symbolInput').value = sym;
  $('#companyResult').innerHTML = companySkeleton();
  try {
    const res = await api('company', {symbol: sym});
    renderCompany(res.data);
  } catch(e) {
    $('#companyResult').innerHTML = `<div class="card warning"><h2>Eroare</h2><p>${e.message}</p><p class="muted">Verifică simbolul (ex: AAPL, O, VNA.DE, SGRO.L).</p></div>`;
  }
}
function renderCompany(data){
  const q = data.quote||{}, t = data.technicals||{}, f = data.fundamentals||{}, s = data.score||{}, inc = data.income||{}, val = data.valuation||{};
  const cur = q.currency || 'USD';
  const isReit = q.assetType === 'REIT' || (q.sector||'').toLowerCase() === 'real estate';
  const v = s.verdict || {};
  const cls = scoreClass(s.final||0);
  const flags = (s.flags||[]).length ? s.flags.map(x=>`<span class="flag">${x}</span>`).join('') : '<span class="flag ok">Fără red flags majore</span>';
  const explain = (s.explain||[]).length ? s.explain.map(x=>`<div>${x}</div>`).join('') : '<div>Scorul se bazează pe preț, trend și istoric. Pentru fundamente complete e nevoie de date SEC (doar companii SUA).</div>';

  $('#companyResult').innerHTML = `
    <div class="co-header">
      <div class="card">
        <div class="co-title">
          <span class="tk">${q.symbol}</span>
          <span class="score s-${cls}" style="height:34px;min-width:54px;font-size:15px">${fmt(s.final,0)}</span>
          ${s.uncertain?'<span class="unc-badge" title="Unele date-cheie (P/E, creștere) sunt incerte sau lipsă — vezi red flags">⚠ scor incert</span>':''}
          ${typeTag(q)}${regionTag(q)}
        </div>
        <div class="co-sub">${q.name||''} · ${q.sector||''} · ${q.exchange||''} · ${q.source||''} ${q.date||''}</div>
        <div class="verdict-box">
          <div class="bigscore s-${v.tone||cls}" style="background:transparent;box-shadow:none;width:auto;font-size:17px">${v.label||'—'}</div>
        </div>
        <div class="co-sub" style="margin-top:0">${v.text||''}</div>
        <div class="metric-grid m3">
          ${metricTip('Preț', money(q.price, cur), 'price')}
          ${metricTip('Capitalizare', isNum(q.marketCap)?compactMoney(q.marketCap,cur):'—', 'marketCap')}
          ${metricTip('Variație zi', pct(q.changePct), 'change', q.changePct>=0?'positive':'negative')}
          ${metricTip('Volum', fmt(q.volume,0), 'volume')}
          ${metricTip('Dividend yield', isNum(inc.yield)?pct(inc.yield):'—', 'yield')}
          ${metricTip('Poziție 52s', pct(t.position52w), 'pos52')}
        </div>
      </div>
      <div class="card">
        <h2>Din ce e compus scorul</h2>
        <p class="muted small" style="margin:6px 0 14px">Fiecare bară (0–100) e o dimensiune a calității investiției. Scorul final le combină și scade riscul.</p>
        <div class="bars">
          ${bar('Calitate', s.quality, false, 'quality')}${bar('Evaluare', s.valuation, false, 'valuation')}${bar('Creștere', s.growth, false, 'growth')}${bar('Sănătate', s.health, false, 'health')}${bar('Momentum', s.momentum, false, 'momentum')}${bar('Dividend', s.dividend, false, 'dividend')}${bar('Penalizare risc', s.riskPenalty, true, 'risk')}
        </div>
        <div class="cap" style="margin-top:14px"><strong>Formula:</strong> Calitate 23% · Sănătate 20% · Evaluare 14% · Momentum 15% · Creștere 12% · Dividend 8% (+8% bază), minus penalizarea de risc. <b>Sănătatea & calitatea domină</b>, momentumul e secundar. Dacă sănătatea financiară e slabă, scorul e <b>plafonat</b> ca momentumul/prețul să nu mascheze riscul.</div>
        <div class="cap" style="margin-top:10px"><strong>Confidence ${fmt(s.confidence,0)}/100</strong>${tipIco('confidence')} — cât de complete sunt datele. Scade cu fiecare indicator-cheie lipsă.</div>
      </div>
    </div>

    <div class="card chart-card">
      <div class="chart-head">
        <div class="chart-tabs">
          <button class="ctab active" data-chart="price">Preț & medii</button>
          <button class="ctab" data-chart="boll">Bollinger</button>
          <button class="ctab" data-chart="macd">MACD</button>
          <button class="ctab" data-chart="vol">Volum</button>
          <button class="ctab" data-chart="rsi">RSI</button>
          <button class="ctab" data-chart="ret">Randament</button>
          <button class="ctab" data-chart="dd">Drawdown</button>
        </div>
        <div class="legend" id="chartLegend"></div>
      </div>
      <canvas id="mainChart" class="chart" height="320"></canvas>
      <div class="cap" id="chartCap"></div>
    </div>

    <div class="card">
      <div class="chart-head"><h2>Poziția în intervalul de 52 săptămâni</h2></div>
      ${range52(t, cur)}
      <div class="cap">Unde se află prețul azi între minimul și maximul ultimului an. Aproape de maxim = trend puternic dar potențial scump; aproape de minim = ieftin relativ, dar verifică de ce a scăzut.</div>
    </div>

    <div class="card">
      <div class="section-head">
        <h2>Analiză tehnică & semnale</h2>
        <button class="ghost collapse-btn" id="techToggle">Arată semnalele <span class="chev">⌄</span></button>
      </div>
      <div class="tech-body" id="techBody"><div style="padding-top:2px">${signalsHtml(data.history||[], t, q, cur)}</div></div>
    </div>

    <div class="card">
      <h2>Pattern-uri & probabilități${tipIco('pattern')}</h2>
      <p class="muted small" style="margin:6px 0 14px">Caut configurații tehnice clasice în grafic și verific, pe istoricul propriu al acțiunii, ce s-a întâmplat după ~2 luni de fiecare dată când au apărut.</p>
      ${patternHtml(data.history||[])}
    </div>

    <div class="card">
      <h2>Evaluare — cât de scumpă e acțiunea</h2>
      <p class="muted small" style="margin:6px 0 14px">Indicatorii de evaluare îți spun dacă plătești un preț corect pentru profitul, activele și vânzările firmei.</p>
      ${valuationBlock(val, cur, isReit)}
    </div>

    <div class="card">
      <h2>Cum se compară cu sectorul${tipIco('benchmark')}</h2>
      <p class="muted small" style="margin:6px 0 12px">Un indicator e relevant doar față de „colegii de breaslă". Aici compar compania cu mediana sectorului ei.</p>
      <div id="benchBody" class="bench-body">${benchSkeleton()}</div>
    </div>

    <div class="card">
      <h2>Fundamente financiare · <small style="font-weight:600;color:var(--muted);font-size:13px">sursă ${f.source||'—'}</small></h2>
      ${fundamentalBlock(f, cur, isReit, val)}
      ${aiOpinionUI(f)}
    </div>

    <div class="grid two">
      <div class="card">
        <h2>Dividend & venit pasiv</h2>
        ${incomeBlock(inc, q, cur)}
      </div>
      <div class="card">
        <h2>Indicatori tehnici</h2>
        <div class="metric-grid">
          ${metricTip('MA50', money(t.ma50, cur), 'ma50')}
          ${metricTip('MA200', money(t.ma200, cur), 'ma200')}
          ${metricTip('RSI 14', fmt(t.rsi14,1), 'rsi')}
          ${metricTip('Poziție 52s', pct(t.position52w), 'pos52')}
        </div>
      </div>
    </div>

    <div class="grid two">
      <div class="card"><h2>Red flags</h2><div class="flags" style="margin-top:6px">${flags}</div></div>
      <div class="card"><h2>Explicația scorului</h2><div class="explain" style="margin-top:6px">${explain}</div></div>
    </div>
  `;

  chartState = {hist: data.history || [], cur, tech: t};
  $$('#companyResult .ctab').forEach(b => b.addEventListener('click', () => showChart(b.dataset.chart)));
  showChart('price');
  const tt = $('#techToggle'), tb = $('#techBody');
  if (tt && tb) tt.addEventListener('click', () => {
    const open = tt.classList.toggle('open');
    tb.style.maxHeight = open ? tb.scrollHeight + 'px' : '0';
    tt.firstChild.textContent = open ? 'Ascunde semnalele ' : 'Arată semnalele ';
  });
  loadBenchmark(q.symbol, {pe:val.pe, pb:val.pb, margin:f.profitMargin, roe:f.roe});
  const aiBtn = $('#aiBtn');
  if (aiBtn) {
    const aiData = {
      symbol: q.symbol, name: q.name, sector: q.sector, currency: cur, assetType: q.assetType, isReit: isReit,
      price: q.price, marketCap: q.marketCap, changePct: q.changePct,
      dividendYield: inc.yield,
      score: {
        final: s.final, verdict: v.label, quality: s.quality, valuation: s.valuation, growth: s.growth,
        health: s.health, momentum: s.momentum, dividend: s.dividend, risk: s.riskPenalty,
        confidence: s.confidence, uncertain: s.uncertain, flags: s.flags || []
      },
      fundamentals: {
        assets: f.assets,
        liabilities: isNum(f.liabilities) ? f.liabilities : ((isNum(f.assets)&&isNum(f.equity)) ? f.assets-f.equity : null),
        equity: f.equity,
        revenue: f.revenue, netIncome: f.netIncome, profitMargin: f.profitMargin,
        ebitMargin: f.ebitMargin, ebitda: f.ebitda, roe: f.roe, debtEquity: f.debtEquity,
        totalDebt: f.totalDebt, netDebt: f.netDebt, netDebtEbitda: f.netDebtEbitda,
        equityRatio: f.equityRatio, interestCoverage: f.interestCoverage,
        revenueGrowth: f.revenueGrowth, cash: f.cash, freeCashFlow: f.freeCashFlow,
        ffo: f.ffo, period: f.period, source: f.source
      },
      valuation: {
        pe: val.pe, peFromEps: val.peFromEps, peUncertain: val.peUncertain,
        pb: val.pb, ps: val.ps, evEbitda: val.evEbitda, pFcf: val.pFcf,
        pFfo: val.pFfo, ffoPayout: val.ffoPayout, fcfYield: val.fcfYield, payout: val.payout
      },
      technicals: {
        rsi14: t.rsi14, position52w: t.position52w, aboveMA50: t.aboveMA50,
        aboveMA200: t.aboveMA200, momentum1y: t.momentum1y
      }
    };
    aiBtn.addEventListener('click', () => askAi(aiData), {once:false});
  }
  $$('#companyResult .ptab').forEach(b => b.addEventListener('click', () => {
    const pi = b.dataset.pi;
    $$('#companyResult .ptab').forEach(x => x.classList.toggle('active', x === b));
    $$('#companyResult .ppanel').forEach(x => x.classList.toggle('active', x.dataset.pi === pi));
  }));
  updateWatchBtn(q.symbol);
}
let chartState = null;
function showChart(which){
  if (!chartState) return;
  $$('#companyResult .ctab').forEach(b => b.classList.toggle('active', b.dataset.chart === which));
  const {hist, cur, tech} = chartState;
  const cap = $('#chartCap'), legend = $('#chartLegend');
  const cv = $('#mainChart');
  const L = (...items) => legend.innerHTML = items.map(([c,t])=>`<span><i style="background:${c}"></i>${t}</span>`).join('');
  if (which === 'price'){
    L(['#0d9488','Preț'],['#3b5bdb','MA50'],['#d97706','MA200']);
    drawPriceChart(cv, hist, cur); cap.innerHTML = priceCaption(tech, cur);
  } else if (which === 'boll'){
    L(['#0d9488','Preț'],['#3b5bdb','Bandă sus/jos'],['#64748b','Media 20']);
    drawBollinger(cv, hist, cur);
    cap.innerHTML = '<strong>Benzile Bollinger</strong> = media pe 20 de zile ± 2 abateri standard. Prețul atinge banda de sus = mișcare puternică/posibil scump pe termen scurt; banda de jos = posibil ieftin. Benzi înguste = liniște înainte de o mișcare mare (volatilitate scăzută).';
  } else if (which === 'macd'){
    L(['#0d9488','MACD'],['#d97706','Semnal'],['#3b5bdb','Histogramă']);
    drawMACD(cv, hist);
    cap.innerHTML = '<strong>MACD</strong> = diferența dintre media rapidă (12) și cea lentă (26), cu o linie de semnal (9). Când MACD taie semnalul în <span class="v-good">sus</span> = impuls pozitiv; în <span class="v-bad">jos</span> = impuls negativ. Histograma arată cât de puternic e momentul.';
  } else if (which === 'vol'){
    L(['#16a34a','zi în creștere'],['#e5484d','zi în scădere']);
    drawVolumeChart(cv, hist);
    cap.innerHTML = 'Câte acțiuni s-au tranzacționat zilnic. Volum mare la urcare = interes real al cumpărătorilor; volum mic = lichiditate slabă și risc mai mare.';
  } else if (which === 'rsi'){
    L(['#7c3aed','RSI (14)']);
    drawRsiChart(cv, hist);
    cap.innerHTML = 'Peste <strong>70</strong> = posibil supraevaluat pe termen scurt (risc de corecție). Sub <strong>30</strong> = posibil oversold (oportunitate, dar atenție la „falling knife").';
  } else if (which === 'ret'){
    const r = drawReturn(cv, hist);
    L(['#0d9488','Randament cumulat %']);
    cap.innerHTML = `Cât ai fi câștigat/pierdut dacă investeai la începutul perioadei și țineai până azi: <strong class="${r>=0?'v-good':'v-bad'}">${r>=0?'+':''}${fmt(r,1)}%</strong>. Linia rebază prețul la 0% în prima zi și arată evoluția procentuală.`;
  } else if (which === 'dd'){
    const mdd = drawDrawdown(cv, hist);
    L(['#e5484d','Scădere de la maxim %']);
    cap.innerHTML = `<strong>Drawdown</strong> = cât de mult a scăzut prețul față de cel mai mare nivel atins până atunci. Cea mai mare cădere din perioadă: <strong class="v-bad">${fmt(mdd,1)}%</strong>. Arată cât „durere" ai fi îndurat ținând acțiunea — important pentru a ști dacă suporți riscul.`;
  }
}
function bar(label, val=0, risk=false, tipKey=''){
  const w = Math.max(0, Math.min(100, val||0));
  const lbl = tipKey ? `${label}${tipIco(tipKey)}` : label;
  return `<div class="bar"><label>${lbl}</label><div class="track"><div class="fill${risk?' risk':''}" style="width:${w}%"></div></div><strong>${fmt(val,0)}</strong></div>`;
}
function range52(t, cur){
  const lo = t.low52w, hi = t.high52w, pos = t.position52w;
  if (!isNum(lo) || !isNum(hi)) return '<p class="muted">Date insuficiente pentru intervalul de 52 săptămâni.</p>';
  const p = Math.max(0, Math.min(100, pos||0));
  return `<div class="range52">
    <div class="track"><div class="fill" style="width:${p}%"></div><div class="marker" style="left:calc(${p}% - 2px)"></div></div>
    <div class="ends"><span>Min ${money(lo,cur)}</span><span><strong style="color:#fff">${pct(pos)}</strong> din interval</span><span>Max ${money(hi,cur)}</span></div>
  </div>`;
}
function priceCaption(t, cur){
  const above50 = t.aboveMA50, above200 = t.aboveMA200;
  let trend = 'mixt';
  if (above50 && above200) trend = '<strong>ascendent</strong> (prețul e peste ambele medii mobile)';
  else if (!above50 && !above200) trend = '<strong>descendent</strong> (prețul e sub ambele medii mobile)';
  else trend = '<strong>de tranziție</strong> (prețul e între medii)';
  const m1 = isNum(t.momentum1y) ? `, ${t.momentum1y>=0?'+':''}${fmt(t.momentum1y,1)}% pe 1 an` : '';
  return `Trend ${trend}${m1}. Când MA50 e peste MA200, e semn de impuls pozitiv pe termen mediu; invers, slăbiciune.`;
}
function valuationBlock(v, cur, isReit){
  if (!v || (v.pe===null && v.pb===null && v.ps===null && !isNum(v.pFfo))) return '<p class="muted">Indicatori de evaluare indisponibili — lipsesc fundamentele SEC (tipic la REIT-uri/ETF-uri sau firme non-SUA). Folosește dividendul și trendul.</p>';
  let note = 'Evaluare echilibrată.';
  // v.pe is now the market (Yahoo TTM) P/E when available — use it for the note.
  const peEff = v.pe;
  if (isReit && isNum(v.pFfo)){
    if (v.pFfo < 13) note = 'P/FFO scăzut → REIT <span class="v-good">ieftin</span> față de cash-flow. La REIT, P/FFO contează, nu P/E.';
    else if (v.pFfo < 18) note = 'P/FFO rezonabil → evaluare <span class="v-good">corectă</span> pentru un REIT.';
    else if (v.pFfo < 22) note = 'P/FFO ridicat → piața plătește o primă; justificat doar cu creștere a FFO.';
    else note = 'P/FFO mare → REIT <span class="v-bad">scump</span> față de cash-flow.';
  } else if (isNum(peEff)){
    if (peEff < 15) note = 'P/E scăzut → pare <span class="v-good">ieftină</span> relativ la profit. Verifică dacă nu e o „capcană de valoare" (firmă în declin).';
    else if (peEff < 25) note = 'P/E rezonabil → evaluare <span class="v-good">corectă</span> pentru o firmă sănătoasă.';
    else if (peEff < 40) note = 'P/E ridicat → piața <span class="v-mid">se așteaptă la creștere</span>. Justificat doar dacă firma chiar crește rapid.';
    else note = 'P/E foarte mare → <span class="v-bad">scumpă</span>. Orice dezamăgire poate lovi prețul tare.';
  } else if (v.peNeg){
    note = 'Firma e <span class="v-bad">pe pierdere</span>, așa că P/E nu se aplică (ar fi negativ). Pentru evaluare folosește <b>EV/EBITDA</b>, <b>P/S</b> și <b>P/B</b>, care funcționează și fără profit.';
  }
  // P/E cell: show the market (TTM) P/E; flag conflict with our SEC-computed value
  let peCell;
  if (isNum(v.pe)) {
    peCell = fmt(v.pe,1) + (v.peConflict ? ` <small style="font-weight:600;color:#b45309" title="P/E de piață (TTM). Calculul nostru din SEC (an fiscal) dă ${fmt(v.peSec,1)} — diferă (one-off / TTM vs an fiscal).">⚠ conflict</small>` : '');
  } else { peCell = v.peNeg ? `— <small style="font-weight:600;color:#b45309">${v.marketLoss?'pierdere pe TTM':'pierdere'}</small>` : '—'; }
  if (v.peConflict && isNum(v.pe)) note += ` <span class="v-mid">P/E conflict</span> — afișez P/E-ul de piață (TTM, ${fmt(v.pe,1)}); calculul din SEC (an fiscal) dă ${fmt(v.peSec,1)}. Diferența vine din an fiscal vs TTM sau elemente nerecurente.`;
  else if (v.peSecOnlyProfit) note += ` <span class="v-bad">P/E conflict</span> — datele SEC arată profit, dar piața e <b>pe pierdere pe TTM</b> (writedown recent). Folosește EV/EBITDA, P/S, P/B.`;
  // For REITs, lead with P/FFO and FFO Payout; P/E is de-emphasized
  const reitCells = isReit ? `
    ${metricTip('P/FFO', isNum(v.pFfo)?fmt(v.pFfo,1)+'×':'—', 'pFfo')}
    ${metricTip('FFO Payout', isNum(v.ffoPayout)?pct(v.ffoPayout):'—', 'ffoPayout')}` : '';
  return `<div class="metric-grid">
    ${reitCells}
    <div class="metric${isReit?' m-dim':''}"><span>P/E${tipIco('pe')}${isReit?'<small style="text-transform:none;color:#94a3b8">secundar la REIT</small>':''}</span><strong>${peCell}</strong></div>
    ${metricTip('P/B', isNum(v.pb)?fmt(v.pb,1):'—', 'pb')}
    ${metricTip('P/S', isNum(v.ps)?fmt(v.ps,1):'—', 'ps')}
    ${metricTip('EV/EBITDA', isNum(v.evEbitda)?fmt(v.evEbitda,1)+'×':'—', 'evEbitda')}
    ${metricTip('FCF yield', isNum(v.fcfYield)?pct(v.fcfYield):'—', 'fcfYield')}
    ${metricTip(isReit?'Payout (net)':'Payout', isNum(v.payout)?pct(v.payout):'—', 'payout')}
    ${metricTip('Free cash flow', isNum(v.freeCashFlow)?compactMoney(v.freeCashFlow,cur):'—', 'fcf')}
  </div><div class="cap" style="margin-top:14px">${note}</div>
  <p class="muted small" style="margin:8px 0 0">P/E, P/B, P/S sunt <b>GAAP</b>, calculate din capitalizare ÷ (profit net / equity / venituri). Capitalizarea e validată cu sursa de piață (Yahoo). Nu sunt valori „adjusted" sau „forward".</p>`;
}
/* ---------- sector benchmark ---------- */
function benchSkeleton(){
  return `<div class="bench">${[0,0,0,0].map(()=>'<div class="bench-row sk"><span class="sk-bar" style="width:70px"></span><span class="sk-bar" style="width:46px"></span><span class="sk-bar" style="width:120px"></span><span class="sk-bar" style="width:80px"></span></div>').join('')}</div><p class="muted small" style="margin:10px 0 0">Se compară cu sectorul…</p>`;
}
function renderBench(b, own){
  if (!b || !b.available) return `<p class="muted">${(b&&b.reason)||'Comparație pe sector indisponibilă'}${b&&b.sector?' · sector: '+b.sector:''}. (Disponibilă doar pentru companii SUA cu fundamente SEC.)</p>`;
  const m = b.median;
  const row = (label, key, ownVal, lowerBetter, fmtFn) => {
    const med = m[key];
    if (!isNum(ownVal) || !isNum(med)) return '';
    const inline = Math.abs(ownVal - med) / Math.max(Math.abs(med), 1e-9) < 0.03;
    const better = lowerBetter ? ownVal < med : ownVal > med;
    const tone = inline ? 'v-mid' : (better ? 'v-good' : 'v-bad');
    const word = inline ? 'în linie cu media' : (lowerBetter ? (ownVal < med ? 'mai ieftin' : 'mai scump') : (ownVal > med ? 'peste medie' : 'sub medie'));
    return `<div class="bench-row"><span class="bl">${label}</span><b>${fmtFn(ownVal)}</b><span class="bm">vs ${fmtFn(med)} sector</span><span class="bv ${tone}">${word}</span></div>`;
  };
  const rows = [
    row('P/E','pe',own.pe,true,v=>fmt(v,1)),
    row('P/B','pb',own.pb,true,v=>fmt(v,1)),
    row('Marjă profit','margin',own.margin,false,v=>pct(v)),
    row('ROE','roe',own.roe,false,v=>pct(v)),
  ].filter(Boolean).join('');
  return `<p class="muted small" style="margin:0 0 12px">Median pe <strong>${b.count}</strong> companii din sectorul <strong>${b.sector}</strong>.</p><div class="bench">${rows||'<p class="muted">Date insuficiente pentru comparație.</p>'}</div>`;
}
async function loadBenchmark(symbol, own){
  const el = $('#benchBody');
  if (!el) return;
  try {
    const res = await api('benchmark', {symbol});
    if ($('#benchBody') === el) el.innerHTML = renderBench(res.data, own);
  } catch(e) {
    if ($('#benchBody') === el) el.innerHTML = `<p class="muted">Nu am putut calcula comparația pe sector.</p>`;
  }
}
function lastCross(a, b){
  let res = null;
  for (let i=1;i<a.length;i++){
    if(!isNum(a[i])||!isNum(b[i])||!isNum(a[i-1])||!isNum(b[i-1])) continue;
    const d0=a[i-1]-b[i-1], d1=a[i]-b[i];
    if (d0<=0 && d1>0) res={idx:i, dir:'up'};
    else if (d0>=0 && d1<0) res={idx:i, dir:'down'};
  }
  return res;
}
function signalsHtml(history, t, q, cur){
  const valid = history.filter(r=>isNum(Number(r.close)));
  const closes = valid.map(r=>Number(r.close));
  const dates = valid.map(r=>r.date);
  const n = closes.length;
  if (n < 60) return '<p class="muted">Istoric insuficient pentru semnale tehnice fiabile.</p>';
  const ma50 = maSeries(closes,50), ma200 = maSeries(closes,200), rsi = rsiSeries(closes);
  const last = closes[n-1], sig = [];
  const c = lastCross(ma50, ma200);
  if (c){
    const ago = n-1-c.idx;
    if (c.dir==='up') sig.push(['good','🟢','Golden cross — MA50 a urcat peste MA200',`Semnal clasic de trend ascendent, apărut acum ~${ago} zile (${dates[c.idx]||''}). Sugerează putere pe termen mediu.`]);
    else sig.push(['bad','🔴','Death cross — MA50 a coborât sub MA200',`Semnal de slăbiciune, apărut acum ~${ago} zile (${dates[c.idx]||''}). Trendul s-a deteriorat.`]);
  } else if (isNum(ma50[n-1]) && isNum(ma200[n-1])) {
    sig.push(['mid','⚪','Fără intersecție recentă MA50/MA200', ma50[n-1]>ma200[n-1] ? 'MA50 e peste MA200 — trend pe termen lung încă pozitiv.' : 'MA50 e sub MA200 — trend pe termen lung încă slab.']);
  }
  const a50 = isNum(ma50[n-1]) && last>ma50[n-1], a200 = isNum(ma200[n-1]) && last>ma200[n-1];
  if (a50 && a200) sig.push(['good','📈','Preț peste ambele medii mobile','Cumpărătorii dețin controlul pe termen scurt și lung — trend sănătos.']);
  else if (!a50 && !a200) sig.push(['bad','📉','Preț sub ambele medii mobile','Slăbiciune pe toate orizonturile. Prudență — nu „prinde cuțitul care cade".']);
  else sig.push(['mid','〰️','Preț între medii mobile','Zonă de tranziție/indecizie. Așteaptă confirmarea direcției.']);
  const r = rsi[n-1];
  if (isNum(r)){
    if (r>=70) sig.push(['bad','🔥',`RSI ridicat (${r.toFixed(0)})`,'Supra-cumpărat pe termen scurt — risc crescut de corecție. Poate merită să aștepți o răcire.']);
    else if (r<=30) sig.push(['good','❄️',`RSI scăzut (${r.toFixed(0)})`,'Supra-vândut — posibilă oportunitate dacă fundamentele sunt bune (dar poate continua să scadă).']);
    else sig.push(['mid','✅',`RSI neutru (${r.toFixed(0)})`,'Fără extreme — nici prea scump, nici prea ieftin pe termen scurt.']);
  }
  if (isNum(t.position52w)){
    const p = t.position52w;
    if (p>=85) sig.push(['mid','🚀',`Aproape de maximul de 52s (${p.toFixed(0)}%)`,'În forță, dar potențial scump. Cumpărarea la maxim cere convingere în creșterea viitoare.']);
    else if (p<=15) sig.push(['mid','🏷️',`Aproape de minimul de 52s (${p.toFixed(0)}%)`,'Ieftin relativ. Oportunitate DOAR dacă înțelegi de ce a scăzut și firma e sănătoasă.']);
  }
  const rows = sig.map(([tone,ic,title,text])=>`<div class="signal ${tone}"><div class="ic">${ic}</div><div class="tx"><strong>${title}</strong><span>${text}</span></div></div>`).join('');
  const levels = `<div class="levels">
    ${metricTip('Suport (min 52s)', money(t.low52w,cur),'pos52')}
    ${metricTip('Rezistență (max 52s)', money(t.high52w,cur),'pos52')}
    ${metricTip('MA50', money(t.ma50,cur),'ma50')}
    ${metricTip('MA200', money(t.ma200,cur),'ma200')}
  </div>`;
  return `<div class="signals">${rows}</div>${levels}<div class="cap" style="margin-top:14px">Intersecțiile de linii (cross-urile) sunt semnale de posibilă schimbare de trend, nu garanții. Combină-le mereu cu fundamentele și cu verdictul de sus.</div>`;
}
/* ---------- pattern detection + backtest on the stock's own history ---------- */
function crossUpIdx(a,b){ const o=[]; for(let i=1;i<a.length;i++){ if(isNum(a[i])&&isNum(b[i])&&isNum(a[i-1])&&isNum(b[i-1])&&a[i-1]<=b[i-1]&&a[i]>b[i]) o.push(i);} return o; }
function crossDownIdx(a,b){ const o=[]; for(let i=1;i<a.length;i++){ if(isNum(a[i])&&isNum(b[i])&&isNum(a[i-1])&&isNum(b[i-1])&&a[i-1]>=b[i-1]&&a[i]<b[i]) o.push(i);} return o; }
function crossLevelUp(arr,lvl){ const o=[]; for(let i=1;i<arr.length;i++){ if(isNum(arr[i])&&isNum(arr[i-1])&&arr[i-1]<=lvl&&arr[i]>lvl) o.push(i);} return o; }
function breakoutIdx(closes,win){ const o=[]; for(let i=win;i<closes.length;i++){ let mx=-Infinity; for(let j=i-win;j<i;j++) mx=Math.max(mx,closes[j]); if(closes[i]>mx) o.push(i);} return o; }
function backtest(closes, idxs, h){
  let wins=0,n=0,sum=0;
  for(const i of idxs){ if(i+h<closes.length){ const r=closes[i+h]/closes[i]-1; sum+=r; if(r>0)wins++; n++; } }
  return n? {n, winRate:wins/n*100, avg:sum/n*100} : null;
}
function patternAnalysis(history){
  const valid=history.filter(r=>isNum(Number(r.close)));
  const closes=valid.map(r=>Number(r.close)), n=closes.length;
  if(n<150) return null;
  const ma50=maSeries(closes,50), ma200=maSeries(closes,200), rsi=rsiSeries(closes);
  const e12=emaSeries(closes,12), e26=emaSeries(closes,26);
  const macd=closes.map((_,i)=>(isNum(e12[i])&&isNum(e26[i]))?e12[i]-e26[i]:null);
  const sig=new Array(n).fill(null); let prev=null,cnt=0,acc=0; const k=2/10;
  for(let i=0;i<n;i++){ if(!isNum(macd[i]))continue; if(prev===null){acc+=macd[i];cnt++; if(cnt===9){prev=acc/9;sig[i]=prev;}} else {prev=macd[i]*k+prev*(1-k);sig[i]=prev;} }
  const H=42; // ~2 luni de tranzacționare
  const defs=[
    {key:'golden', short:'Golden cross', name:'Golden cross (MA50 ↑ peste MA200)', bull:true, idx:crossUpIdx(ma50,ma200), recent:6},
    {key:'macd', short:'MACD bullish', name:'MACD bullish cross', bull:true, idx:crossUpIdx(macd,sig), recent:4},
    {key:'rsi', short:'RSI rebound', name:'Revenire din supra-vândut (RSI ↑ peste 30)', bull:true, idx:crossLevelUp(rsi,30), recent:4},
    {key:'breakout', short:'Breakout 60z', name:'Breakout peste maximul ultimelor 60 zile', bull:true, idx:breakoutIdx(closes,60), recent:2},
    {key:'death', short:'Death cross', name:'Death cross (MA50 ↓ sub MA200)', bull:false, idx:crossDownIdx(ma50,ma200), recent:6},
  ];
  const out=[];
  for(const d of defs){
    const bt=backtest(closes,d.idx,H);
    if(!bt||bt.n<3) continue;
    const last=d.idx.length?d.idx[d.idx.length-1]:-1;
    const active=last>=0 && last>=n-d.recent;
    out.push({...d, ...bt, active});
  }
  const activeBull=out.filter(p=>p.active&&p.bull);
  const combined=activeBull.length? {
    names:activeBull.map(p=>p.name),
    winRate:activeBull.reduce((a,p)=>a+p.winRate,0)/activeBull.length,
    avg:activeBull.reduce((a,p)=>a+p.avg,0)/activeBull.length
  }:null;
  out.sort((a,b)=>(b.active-a.active)||(b.winRate-a.winRate));
  return {patterns:out, horizon:H, combined};
}
const PATTERN_DETAIL = {
  golden: {
    what:'„Golden cross" apare când media mobilă pe <strong>50 de zile</strong> (trendul pe termen scurt) urcă peste media pe <strong>200 de zile</strong> (trendul de fond). E unul dintre cele mai urmărite semnale de început de trend ascendent pe termen mediu.',
    calc:'Se compară zilnic MA50 cu MA200. Momentul exact în care MA50 trece de sub la peste MA200 = golden cross.',
    read:'Arată că impulsul recent a devenit mai puternic decât trendul de fond — adesea începutul unei mișcări mai lungi în sus. Mulți investitori urmăresc acest semnal, ceea ce îi poate amplifica efectul.',
    caveat:'E un semnal „întârziat" — se confirmă abia după ce mișcarea a început. În piețe laterale (fără direcție clară) poate da semnale false.'
  },
  macd: {
    what:'MACD măsoară impulsul prețului. „Bullish cross" = linia MACD urcă peste linia ei de semnal, indicând că momentul pe termen scurt trece în pozitiv.',
    calc:'MACD = media exponențială pe 12 zile − cea pe 26 zile. Linia de semnal = media pe 9 zile a MACD. Semnalul apare când MACD taie linia de semnal de jos în sus.',
    read:'Sugerează că presiunea de cumpărare crește. Cu cât crossul are loc mai jos (după o scădere), cu atât semnalul de revenire e considerat mai puternic.',
    caveat:'Foarte sensibil — generează multe semnale, unele false, mai ales pe acțiuni volatile. Cel mai bine se folosește alături de trend (ex: doar crossurile în direcția trendului principal).'
  },
  rsi: {
    what:'RSI revine peste 30 după ce fusese în zona de „supra-vândut" (sub 30). Semnalează că o scădere puternică s-a epuizat și cumpărătorii revin.',
    calc:'RSI(14) = 100 − 100 ÷ (1 + media câștigurilor/media pierderilor pe 14 zile). Semnalul apare exact când RSI trece de sub la peste pragul de 30.',
    read:'Adesea urmează un rebound tehnic pe termen scurt. E un semnal de tip „contrarian" — cumperi când ceilalți au vândut în panică.',
    caveat:'Riscul de „cuțit care cade": dacă firma are probleme reale, oversold-ul poate continua mult. Verifică întotdeauna fundamentele înainte.'
  },
  breakout: {
    what:'Prețul depășește cel mai mare nivel din ultimele 60 de zile. „Breakout-ul" arată putere și posibila continuare a trendului, pe măsură ce dispare rezistența de sus.',
    calc:'Se ia maximul prețurilor de închidere din ultimele 60 de zile; semnalul apare în ziua în care prețul închide peste acel maxim.',
    read:'Un breakout pe volum mare e mai credibil (cumpărători reali). Strategia „momentum" se bazează exact pe ideea că ce e puternic tinde să rămână puternic o vreme.',
    caveat:'Există „false breakouts" — prețul depășește scurt maximul, apoi recade. Confirmarea (câteva zile peste nivel, volum bun) reduce riscul.'
  },
  death: {
    what:'Opusul golden cross: MA50 coboară sub MA200. Semnal clasic de slăbiciune și posibil început de trend descendent pe termen mediu.',
    calc:'Momentul în care MA50 trece de sus la sub MA200.',
    read:'Istoric, e des urmat de performanță slabă. Mulți îl folosesc ca semnal de prudență / reducere a expunerii, nu neapărat de vânzare totală.',
    caveat:'Tot un semnal întârziat. Uneori apare fix la finalul scăderii, exact înainte de revenire („shakeout"). Nu-l lua izolat.'
  },
};
function patternHtml(history){
  const pa=patternAnalysis(history);
  if(!pa||!pa.patterns.length) return '<p class="muted">Istoric insuficient pentru backtest de pattern-uri (e nevoie de mai mult de ~1 an de date).</p>';
  const wr=v=>v>=55?'v-good':v>=45?'v-mid':'v-bad';
  let head;
  if(pa.combined){
    const c=pa.combined;
    // Grade the setup by its own historical hit-rate — don't oversell a weak/mixed track record as strongly bullish
    const strong = c.winRate>=58 && c.avg>=2;
    const weak = c.winRate<48 || c.avg<1;
    const tone = strong?'good':(weak?'bad':'mid');
    const badge = strong?'SETUP BULLISH ACTIV':(weak?'SETUP ACTIV · ISTORIC SLAB':'SETUP ACTIV · ISTORIC MIXT');
    const lead = strong?'' : (weak?'<b>Atenție:</b> deși pattern-ul e activ, istoricul lui pe această acțiune e <b>slab/mixat</b> — nu te baza doar pe el. ':'Pattern activ, dar cu istoric <b>mixt</b> — folosește-l ca semnal secundar. ');
    head=`<div class="setup-now setup-${tone}">
      <div class="setup-badge">${badge}</div>
      <div class="setup-tx"><strong>${c.names.join(' + ')}</strong>
      <div>${lead}Istoric: când au apărut aceste pattern-uri la această acțiune, peste ~2 luni prețul a fost mai sus în <b class="${wr(c.winRate)}">${fmt(c.winRate,0)}%</b> din cazuri, randament mediu <b class="${c.avg>=0?'v-good':'v-bad'}">${c.avg>=0?'+':''}${fmt(c.avg,1)}%</b>.</div></div>
    </div>`;
  } else {
    head=`<p class="muted small" style="margin-top:4px">Niciun pattern „bullish" activ chiar acum. Alege un pattern din tab-uri ca să vezi în detaliu cum s-a comportat istoric la această acțiune.</p>`;
  }
  const tabs = pa.patterns.map((p,i)=>`<button class="ptab ${i===0?'active':''}" data-pi="${i}"><span class="pat-dot ${p.bull?'bull':'bear'}"></span>${p.short}${p.active?'<span class="ptab-now">ACTIV</span>':''}</button>`).join('');
  const panels = pa.patterns.map((p,i)=>{
    const d = PATTERN_DETAIL[p.key] || {};
    const verdictTxt = p.winRate>=60 ? `La <strong>această</strong> acțiune pattern-ul a funcționat <span class="v-good">bine</span> istoric.` : (p.winRate>=45 ? `La această acțiune rezultatele au fost <span class="v-mid">mixte</span>.` : `La această acțiune pattern-ul <span class="v-bad">nu</span> a funcționat bine istoric — prudență.`);
    return `<div class="ppanel ${i===0?'active':''}" data-pi="${i}">
      <div class="ppanel-head"><span class="pat-dot ${p.bull?'bull':'bear'}"></span><strong>${p.name}</strong>${p.active?'<span class="pat-now">ACTIV ACUM</span>':'<span class="pat-off">inactiv acum</span>'}</div>
      <div class="pat-stats">
        <div><span>Apariții în 2 ani</span><b>${p.n}</b></div>
        <div><span>Mai sus după ~2 luni</span><b class="${wr(p.winRate)}">${fmt(p.winRate,0)}%</b></div>
        <div><span>Randament mediu</span><b class="${p.avg>=0?'v-good':'v-bad'}">${p.avg>=0?'+':''}${fmt(p.avg,1)}%</b></div>
      </div>
      <div class="pdetail">
        <p><b>Ce este:</b> ${d.what||''}</p>
        <p><b>Cum se calculează:</b> ${d.calc||''}</p>
        <p><b>Cum îl citești:</b> ${d.read||''}</p>
        <div class="formula"><b>Ce spune statistica de mai sus:</b> din ultimii ~2 ani, acest pattern a apărut de <strong>${p.n}</strong> ori la această acțiune. După ~2 luni, prețul era mai sus în <strong class="${wr(p.winRate)}">${fmt(p.winRate,0)}%</strong> din cazuri, cu un randament mediu de <strong class="${p.avg>=0?'v-good':'v-bad'}">${p.avg>=0?'+':''}${fmt(p.avg,1)}%</strong>. ${verdictTxt}</div>
        <p class="when"><b>⚠ Atenție:</b> ${d.caveat||''} ${p.n<6?'<strong>Eșantion mic ('+p.n+' apariții)</strong> → statistica e doar orientativă.':''}</p>
      </div>
    </div>`;
  }).join('');
  return `${head}
    <div class="ptabs">${tabs}</div>
    <div class="ppanels">${panels}</div>
    <div class="cap" style="margin-top:14px;border-left-color:var(--warn)"><strong>Reamintire:</strong> sunt statistici pe <strong>istoricul propriu</strong> al acțiunii (~2 ani), NU predicții și fără garanții — un reper despre cum a reacționat prețul în trecut la aceleași configurații.</div>`;
}
function fundamentalBlock(f, cur, isReit, val){
  if (!f || !f.available) return `<p class="muted">Fundamente indisponibile (nici SEC, nici Yahoo).</p><p class="muted small">Motiv: ${f?.reason || 'CIK lipsă / companie non-SUA'}. Tipic la ETF-uri sau simboluri pe care Yahoo nu le acoperă — folosește dividendul și trendul.</p>`;
  val = val || {};
  // Liabilities: use SEC value, or derive from Assets − Equity when missing
  let liabilities = isNum(f.liabilities) ? f.liabilities : null;
  let liabDerived = false;
  if (liabilities === null && isNum(f.assets) && isNum(f.equity)) { liabilities = f.assets - f.equity; liabDerived = true; }
  // Homogeneous bilingual labels: English term + small Romanian translation underneath.
  // cat = subtle color category: 'bs' (bilanț), 'prof' (profitabilitate), 'debt' (datorie/lichiditate), 'reit' (FFO). dim = de-emphasized.
  const fcur = f.currency || cur;
  const fm = (en, ro, value, key, cat, dim) => `<div class="metric m-${cat}${dim?' m-dim':''}"><span>${en}${key?tipIco(key):''}<small>${ro}</small></span><strong>${value}</strong></div>`;
  // REIT-specific FFO block (FFO replaces EPS/P-E; Net Income & ROE are de-emphasized below)
  const reitBlock = isReit ? `
    ${fm('FFO', 'funds from operations', compactMoney(f.ffo, fcur), 'ffo', 'reit')}
    ${fm('FFO / share', 'FFO pe acțiune', isNum(f.ffoPerShare)?money(f.ffoPerShare,fcur):'—', 'ffoPerShare', 'reit')}
    ${fm('P/FFO', 'preț ÷ FFO (≈ P/E)', isNum(val.pFfo)?fmt(val.pFfo,1)+'×':'—', 'pFfo', 'reit')}
    ${fm('FFO Payout', 'dividend ÷ FFO', isNum(val.ffoPayout)?pct(val.ffoPayout):'—', 'ffoPayout', 'reit')}
    ${fm('Interest Coverage', 'acoperirea dobânzii', isNum(f.interestCoverage)?fmt(f.interestCoverage,1)+'×':'—', 'interestCoverage', 'reit')}` : '';
  const reitNote = isReit ? `<p class="reit-note">🏢 <b>REIT</b> — la fonduri imobiliare, <b>FFO / P/FFO / FFO Payout</b> sunt indicatorii care contează; <b>P/E, ROE și Profitul net</b> (mai pal mai jos) sunt distorsionate de amortizarea contabilă a imobilelor și rămân secundare. <span class="muted">Indicatori operaționali precum gradul de ocupare (occupancy), WALT sau rating-ul de credit nu sunt în rapoartele financiare standard — îi verifici în prezentările companiei.</span></p>` : '';
  const legend = `<div class="fund-legend">
    ${isReit?'<span class="m-reit">Indicatori REIT (FFO)</span>':''}
    <span class="m-bs">Structură bilanț</span>
    <span class="m-prof">Profitabilitate & creștere</span>
    <span class="m-debt">Datorie & lichiditate</span>
  </div>`;
  return `${reitNote}${legend}<div class="metric-grid fund">
    ${reitBlock}
    ${fm('Total Assets', 'active totale', compactMoney(f.assets, fcur), 'assets', 'bs')}
    ${fm('Total Liabilities'+(liabDerived?' *':''), 'datorii totale', compactMoney(liabilities, fcur), 'liabilities', 'bs')}
    ${fm('Equity', 'capital propriu', compactMoney(f.equity, fcur), 'equity', 'bs')}
    ${fm('Equity Ratio', 'rata capitalului propriu', pct(f.equityRatio), 'equityRatio', 'bs')}
    ${fm('Revenue', 'venituri', compactMoney(f.revenue, fcur), 'revenue', 'prof')}
    ${fm('Net Income', 'profit net', compactMoney(f.netIncome, fcur), 'netIncome', 'prof', isReit)}
    ${fm('Profit Margin', 'marjă de profit', pct(f.profitMargin), 'profitMargin', 'prof', isReit)}
    ${fm('EBIT Margin', 'marjă operațională', pct(f.ebitMargin), 'ebitMargin', 'prof')}
    ${fm('EBITDA', 'profit op. + amortizare', compactMoney(f.ebitda, fcur), 'ebitda', 'prof')}
    ${fm('ROE', 'randamentul capitalului', pct(f.roe), 'roe', 'prof', isReit)}
    ${fm('Revenue Growth', 'creșterea veniturilor', (isNum(f.revenueGrowth)&&Math.abs(f.revenueGrowth)>150)?(pct(f.revenueGrowth)+' <small style="color:#b45309">one-off</small>'):pct(f.revenueGrowth), 'revenueGrowth', 'prof')}
    ${fm('Free Cash Flow', 'flux liber de numerar', compactMoney(f.freeCashFlow, fcur), 'fcf', 'prof')}
    ${fm('Cash', 'numerar', compactMoney(f.cash, fcur), 'cash', 'debt')}
    ${fm('Total Debt', 'datorie financiară', compactMoney(f.totalDebt, fcur), 'totalDebt', 'debt')}
    ${fm('Net Debt', 'datorie netă', compactMoney(f.netDebt, fcur), 'netDebt', 'debt')}
    ${fm('Debt / Equity', 'datorii ÷ capital', fmt(f.debtEquity,2), 'debtEquity', 'debt')}
    ${fm('Net Debt / EBITDA', 'grad de îndatorare', isNum(f.netDebtEbitda)?fmt(f.netDebtEbitda,1)+'×':'—', 'netDebtEbitda', 'debt')}
  </div><p class="muted small" style="margin-top:12px">Sursă: ${f.source}${f.cik?', CIK '+f.cik:''} · Perioadă: ${f.period||'—'}${f.currency?' · '+f.currency:''}. ${f.source==='Yahoo Finance'?'Fallback Yahoo (TTM) — bilanțul detaliat (active/datorii) nu e disponibil acolo.':'Extrase automat din XBRL — verifică manual înainte de decizii.'}${liabDerived?' <b>*</b> Total Liabilities calculat ca Total Assets − Equity (nu raportat direct).':''}</p>`;
}
function aiOpinionUI(f){
  if (!f || !f.available) return '';
  return `<div class="ai-box">
    <button class="ai-btn" id="aiBtn"><span class="ai-ico">🤖</span> Întreabă AI: verifică datele & recomandare</button>
    <p class="muted small" style="margin:8px 0 0">Trimite toate datele firmei (bilanț, evaluare, tehnic, scor) către un model AI care <b>verifică dacă cifrele par corecte</b> și spune dacă ar <b>cumpăra, aștepta sau evita</b>. Opinie educativă, nu sfat de investiție.</p>
    <div id="aiResult" class="ai-result" hidden></div>
  </div>`;
}
function renderAiText(txt){
  // light formatting: escape, bold **x**, keep line breaks
  const esc = txt.replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  return esc.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
}
async function aiRequest(aiData){
  const url = apiUrl();
  url.searchParams.set('action', 'ai');
  const res = await fetch(url.toString(), {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(aiData),
  });
  let json = {};
  try { json = await res.json(); } catch(_) {}
  if (!res.ok || json.error){
    const err = new Error(json.error || json.detail || 'Eroare AI');
    // mark gateway/timeout errors so the caller can retry once (model cold-start)
    err.gateway = res.status === 502 || res.status === 504 || /nu a răspuns la timp|lent sau oprit/i.test(json.error||'');
    throw err;
  }
  return json;
}
async function askAi(aiData){
  const btn = $('#aiBtn'), box = $('#aiResult');
  if (!btn || !box) return;
  btn.disabled = true;
  const original = btn.innerHTML;
  btn.innerHTML = '<span class="ai-ico spin">⏳</span> Analizez datele… (primul răspuns poate dura ~1 min)';
  box.hidden = false;
  box.className = 'ai-result loading';
  box.innerHTML = '<span class="ai-dot"></span><span class="ai-dot"></span><span class="ai-dot"></span>';
  try {
    let json;
    try {
      json = await aiRequest(aiData);
    } catch(e1) {
      if (!e1.gateway) throw e1;
      // cold-start: the first call likely warmed the model — retry once
      box.innerHTML = '<span class="muted small">Modelul AI se încălzește… reîncerc o dată.</span>';
      json = await aiRequest(aiData);
    }
    box.className = 'ai-result';
    box.innerHTML = `<div class="ai-head"><span class="ai-ico">🤖</span> Părerea AI${json.model ? ' · <small>'+json.model+'</small>' : ''}</div><div class="ai-text">${renderAiText(json.reply)}</div>`;
  } catch(e) {
    box.className = 'ai-result err';
    box.innerHTML = `<strong>Nu am putut obține părerea AI.</strong><br><span class="muted small">${(e.message||'').replace(/[<>]/g,'')}</span>`;
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
}
function incomeBlock(inc, q, cur){
  if (!inc || !isNum(inc.yield)) return '<p class="muted">Compania nu a plătit dividende în ultimele 12 luni (sau datele lipsesc). Randamentul vine doar din creșterea prețului.</p>';
  const annual = isNum(inc.ttmDividend) ? money(inc.ttmDividend, cur) : '—';
  let note = '';
  if (inc.yield > 9) note = 'Yield foarte mare (>9%) — verifică dacă dividendul e sustenabil sau dacă prețul a căzut.';
  else if (inc.yield >= 3.5) note = 'Yield solid pentru venit pasiv, tipic REIT / dividend stocks.';
  else note = 'Yield moderat — accent mai mare pe creșterea companiei decât pe venit imediat.';
  return `<div class="metric-grid">
    <div class="metric"><span>Dividend yield</span><strong>${pct(inc.yield)}</strong></div>
    <div class="metric"><span>Dividend / an</span><strong>${annual}</strong></div>
    <div class="metric"><span>Plăți / an</span><strong>${fmt(inc.payments,0)}</strong></div>
    <div class="metric"><span>La 10.000${curSym(cur)||' '+cur}</span><strong>${money(10000*inc.yield/100, cur)}/an</strong></div>
  </div><p class="muted small" style="margin-top:12px">${note}</p>`;
}

/* ---------- charts ---------- */
function setupCanvas(canvas){
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const w = Math.max(1, rect.width || (canvas.parentElement.clientWidth - 44));
  const h = Math.max(1, rect.height || 320);
  canvas.width = w * dpr; canvas.height = h * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  return {ctx, w, h};
}
function maSeries(closes, n){
  const out = new Array(closes.length).fill(null);
  for (let i=n-1;i<closes.length;i++){
    let sum=0; for(let j=i-n+1;j<=i;j++) sum+=closes[j];
    out[i]=sum/n;
  }
  return out;
}
function drawPriceChart(canvas, rows, cur){
  if (!canvas || !rows.length) return;
  const {ctx, w, h} = setupCanvas(canvas);
  const pad = {l:54,r:12,t:14,b:24};
  const closes = rows.map(r=>Number(r.close));
  const ma50 = maSeries(closes,50), ma200 = maSeries(closes,200);
  const all = closes.concat(ma50.filter(isNum), ma200.filter(isNum));
  const min = Math.min(...all), max = Math.max(...all);
  const x = i => pad.l + (i/(closes.length-1))*(w-pad.l-pad.r);
  const y = val => h-pad.b - ((val-min)/((max-min)||1))*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  // grid + y labels
  ctx.strokeStyle='rgba(100,116,139,.14)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui'; ctx.lineWidth=1;
  for(let i=0;i<=4;i++){ const yy=pad.t+i*(h-pad.t-pad.b)/4; const val=max-(i*(max-min)/4);
    ctx.beginPath(); ctx.moveTo(pad.l,yy); ctx.lineTo(w-pad.r,yy); ctx.stroke();
    ctx.fillText(money(val,cur).replace(/ /g,''), 6, yy+3); }
  // area under price
  const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);
  grad.addColorStop(0,'rgba(13,148,136,.22)'); grad.addColorStop(1,'rgba(13,148,136,0)');
  ctx.beginPath(); closes.forEach((v,i)=> i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v)));
  ctx.lineTo(x(closes.length-1),h-pad.b); ctx.lineTo(x(0),h-pad.b); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
  // ma lines
  const line=(arr,color)=>{ ctx.beginPath(); let started=false;
    arr.forEach((v,i)=>{ if(!isNum(v))return; const px=x(i),py=y(v); if(!started){ctx.moveTo(px,py);started=true;}else ctx.lineTo(px,py);});
    ctx.strokeStyle=color; ctx.lineWidth=1.6; ctx.stroke(); };
  line(ma200,'#d97706'); line(ma50,'#3b5bdb');
  // price line
  ctx.beginPath(); closes.forEach((v,i)=> i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v)));
  ctx.strokeStyle='#0d9488'; ctx.lineWidth=2.2; ctx.stroke();
  // x labels (first/last date)
  ctx.fillStyle='#64748b';
  ctx.fillText(rows[0]?.date||'', pad.l, h-7);
  const last=rows[rows.length-1]?.date||''; ctx.fillText(last, w-pad.r-ctx.measureText(last).width, h-7);
}
function drawVolumeChart(canvas, rows){
  if (!canvas || !rows.length) return;
  const {ctx, w, h} = setupCanvas(canvas);
  const pad={l:48,r:10,t:12,b:22};
  const vols=rows.map(r=>Number(r.volume)||0);
  const max=Math.max(...vols,1);
  const n=vols.length; const bw=Math.max(1,(w-pad.l-pad.r)/n - 0.5);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='rgba(100,116,139,.14)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui';
  for(let i=0;i<=3;i++){ const yy=pad.t+i*(h-pad.t-pad.b)/3; ctx.beginPath(); ctx.moveTo(pad.l,yy); ctx.lineTo(w-pad.r,yy); ctx.stroke();
    const val=max-(i*max/3); ctx.fillText(compactVol(val), 6, yy+3); }
  vols.forEach((v,i)=>{ const x=pad.l+(i/(n-1))*(w-pad.l-pad.r); const bh=(v/max)*(h-pad.t-pad.b);
    const up = i>0 && Number(rows[i].close)>=Number(rows[i-1].close);
    ctx.fillStyle = up ? 'rgba(22,163,74,.6)' : 'rgba(229,72,77,.5)';
    ctx.fillRect(x-bw/2, h-pad.b-bh, bw, bh); });
}
function compactVol(n){ n=Number(n); if(n>=1e9)return (n/1e9).toFixed(1)+'B'; if(n>=1e6)return (n/1e6).toFixed(0)+'M'; if(n>=1e3)return (n/1e3).toFixed(0)+'K'; return n.toFixed(0); }
function rsiSeries(closes, period=14){
  const out=new Array(closes.length).fill(null);
  if(closes.length<=period) return out;
  let gain=0,loss=0;
  for(let i=1;i<=period;i++){ const d=closes[i]-closes[i-1]; if(d>=0)gain+=d; else loss-=d; }
  let ag=gain/period, al=loss/period;
  out[period]= al===0?100:100-100/(1+ag/al);
  for(let i=period+1;i<closes.length;i++){ const d=closes[i]-closes[i-1]; const g=d>0?d:0, l=d<0?-d:0;
    ag=(ag*(period-1)+g)/period; al=(al*(period-1)+l)/period;
    out[i]= al===0?100:100-100/(1+ag/al); }
  return out;
}
function drawRsiChart(canvas, rows){
  if (!canvas || !rows.length) return;
  const {ctx, w, h} = setupCanvas(canvas);
  const pad={l:32,r:10,t:12,b:22};
  const closes=rows.map(r=>Number(r.close));
  const rsi=rsiSeries(closes);
  const x=i=>pad.l+(i/(closes.length-1))*(w-pad.l-pad.r);
  const y=v=>pad.t+(1-v/100)*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui';
  // zones 30/70
  ctx.fillStyle='rgba(229,72,77,.08)'; ctx.fillRect(pad.l,y(100),w-pad.l-pad.r,y(70)-y(100));
  ctx.fillStyle='rgba(13,148,136,.08)'; ctx.fillRect(pad.l,y(30),w-pad.l-pad.r,y(0)-y(30));
  ctx.strokeStyle='rgba(100,116,139,.25)'; ctx.setLineDash([4,4]);
  [30,50,70].forEach(lvl=>{ ctx.beginPath(); ctx.moveTo(pad.l,y(lvl)); ctx.lineTo(w-pad.r,y(lvl)); ctx.stroke();
    ctx.fillStyle='#64748b'; ctx.fillText(lvl, 8, y(lvl)+3); });
  ctx.setLineDash([]);
  ctx.beginPath(); let started=false;
  rsi.forEach((v,i)=>{ if(!isNum(v))return; const px=x(i),py=y(v); if(!started){ctx.moveTo(px,py);started=true;}else ctx.lineTo(px,py);});
  ctx.strokeStyle='#7c3aed'; ctx.lineWidth=1.8; ctx.stroke();
}

/* ===================== WATCHLIST / PORTFOLIO ===================== */
function emaSeries(values, n){
  const k = 2/(n+1), out = new Array(values.length).fill(null);
  let prev = null;
  for (let i=0;i<values.length;i++){
    if (prev === null){ if (i >= n-1){ let s=0; for(let j=i-n+1;j<=i;j++) s+=values[j]; prev=s/n; out[i]=prev; } }
    else { prev = values[i]*k + prev*(1-k); out[i]=prev; }
  }
  return out;
}
function drawBollinger(canvas, rows, cur){
  if (!canvas || !rows.length) return;
  const {ctx,w,h} = setupCanvas(canvas);
  const pad={l:54,r:12,t:14,b:24};
  const closes = rows.map(r=>Number(r.close));
  const n = closes.length, P = 20;
  const mid = maSeries(closes, P), up = new Array(n).fill(null), lo = new Array(n).fill(null);
  for (let i=P-1;i<n;i++){ let s=0; for(let j=i-P+1;j<=i;j++) s+=(closes[j]-mid[i])**2; const sd=Math.sqrt(s/P); up[i]=mid[i]+2*sd; lo[i]=mid[i]-2*sd; }
  const all = closes.concat(up.filter(isNum), lo.filter(isNum));
  const min=Math.min(...all), max=Math.max(...all);
  const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>h-pad.b-((v-min)/((max-min)||1))*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='rgba(100,116,139,.12)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui';
  for(let i=0;i<=4;i++){const yy=pad.t+i*(h-pad.t-pad.b)/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText(money(max-i*(max-min)/4,cur).replace(/ /g,''),6,yy+3);}
  // fill between bands
  ctx.beginPath(); let started=false;
  for(let i=0;i<n;i++){ if(!isNum(up[i]))continue; const px=x(i),py=y(up[i]); started?ctx.lineTo(px,py):(ctx.moveTo(px,py),started=true); }
  for(let i=n-1;i>=0;i--){ if(!isNum(lo[i]))continue; ctx.lineTo(x(i),y(lo[i])); }
  ctx.closePath(); ctx.fillStyle='rgba(59,91,219,.10)'; ctx.fill();
  const line=(arr,c,wd)=>{ctx.beginPath();let st=false;for(let i=0;i<n;i++){if(!isNum(arr[i]))continue;const px=x(i),py=y(arr[i]);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}ctx.strokeStyle=c;ctx.lineWidth=wd;ctx.stroke();};
  line(up,'#3b5bdb',1.2); line(lo,'#3b5bdb',1.2); line(mid,'#64748b',1.2);
  line(closes,'#0d9488',2);
}
function drawMACD(canvas, rows){
  if (!canvas || !rows.length) return;
  const {ctx,w,h} = setupCanvas(canvas);
  const pad={l:40,r:12,t:14,b:22};
  const closes = rows.map(r=>Number(r.close)), n = closes.length;
  const e12 = emaSeries(closes,12), e26 = emaSeries(closes,26);
  const macd = closes.map((_,i)=> (isNum(e12[i])&&isNum(e26[i])) ? e12[i]-e26[i] : null);
  // signal = EMA9 of macd (over defined region)
  const sig = new Array(n).fill(null); const k=2/(9+1); let prev=null, cnt=0, acc=0;
  for(let i=0;i<n;i++){ if(!isNum(macd[i]))continue; if(prev===null){ acc+=macd[i]; cnt++; if(cnt===9){ prev=acc/9; sig[i]=prev; } } else { prev=macd[i]*k+prev*(1-k); sig[i]=prev; } }
  const hist = macd.map((m,i)=> (isNum(m)&&isNum(sig[i])) ? m-sig[i] : null);
  const vals = macd.filter(isNum).concat(sig.filter(isNum), hist.filter(isNum));
  const m = Math.max(...vals.map(Math.abs), 0.001);
  const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>pad.t+(1-(v+m)/(2*m))*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='rgba(100,116,139,.25)'; ctx.beginPath(); ctx.moveTo(pad.l,y(0)); ctx.lineTo(w-pad.r,y(0)); ctx.stroke();
  const bw=Math.max(1,(w-pad.l-pad.r)/n-0.5);
  for(let i=0;i<n;i++){ if(!isNum(hist[i]))continue; const px=x(i); ctx.fillStyle=hist[i]>=0?'rgba(13,148,136,.5)':'rgba(229,72,77,.5)'; const y0=y(0),yv=y(hist[i]); ctx.fillRect(px-bw/2,Math.min(y0,yv),bw,Math.abs(yv-y0)); }
  const line=(arr,c)=>{ctx.beginPath();let st=false;for(let i=0;i<n;i++){if(!isNum(arr[i]))continue;const px=x(i),py=y(arr[i]);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}ctx.strokeStyle=c;ctx.lineWidth=1.7;ctx.stroke();};
  line(macd,'#0d9488'); line(sig,'#d97706');
}
function drawReturn(canvas, rows){
  if (!canvas || !rows.length) return 0;
  const {ctx,w,h} = setupCanvas(canvas);
  const pad={l:46,r:12,t:14,b:22};
  const closes = rows.map(r=>Number(r.close)), base = closes[0], n = closes.length;
  const ret = closes.map(c=>(c/base-1)*100);
  const min=Math.min(...ret,0), max=Math.max(...ret,0);
  const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>h-pad.b-((v-min)/((max-min)||1))*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='rgba(100,116,139,.12)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui';
  for(let i=0;i<=4;i++){const yy=pad.t+i*(h-pad.t-pad.b)/4;const val=max-i*(max-min)/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText((val>=0?'+':'')+val.toFixed(0)+'%',6,yy+3);}
  ctx.strokeStyle='rgba(100,116,139,.4)'; ctx.setLineDash([4,4]); ctx.beginPath(); ctx.moveTo(pad.l,y(0)); ctx.lineTo(w-pad.r,y(0)); ctx.stroke(); ctx.setLineDash([]);
  const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b); grad.addColorStop(0,'rgba(13,148,136,.22)'); grad.addColorStop(1,'rgba(13,148,136,0)');
  ctx.beginPath(); ret.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.lineTo(x(n-1),y(0)); ctx.lineTo(x(0),y(0)); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
  ctx.beginPath(); ret.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.strokeStyle='#0d9488'; ctx.lineWidth=2.2; ctx.stroke();
  return ret[n-1];
}
function drawDrawdown(canvas, rows){
  if (!canvas || !rows.length) return 0;
  const {ctx,w,h} = setupCanvas(canvas);
  const pad={l:46,r:12,t:14,b:22};
  const closes = rows.map(r=>Number(r.close)), n = closes.length;
  let peak=closes[0]; const dd=closes.map(c=>{ if(c>peak)peak=c; return (c/peak-1)*100; });
  const min=Math.min(...dd,-0.001);
  const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>pad.t+(v/min)*(h-pad.t-pad.b);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='rgba(100,116,139,.12)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui';
  for(let i=0;i<=4;i++){const yy=pad.t+i*(h-pad.t-pad.b)/4;const val=i*min/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText(val.toFixed(0)+'%',6,yy+3);}
  const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b); grad.addColorStop(0,'rgba(229,72,77,0)'); grad.addColorStop(1,'rgba(229,72,77,.28)');
  ctx.beginPath(); dd.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.lineTo(x(n-1),y(0)); ctx.lineTo(x(0),y(0)); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
  ctx.beginPath(); dd.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.strokeStyle='#e5484d'; ctx.lineWidth=2; ctx.stroke();
  return min;
}
function saveWatch(){ localStorage.setItem('investiq_watchlist', JSON.stringify(watch)); }
function addToWatch(sym){
  sym = (sym || $('#symbolInput').value || '').toUpperCase().trim();
  if(!sym) return;
  const i = watch.indexOf(sym);
  if(i >= 0){ watch.splice(i,1); toast(`${sym} scos din watchlist`); }
  else { watch.push(sym); toast(`${sym} adăugat în watchlist`); }
  saveWatch(); renderWatchlist(); updateWatchBtn(sym);
}
function removeFromWatch(sym){ watch = watch.filter(x=>x!==sym); saveWatch(); renderWatchlist(); }
function updateWatchBtn(sym){
  const b = $('#addWatch'); if(!b) return;
  sym = (sym || $('#symbolInput').value || '').toUpperCase().trim();
  const inW = watch.includes(sym);
  b.textContent = inW ? '✓ În watchlist' : '+ Watchlist';
  b.classList.toggle('active', inW);
}
function renderWatchlist(){
  const el = $('#watchlist'); if(!el) return;
  el.innerHTML = watch.length ? watch.map(s=>`<span class="chip"><button class="chip-open" data-open="${s}" title="Deschide analiza">${s}</button><button data-rm="${s}" title="Scoate">×</button></span>`).join('') : '<p class="muted">Watchlist gol. Adaugă din „Analiză companie".</p>';
  $$('#watchlist [data-open]').forEach(b => b.addEventListener('click', () => loadCompany(b.dataset.open)));
  $$('#watchlist [data-rm]').forEach(b => b.addEventListener('click', () => { removeFromWatch(b.dataset.rm); }));
}
async function renderWatchView(){
  const box = $('#watchCards'); if(!box) return;
  const meta = $('#watchMeta');
  if(!watch.length){
    if(meta) meta.textContent = '0 companii';
    box.innerHTML = '<div class="card"><p class="muted">Watchlist gol. Deschide o companie în „Analiză companie" și apasă <b>„+ Watchlist"</b> ca să o salvezi aici.</p></div>';
    return;
  }
  if(meta) meta.textContent = `${watch.length} ${watch.length===1?'companie':'companii'} · se încarcă live…`;
  box.innerHTML = ideasSkeleton(Math.min(watch.length, 9));
  const cards = [];
  for(const sym of watch){
    try {
      const r = await api('company', {symbol: sym});
      const d = r.data;
      const flat = Object.assign({}, d.quote, { score: d.score, dividendYield: d.income && d.income.yield, position52w: d.technicals && d.technicals.position52w });
      cards.push(pickCard(flat, 'watch'));
    } catch(e){
      cards.push(`<div class="pick"><div class="pick-top"><div class="pick-id"><div class="tk">${sym}</div><div class="nm">Nu am putut încărca datele</div></div></div><button class="ghost pick-rm" data-rmwatch="${sym}">× Scoate din watchlist</button></div>`);
    }
  }
  box.innerHTML = cards.join('');
  if(meta) meta.textContent = `${watch.length} ${watch.length===1?'companie':'companii'} · live Yahoo Finance + SEC`;
  $$('#watchCards .pick-btn').forEach(b => b.addEventListener('click', () => loadCompany(b.dataset.symbol)));
  $$('#watchCards [data-rmwatch]').forEach(b => b.addEventListener('click', () => { removeFromWatch(b.dataset.rmwatch); renderWatchView(); }));
}
async function buildPortfolio(){
  const symbols = ($('#portfolioSymbols').value || watch.join(',')).split(',').map(s=>s.trim().toUpperCase()).filter(Boolean);
  if (!symbols.length) { toast('Adaugă tickere'); return; }
  $('#portfolioOut').innerHTML = '<p class="muted">Analizez portofoliul…</p>';
  const rows=[];
  for (const s of symbols) { try { const r = await api('company', {symbol:s}); rows.push(r.data); } catch(e) {} }
  if(!rows.length){ $('#portfolioOut').innerHTML = '<p class="muted">Nu am putut încărca tickerele.</p>'; return; }
  const sectors = {};
  rows.forEach(r => { const sec = r.quote.sector || 'Unknown'; sectors[sec] = (sectors[sec]||0)+1; });
  const equal = 100 / rows.length;
  const avg = rows.reduce((a,r)=>a+(r.score.final||0),0)/rows.length;
  $('#portfolioOut').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Ticker</th><th>Sector</th><th>Score</th><th>Verdict</th><th>Pondere</th></tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${r.quote.symbol}</strong></td><td>${r.quote.sector}</td><td><span class="score s-${scoreClass(r.score.final)}">${fmt(r.score.final,0)}</span></td><td class="vchip v-${(r.score.verdict||{}).tone||scoreClass(r.score.final)}">${(r.score.verdict||{}).label||'—'}</td><td>${equal.toFixed(1)}%</td></tr>`).join('')}</tbody></table></div><div class="cap" style="margin-top:14px">Scor mediu portofoliu: <strong>${fmt(avg,0)}/100</strong>. Concentrare sectorială: ${Object.entries(sectors).map(([k,v])=>`${k}: ${v}`).join(' · ')}. Regula practică: nu pune prea mult în același sector — diversifică.</div>`;
}

/* ===================== GUIDE (interactive) ===================== */
const DEMO = (()=>{
  let s = 12345; const rnd = () => { s = (s*9301+49297)%233280; return s/233280; };
  const closes = []; let v = 100;
  for (let i=0;i<160;i++){ v += (rnd()-0.46)*2.4 + Math.sin(i/14)*0.9; closes.push(Math.max(30, v)); }
  const vols = []; for (let i=0;i<160;i++) vols.push(0.35 + rnd());
  return {closes, vols};
})();
function animLine(canvas, drawFrame, dur=1100){
  const {ctx, w, h} = setupCanvas(canvas);
  const start = performance.now();
  (function f(now){ const p = Math.min(1,(now-start)/dur); ctx.clearRect(0,0,w,h); drawFrame(ctx,w,h,p); if(p<1) requestAnimationFrame(f); })(performance.now());
}
function demoMA(canvas){
  const closes = DEMO.closes, n = closes.length;
  const ma50 = maSeries(closes,50), ma200 = maSeries(closes,120);
  const all = closes.concat(ma50.filter(isNum), ma200.filter(isNum));
  const min = Math.min(...all), max = Math.max(...all);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:46,r:10,t:12,b:12}, count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>h-pad.b-((v-min)/((max-min)||1))*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.12)'; ctx.lineWidth=1;
    for(let i=0;i<=3;i++){const yy=pad.t+i*(h-pad.t-pad.b)/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();}
    const ln=(arr,c,wd)=>{ctx.beginPath();let st=false;for(let i=0;i<count;i++){const v=arr[i];if(!isNum(v))continue;const px=x(i),py=y(v);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}ctx.strokeStyle=c;ctx.lineWidth=wd;ctx.stroke();};
    ln(ma200,'#d97706',1.6); ln(ma50,'#3b5bdb',1.6); ln(closes,'#0d9488',2);
  });
}
function demoRSI(canvas){
  const rsi = rsiSeries(DEMO.closes), n = rsi.length;
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:30,r:10,t:10,b:12}, count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>pad.t+(1-v/100)*(h-pad.t-pad.b);
    ctx.fillStyle='rgba(229,72,77,.08)';ctx.fillRect(pad.l,y(100),w-pad.l-pad.r,y(70)-y(100));
    ctx.fillStyle='rgba(13,148,136,.08)';ctx.fillRect(pad.l,y(30),w-pad.l-pad.r,y(0)-y(30));
    ctx.setLineDash([4,4]);ctx.strokeStyle='rgba(100,116,139,.3)';ctx.fillStyle='#64748b';ctx.font='11px Inter,system-ui';
    [30,50,70].forEach(l=>{ctx.beginPath();ctx.moveTo(pad.l,y(l));ctx.lineTo(w-pad.r,y(l));ctx.stroke();ctx.fillText(l,7,y(l)+3);});
    ctx.setLineDash([]);
    ctx.beginPath();let st=false;for(let i=0;i<count;i++){const v=rsi[i];if(!isNum(v))continue;const px=x(i),py=y(v);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}ctx.strokeStyle='#7c3aed';ctx.lineWidth=1.9;ctx.stroke();
  });
}
function demoVol(canvas){
  const vols=DEMO.vols, closes=DEMO.closes, n=vols.length, max=Math.max(...vols);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:16,r:10,t:10,b:12}, count=Math.floor(p*n), bw=Math.max(1,(w-pad.l-pad.r)/n-0.6);
    for(let i=0;i<count;i++){const x=pad.l+(i/(n-1))*(w-pad.l-pad.r);const bh=(vols[i]/max)*(h-pad.t-pad.b);const up=i>0&&closes[i]>=closes[i-1];ctx.fillStyle=up?'rgba(13,148,136,.6)':'rgba(229,72,77,.55)';ctx.fillRect(x-bw/2,h-pad.b-bh,bw,bh);}
  });
}
function demoBoll(canvas){
  const closes=DEMO.closes, n=closes.length, P=20;
  const mid=maSeries(closes,P), up=new Array(n).fill(null), lo=new Array(n).fill(null);
  for(let i=P-1;i<n;i++){let s=0;for(let j=i-P+1;j<=i;j++)s+=(closes[j]-mid[i])**2;const sd=Math.sqrt(s/P);up[i]=mid[i]+2*sd;lo[i]=mid[i]-2*sd;}
  const all=closes.concat(up.filter(isNum),lo.filter(isNum)),min=Math.min(...all),max=Math.max(...all);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:46,r:10,t:12,b:14},count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r),y=v=>h-pad.b-((v-min)/((max-min)||1))*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.12)';for(let i=0;i<=3;i++){const yy=pad.t+i*(h-pad.t-pad.b)/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();}
    ctx.beginPath();let st=false;for(let i=0;i<count;i++){if(!isNum(up[i]))continue;const px=x(i),py=y(up[i]);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}for(let i=count-1;i>=0;i--){if(!isNum(lo[i]))continue;ctx.lineTo(x(i),y(lo[i]));}ctx.closePath();ctx.fillStyle='rgba(59,91,219,.10)';ctx.fill();
    const ln=(arr,c,wd)=>{ctx.beginPath();let s2=false;for(let i=0;i<count;i++){if(!isNum(arr[i]))continue;const px=x(i),py=y(arr[i]);s2?ctx.lineTo(px,py):(ctx.moveTo(px,py),s2=true);}ctx.strokeStyle=c;ctx.lineWidth=wd;ctx.stroke();};
    ln(up,'#3b5bdb',1.1);ln(lo,'#3b5bdb',1.1);ln(mid,'#94a3b8',1.1);ln(closes,'#0d9488',2);
  });
}
function demoMACDg(canvas){
  const closes=DEMO.closes,n=closes.length,e12=emaSeries(closes,12),e26=emaSeries(closes,26);
  const macd=closes.map((_,i)=>(isNum(e12[i])&&isNum(e26[i]))?e12[i]-e26[i]:null);
  const sig=new Array(n).fill(null);let prev=null,cnt=0,acc=0;const k=2/10;
  for(let i=0;i<n;i++){if(!isNum(macd[i]))continue;if(prev===null){acc+=macd[i];cnt++;if(cnt===9){prev=acc/9;sig[i]=prev;}}else{prev=macd[i]*k+prev*(1-k);sig[i]=prev;}}
  const hist=macd.map((m,i)=>(isNum(m)&&isNum(sig[i]))?m-sig[i]:null);
  const vals=macd.filter(isNum).concat(sig.filter(isNum),hist.filter(isNum)),m=Math.max(...vals.map(Math.abs),0.001);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:30,r:10,t:12,b:14},count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r),y=v=>pad.t+(1-(v+m)/(2*m))*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.25)';ctx.beginPath();ctx.moveTo(pad.l,y(0));ctx.lineTo(w-pad.r,y(0));ctx.stroke();
    const bw=Math.max(1,(w-pad.l-pad.r)/n-0.5);
    for(let i=0;i<count;i++){if(!isNum(hist[i]))continue;const px=x(i);ctx.fillStyle=hist[i]>=0?'rgba(13,148,136,.5)':'rgba(229,72,77,.5)';const y0=y(0),yv=y(hist[i]);ctx.fillRect(px-bw/2,Math.min(y0,yv),bw,Math.abs(yv-y0));}
    const ln=(arr,c)=>{ctx.beginPath();let st=false;for(let i=0;i<count;i++){if(!isNum(arr[i]))continue;const px=x(i),py=y(arr[i]);st?ctx.lineTo(px,py):(ctx.moveTo(px,py),st=true);}ctx.strokeStyle=c;ctx.lineWidth=1.7;ctx.stroke();};
    ln(macd,'#0d9488');ln(sig,'#d97706');
  });
}
function demoRet(canvas){
  const closes=DEMO.closes,base=closes[0],n=closes.length,ret=closes.map(c=>(c/base-1)*100);
  const min=Math.min(...ret,0),max=Math.max(...ret,0);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:42,r:10,t:12,b:14},count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r),y=v=>h-pad.b-((v-min)/((max-min)||1))*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.12)';ctx.fillStyle='#64748b';ctx.font='11px Inter,system-ui';
    for(let i=0;i<=3;i++){const yy=pad.t+i*(h-pad.t-pad.b)/3;const val=max-i*(max-min)/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText((val>=0?'+':'')+val.toFixed(0)+'%',6,yy+3);}
    ctx.setLineDash([4,4]);ctx.strokeStyle='rgba(100,116,139,.4)';ctx.beginPath();ctx.moveTo(pad.l,y(0));ctx.lineTo(w-pad.r,y(0));ctx.stroke();ctx.setLineDash([]);
    const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);grad.addColorStop(0,'rgba(13,148,136,.20)');grad.addColorStop(1,'rgba(13,148,136,0)');
    ctx.beginPath();for(let i=0;i<count;i++){const px=x(i),py=y(ret[i]);i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.lineTo(x(count-1),y(0));ctx.lineTo(x(0),y(0));ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath();for(let i=0;i<count;i++){const px=x(i),py=y(ret[i]);i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.strokeStyle='#0d9488';ctx.lineWidth=2.2;ctx.stroke();
  });
}
function demoDD(canvas){
  const closes=DEMO.closes,n=closes.length;let peak=closes[0];const dd=closes.map(c=>{if(c>peak)peak=c;return (c/peak-1)*100;});
  const min=Math.min(...dd,-0.001);
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:42,r:10,t:12,b:14},count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r),y=v=>pad.t+(v/min)*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.12)';ctx.fillStyle='#64748b';ctx.font='11px Inter,system-ui';
    for(let i=0;i<=3;i++){const yy=pad.t+i*(h-pad.t-pad.b)/3;const val=i*min/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText(val.toFixed(0)+'%',6,yy+3);}
    const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);grad.addColorStop(0,'rgba(229,72,77,0)');grad.addColorStop(1,'rgba(229,72,77,.28)');
    ctx.beginPath();for(let i=0;i<count;i++){const px=x(i),py=y(dd[i]);i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.lineTo(x(count-1),y(0));ctx.lineTo(x(0),y(0));ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath();for(let i=0;i<count;i++){const px=x(i),py=y(dd[i]);i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.strokeStyle='#e5484d';ctx.lineWidth=2;ctx.stroke();
  });
}
function demoRange(acc){
  const c=DEMO.closes, lo=Math.min(...c), hi=Math.max(...c), cur=c[c.length-1];
  const pos=Math.max(0,Math.min(100,(cur-lo)/((hi-lo)||1)*100));
  const fill=acc.querySelector('.rangedemo .fill'), marker=acc.querySelector('.rangedemo .marker'), val=acc.querySelector('.rd-val');
  if(val) val.textContent = pos.toFixed(0)+'% în interval';
  fill.style.width='0%'; marker.style.left='0%';
  setTimeout(()=>{ fill.style.width=pos+'%'; marker.style.left=`calc(${pos}% - 2px)`; }, 60);
}
function demoCompound(){
  const canvas = $('#demoCompound'); if (!canvas) return;
  const yrs=30, rate=0.08, contrib=1000;
  const contribArr=[], valArr=[]; let val=0;
  for(let y=0;y<=yrs;y++){ contribArr.push(contrib*y); valArr.push(val); val=(val+contrib)*(1+rate); }
  const max=Math.max(...valArr), n=yrs+1;
  const cap=$('#compoundCap');
  if(cap) cap.innerHTML=`După 30 de ani ai pus <strong>${fmt(contribArr[yrs],0)}</strong> din buzunar, dar ai avea ~<strong class="v-good">${fmt(valArr[yrs],0)}</strong>. Diferența — <strong>${fmt(valArr[yrs]-contribArr[yrs],0)}</strong> — sunt banii făcuți de dobânda compusă.`;
  animLine(canvas,(ctx,w,h,p)=>{
    const pad={l:54,r:12,t:14,b:24}, count=Math.max(2,Math.floor(p*n));
    const x=i=>pad.l+(i/(n-1))*(w-pad.l-pad.r), y=v=>h-pad.b-(v/max)*(h-pad.t-pad.b);
    ctx.strokeStyle='rgba(100,116,139,.13)'; ctx.fillStyle='#64748b'; ctx.font='11px Inter,system-ui'; ctx.lineWidth=1;
    for(let i=0;i<=4;i++){const yy=pad.t+i*(h-pad.t-pad.b)/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText('$'+Math.round((max-i*max/4)/1000)+'k',6,yy+3);}
    // value area (teal)
    const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b); grad.addColorStop(0,'rgba(13,148,136,.20)'); grad.addColorStop(1,'rgba(13,148,136,0)');
    ctx.beginPath(); for(let i=0;i<count;i++){const px=x(i),py=y(valArr[i]); i?ctx.lineTo(px,py):ctx.moveTo(px,py);} ctx.lineTo(x(count-1),h-pad.b); ctx.lineTo(x(0),h-pad.b); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
    const ln=(arr,c,wd)=>{ctx.beginPath();for(let i=0;i<count;i++){const px=x(i),py=y(arr[i]); i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.strokeStyle=c;ctx.lineWidth=wd;ctx.stroke();};
    ln(contribArr,'#94a3b8',1.6); ln(valArr,'#0d9488',2.4);
    ctx.fillStyle='#64748b'; ctx.fillText('anul 0', pad.l, h-7); ctx.fillText('anul 30', w-pad.r-42, h-7);
  }, 1300);
}
function animateScoreBars(){
  const fills = $$('#gp-score .demo-bars .fill');
  fills.forEach(f=>f.style.width='0%');
  setTimeout(()=>fills.forEach(f=>f.style.width=(f.dataset.v||0)+'%'), 60);
}
function initGuide(){
  $$('#guide .gtab').forEach(tab => tab.addEventListener('click', () => {
    const t = tab.dataset.gtab;
    $$('#guide .gtab').forEach(b=>b.classList.toggle('active', b===tab));
    $$('#guide .gpane').forEach(p=>p.classList.toggle('active', p.id==='gp-'+t));
    if (t==='score') animateScoreBars();
    if (t==='strategy') setTimeout(demoCompound, 60);
  }));
  $$('#guide .acc-head').forEach(head => head.addEventListener('click', () => {
    const acc = head.parentElement, body = head.nextElementSibling;
    const open = acc.classList.toggle('open');
    if (!open){ body.style.maxHeight = '0'; return; }
    body.style.maxHeight = body.scrollHeight + 'px';
    setTimeout(()=>{
      const cv = body.querySelector('canvas[data-demo]');
      if (cv){ ({ma:demoMA, rsi:demoRSI, vol:demoVol, boll:demoBoll, macd:demoMACDg, ret:demoRet, dd:demoDD}[cv.dataset.demo] || (()=>{}))(cv); }
      if (body.querySelector('.rangedemo')) demoRange(acc);
      body.style.maxHeight = body.scrollHeight + 'px';
    }, 130);
  }));
}

/* ---------- events ---------- */
$('#ideaGoal').addEventListener('change', toggleYieldField);
$('#findIdeas').addEventListener('click', findIdeas);
$('#runScan').addEventListener('click', () => runScan());
$('#copyIdeas')?.addEventListener('click', (e) => copyToClipboard(buildListText(lastIdeaRows, 'Idei InvestIQ'), e.currentTarget));
$('#copyScan')?.addEventListener('click', (e) => copyToClipboard(buildListText(scanRows, 'Scanner InvestIQ'), e.currentTarget));
$$('#scanTable th.sortable').forEach(th => th.addEventListener('click', () => applyScanSort(th.dataset.key)));
$('#runDiagnostics').addEventListener('click', runDiagnostics);
$('#loadCompany').addEventListener('click', () => loadCompany());
$('#symbolInput').addEventListener('keydown', e => { if(e.key==='Enter') loadCompany(); });
$('#addWatch').addEventListener('click', () => addToWatch());
$('#buildPortfolio').addEventListener('click', buildPortfolio);

async function runDiagnostics(){
  $('#scanMeta').textContent = 'Rulez diagnosticul API…';
  $('#scanTable tbody').innerHTML = '<tr><td colspan="10" class="empty">Testez api/api.php și conexiunea către Yahoo Finance.</td></tr>';
  try {
    const d = await api('diagnostics'); const ext = d.external || {};
    $('#scanMeta').textContent = `API OK · PHP ${d.php} · cache ${d.cacheWritable?'writable':'not writable'} · Yahoo: ${ext.ok?'OK':'problemă'}`;
    $('#scanTable tbody').innerHTML = `<tr><td colspan="10" class="empty">${ext.message||'OK'} · ${d.universeCount} active în univers.</td></tr>`;
  } catch(e){ $('#scanMeta').textContent = e.message; $('#scanTable tbody').innerHTML = `<tr><td colspan="10" class="empty">Diagnostic eșuat: ${e.message}</td></tr>`; }
}

function routeHash(){
  const h = location.hash || '';
  const m = h.match(/^#company\/([A-Za-z0-9.\-]+)/);
  if (m) { loadCompany(m[1]); return; }
  const view = h.replace('#','');
  if (view && $('#'+view) && $('#'+view).classList.contains('view')) setView(view);
}
window.addEventListener('hashchange', routeHash);

initGuide();
init();
if (location.hash.startsWith('#company/')) routeHash();
else { if (location.hash) routeHash(); findIdeas(); }
