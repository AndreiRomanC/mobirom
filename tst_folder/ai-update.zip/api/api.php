<?php
$config = require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
@ini_set('display_errors', '0');
@ini_set('memory_limit', '320M'); // parallel SEC fetches hold several decompressed companyfacts files
@set_time_limit(70);

function json_response($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function clean($v, $max = 120) {
    $v = trim((string)$v);
    $v = preg_replace('/[^A-Za-z0-9_\.\-\^, :\/]/', '', $v);
    return substr($v, 0, $max);
}
function q($key, $default = '') { return isset($_GET[$key]) ? $_GET[$key] : $default; }
function cache_path($key) {
    $dir = __DIR__ . '/cache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir . '/' . sha1($key) . '.cache';
}
function http_get($url, $cacheSeconds = 60, $headers = []) {
    $cacheFile = cache_path($url . json_encode($headers));
    if ($cacheSeconds > 0 && file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheSeconds) {
        return file_get_contents($cacheFile);
    }
    $defaultHeaders = [
        'Accept: */*',
        'User-Agent: InvestIQ-Free-Live/2026 (+local-app)'
    ];
    $allHeaders = array_merge($defaultHeaders, $headers);
    $body = false; $status = 0; $err = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $allHeaders,
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 20, 'header' => implode("\r\n", $allHeaders) . "\r\n"]]);
        $body = @file_get_contents($url, false, $ctx);
        $respHeaders = function_exists('http_get_last_response_headers') ? http_get_last_response_headers() : (${'http_response_header'} ?? null);
        if (is_array($respHeaders) && isset($respHeaders[0]) && preg_match('/\s(\d{3})\s/', $respHeaders[0], $m)) $status = (int)$m[1];
        $err = 'file_get_contents failed';
    }
    if ($body === false || $status >= 400) {
        throw new Exception('HTTP failed: ' . $status . ' ' . $err . ' url=' . $url);
    }
    if ($cacheSeconds > 0) @file_put_contents($cacheFile, $body);
    return $body;
}
// Parallel GET for many URLs (curl_multi), with the same file cache as http_get.
// $reqs: [['url'=>, 'headers'=>[], 'cache'=>int], ...]  -> returns map url => body|null
function http_get_multi($reqs) {
    $out = []; $toFetch = [];
    foreach ($reqs as $r) {
        $url = $r['url']; $headers = $r['headers'] ?? []; $cs = $r['cache'] ?? 0;
        $cf = cache_path($url . json_encode($headers));
        if ($cs > 0 && file_exists($cf) && (time() - filemtime($cf)) < $cs) $out[$url] = file_get_contents($cf);
        else $toFetch[$url] = $r;
    }
    if ($toFetch && function_exists('curl_multi_init')) {
        $mh = curl_multi_init(); $handles = [];
        foreach ($toFetch as $url => $r) {
            $ch = curl_init($url);
            $allHeaders = array_merge(['Accept: */*', 'User-Agent: InvestIQ-Free-Live/2026 (+local-app)'], $r['headers'] ?? []);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_CONNECTTIMEOUT=>8, CURLOPT_TIMEOUT=>25, CURLOPT_ENCODING=>'', CURLOPT_HTTPHEADER=>$allHeaders]);
            curl_multi_add_handle($mh, $ch); $handles[$url] = $ch;
        }
        $running = null;
        do { curl_multi_exec($mh, $running); curl_multi_select($mh, 1.0); } while ($running > 0);
        foreach ($handles as $url => $ch) {
            $body = curl_multi_getcontent($ch); $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($body !== false && $body !== '' && $status < 400) {
                $out[$url] = $body;
                $cs = $toFetch[$url]['cache'] ?? 0;
                if ($cs > 0) @file_put_contents(cache_path($url . json_encode($toFetch[$url]['headers'] ?? [])), $body);
            } else $out[$url] = null;
            curl_multi_remove_handle($mh, $ch); curl_close($ch);
        }
        curl_multi_close($mh);
    } else {
        foreach ($toFetch as $url => $r) { try { $out[$url] = http_get($url, $r['cache'] ?? 0, $r['headers'] ?? []); } catch (Throwable $e) { $out[$url] = null; } }
    }
    return $out;
}
// POST a JSON payload and return the decoded response (no caching). Used for the Ollama AI call.
function http_post_json($url, $payload, $timeout = 60) {
    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => (int)$timeout,
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers) . "\r\n",
            'content' => $json,
            'timeout' => (int)$timeout,
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        $status = ($body === false) ? 0 : 200;
        $err = 'file_get_contents failed';
    }
    if ($body === false || $status >= 400) {
        throw new Exception('Ollama HTTP ' . $status . ' ' . $err, $status ?: 0);
    }
    return $body;
}
// Pull the assistant text out of whatever shape the endpoint returns (custom {reply} or native Ollama {message:{content}}).
function extract_ai_reply($raw) {
    $d = json_decode($raw, true);
    if (!is_array($d)) return trim((string)$raw); // endpoint returned plain text
    foreach (['reply', 'response', 'answer', 'text', 'output'] as $k) {
        if (isset($d[$k]) && is_string($d[$k]) && trim($d[$k]) !== '') return trim($d[$k]);
    }
    if (isset($d['message']['content'])) return trim($d['message']['content']);
    if (isset($d['choices'][0]['message']['content'])) return trim($d['choices'][0]['message']['content']);
    return '';
}
// Build a detailed Romanian analyst prompt: send the full picture and ask the model to (1) sanity-check the data and (2) give a clear buy/wait/avoid call.
function build_ai_prompt($p) {
    $f = $p['fundamentals'] ?? [];
    $v = $p['valuation'] ?? [];
    $t = $p['technicals'] ?? [];
    $sc = $p['score'] ?? [];
    $cur = $p['currency'] ?? 'USD';
    $money = function($n) use ($cur) {
        if ($n === null || $n === '' || !is_numeric($n)) return null;
        $n = (float)$n; $s = ($cur === 'EUR' ? '€' : ($cur === 'GBP' ? '£' : '$'));
        if (abs($n) >= 1e9) return $s . round($n/1e9, 2) . 'B';
        if (abs($n) >= 1e6) return $s . round($n/1e6, 2) . 'M';
        return $s . round($n, 2);
    };
    $line = function($label, $val, $suffix = '') {
        if ($val === null || $val === '' || !is_numeric($val)) return null;
        return "$label " . round((float)$val, 2) . $suffix;
    };
    $mline = function($label, $val) use ($money) { $m = $money($val); return $m === null ? null : "$label $m"; };
    $isReit = !empty($p['isReit']);
    // Balance sheet + income
    $rows = array_filter([
        $mline('Preț', $p['price'] ?? null),
        $mline('Capitalizare', $p['marketCap'] ?? null),
        $mline('Active totale', $f['assets'] ?? null),
        $mline('Datorii totale', $f['liabilities'] ?? null),
        $mline('Capital propriu (equity)', $f['equity'] ?? null),
        $line('Equity ratio', $f['equityRatio'] ?? null, '%'),
        $mline('Venituri', $f['revenue'] ?? null),
        $mline('Profit net', $f['netIncome'] ?? null),
        $line('Marjă profit', $f['profitMargin'] ?? null, '%'),
        $line('Marjă EBIT', $f['ebitMargin'] ?? null, '%'),
        $mline('EBITDA', $f['ebitda'] ?? null),
        $line('ROE', $f['roe'] ?? null, '%'),
        $line('Creștere venituri', $f['revenueGrowth'] ?? null, '%'),
        $mline('Cash', $f['cash'] ?? null),
        $mline('Datorie totală', $f['totalDebt'] ?? null),
        $mline('Datorie netă', $f['netDebt'] ?? null),
        $line('Datorii/Equity', $f['debtEquity'] ?? null),
        $line('Net Debt/EBITDA', $f['netDebtEbitda'] ?? null, '×'),
        $line('Interest coverage', $f['interestCoverage'] ?? null, '×'),
        $mline('Free cash flow', $f['freeCashFlow'] ?? null),
    ]);
    // Valuation
    $valRows = array_filter([
        $line('P/E', $v['pe'] ?? null),
        (!empty($v['peUncertain']) && isset($v['peFromEps'])) ? ('P/E din EPS ' . round((float)$v['peFromEps'],1) . ' (DIVERGENȚĂ — posibil net income greșit extras)') : null,
        $line('P/B', $v['pb'] ?? null),
        $line('P/S', $v['ps'] ?? null),
        $line('EV/EBITDA', $v['evEbitda'] ?? null, '×'),
        $isReit ? $line('P/FFO', $v['pFfo'] ?? null, '×') : $line('P/FCF', $v['pFcf'] ?? null, '×'),
        $isReit ? $line('FFO payout', $v['ffoPayout'] ?? null, '%') : null,
        $line('FCF yield', $v['fcfYield'] ?? null, '%'),
        $line('Payout (din profit)', $v['payout'] ?? null, '%'),
        $line('Dividend yield', $p['dividendYield'] ?? null, '%'),
    ]);
    // Technicals
    $techRows = array_filter([
        $line('RSI', $t['rsi14'] ?? null),
        $line('Poziție în intervalul 52 săpt.', $t['position52w'] ?? null, '%'),
        isset($t['aboveMA50']) ? ('Față de media 50 zile: ' . ($t['aboveMA50'] ? 'peste' : 'sub')) : null,
        isset($t['aboveMA200']) ? ('Față de media 200 zile: ' . ($t['aboveMA200'] ? 'peste' : 'sub')) : null,
        $line('Randament 1 an', $t['momentum1y'] ?? null, '%'),
    ]);
    $name = trim(($p['name'] ?? '') . ' (' . ($p['symbol'] ?? '?') . ')');
    $sector = $p['sector'] ?? 'necunoscut';
    if ($isReit) $sector .= ' (REIT — folosește FFO/P-FFO, nu P/E)';
    $flags = (isset($sc['flags']) && is_array($sc['flags'])) ? array_slice($sc['flags'], 0, 8) : [];
    $scoreLine = isset($sc['final']) ? ('Scorul intern al aplicației: ' . round($sc['final']) . '/100 (' . ($sc['verdict'] ?? '') . ')'
        . (isset($sc['quality']) ? ' — calitate ' . round($sc['quality']) . ', evaluare ' . round($sc['valuation']) . ', creștere ' . round($sc['growth']) . ', sănătate ' . round($sc['health']) . ', momentum ' . round($sc['momentum']) . ', risc ' . round($sc['risk'] ?? 0) : '')
        . (!empty($sc['uncertain']) ? ' [SCOR MARCAT INCERT]' : '')) : '';
    return "Ești un analist financiar prudent care explică pe înțelesul unui investitor obișnuit. "
        . "Datele de mai jos sunt extrase AUTOMAT din rapoarte (SEC EDGAR / Yahoo) și pot conține erori de extragere.\n\n"
        . "COMPANIE: $name · Sector: $sector · Perioadă: " . ($f['period'] ?? 'recentă') . "\n"
        . ($scoreLine ? $scoreLine . "\n" : '')
        . ($flags ? 'Semnale detectate de aplicație: ' . implode('; ', $flags) . "\n" : '')
        . "\nBILANȚ & PROFIT: " . implode(', ', $rows)
        . "\nEVALUARE: " . implode(', ', $valRows)
        . "\nTEHNIC: " . implode(', ', $techRows)
        . "\n\nRăspunde în limba română, structurat, maxim ~170 de cuvinte:\n"
        . "1) VERIFICARE DATE: spune dacă vreo cifră pare GREȘITĂ sau inconsistentă (ex: P/E foarte diferit de P/E din EPS, equity negativ, ROE absurd, creștere imposibilă, marje nerealiste). Dacă totul pare plauzibil, spune-o pe scurt.\n"
        . "2) PUNCTE FORTE și RISCURI principale (câte 1-2).\n"
        . "3) RECOMANDARE clară — alege EXACT una: CUMPĂRĂ / AȘTEAPTĂ / EVITĂ — și explică în 1-2 fraze de ce, ținând cont de preț (evaluare), calitate și risc.\n"
        . "Fii echilibrat și concret. Nu repeta lista de cifre. Nu e sfat financiar profesionist, ci o opinie educativă.";
}
function csv_assoc($csv) {
    $lines = preg_split('/\r\n|\r|\n/', trim($csv));
    if (count($lines) < 2) return [];
    $header = str_getcsv(array_shift($lines));
    $rows = [];
    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $values = str_getcsv($line);
        if (count($values) < count($header)) continue;
        $rows[] = array_combine($header, array_slice($values, 0, count($header)));
    }
    return $rows;
}
function num($v) {
    if ($v === null || $v === '' || $v === 'N/D' || $v === '-') return null;
    if (is_numeric($v)) return (float)$v;
    $v = str_replace([',','%'], '', (string)$v);
    return is_numeric($v) ? (float)$v : null;
}
function pct($new, $old) {
    if ($new === null || $old === null || abs($old) < 0.000001) return null;
    return (($new - $old) / abs($old)) * 100.0;
}
function universe() {
    $path = __DIR__ . '/../data/universe.json';
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : [];
}
function find_universe($symbol) {
    $symbol = strtoupper($symbol);
    foreach (universe() as $row) if (strtoupper($row['symbol']) === $symbol) return $row;
    return null;
}
function stooq_symbol($symbol, $meta = null) {
    if ($meta && !empty($meta['stooq'])) return strtolower($meta['stooq']);
    $s = strtolower(str_replace('.', '-', $symbol));
    if (strpos($s, '.') === false) $s .= '.us';
    return $s;
}
function yahoo_symbol($symbol, $meta = null) {
    if ($meta && !empty($meta['yahoo'])) return strtoupper($meta['yahoo']);
    return strtoupper($symbol);
}
function asset_type($meta) {
    $sector = strtolower($meta['sector'] ?? '');
    $industry = strtolower($meta['industry'] ?? '');
    if ($sector === 'etf' || strpos($industry, 'etf') !== false) return 'ETF';
    if (strpos($industry, 'reit') !== false || $sector === 'real estate') return 'REIT';
    return 'Stock';
}
function region_of($meta) {
    $c = strtoupper($meta['country'] ?? 'US');
    return $c === 'US' ? 'US' : 'EU';
}
function yahoo_dividend_info($symbol, $price, $config) {
    $meta = find_universe($symbol);
    $ys = yahoo_symbol($symbol, $meta);
    $url = 'https://query1.finance.yahoo.com/v8/finance/chart/' . rawurlencode($ys) . '?range=1y&interval=1d&events=div';
    try {
        $json = http_get($url, (int)($config['cache_seconds_history'] ?? 900), ['Accept: application/json']);
    } catch (Throwable $e) { return ['ttmDividend'=>null, 'yield'=>null, 'payments'=>0]; }
    $res = json_decode($json, true)['chart']['result'][0] ?? null;
    $divs = $res['events']['dividends'] ?? [];
    $sum = 0.0; $n = 0;
    foreach ($divs as $d) { if (isset($d['amount'])) { $sum += (float)$d['amount']; $n++; } }
    return [
        'ttmDividend' => $sum > 0 ? $sum : null,
        'yield' => ($price && $sum > 0) ? ($sum / $price * 100) : null,
        'payments' => $n,
    ];
}
// Best share count for market cap. SEC's CommonStockSharesOutstanding can under-count multi-class firms,
// which halves market cap and breaks P/E, P/S, FCF yield. EPS-implied shares (NetIncome/EPS_diluted) match the
// share base the market uses, so we trust it when it diverges materially upward.
function best_share_count($fund) {
    $shares = $fund['sharesOutstanding'] ?? null;
    $eps = $fund['epsDiluted'] ?? null; $ni = $fund['netIncome'] ?? null;
    $implied = ($eps && abs($eps) > 0.001 && $ni) ? abs($ni / $eps) : null;
    if ($implied !== null && $implied > 0) {
        if ($shares === null) return $implied;
        // correct upward when SEC clearly under-counts (1.15×–6× range avoids garbage from tiny/odd EPS)
        if ($implied > $shares * 1.15 && $implied < $shares * 6) return $implied;
    }
    return $shares;
}
// Resolve market cap robustly. Yahoo's reported marketCap is authoritative (handles dual-class like BRK.B);
// fall back to shares×price, but if the two diverge a lot, trust Yahoo's figure.
function resolve_market_cap($fund, $price) {
    $shares = best_share_count($fund);
    $computed = ($shares && $price) ? $shares * $price : null;
    $reported = (isset($fund['marketCap']) && is_numeric($fund['marketCap']) && $fund['marketCap'] > 0) ? (float)$fund['marketCap'] : null;
    if ($reported !== null) {
        if ($computed === null) return $reported;
        if (abs($computed - $reported) / $reported > 0.25) return $reported; // computed is off (shares mismatch) → trust Yahoo
        return $computed;
    }
    return $computed;
}
function valuation_metrics($mcap, $fund, $income, $price) {
    $net = $fund['netIncome'] ?? null;
    $eq = $fund['equity'] ?? null;
    $rev = $fund['revenue'] ?? null;
    $eps = $fund['epsDiluted'] ?? null;
    $fcf = $fund['freeCashFlow'] ?? null;
    $ebitda = $fund['ebitda'] ?? null;
    $totalDebt = $fund['totalDebt'] ?? null;
    $cash = $fund['cash'] ?? null;
    $ffo = $fund['ffo'] ?? null;
    $ffoPerShare = $fund['ffoPerShare'] ?? null;
    $ttmDiv = $income['ttmDividend'] ?? null;
    // Enterprise Value = market cap + total debt − cash; EV/EBITDA works even when the firm is loss-making (P/E doesn't)
    $ev = $mcap ? ($mcap + ($totalDebt ?? 0) - ($cash ?? 0)) : null;
    // Our SEC-derived P/E (market cap ÷ annual net income) and the directly-reported EPS-based P/E
    $peSec = ($mcap && $net && $net > 0) ? $mcap / $net : null;
    $peEps = ($price && $eps && $eps > 0) ? $price / $eps : null;
    // Yahoo's trailing P/E + EPS = the market standard (TTM). Use as authoritative reference when available.
    $yahooPE = (isset($fund['yahooPE']) && is_numeric($fund['yahooPE']) && $fund['yahooPE'] > 0) ? (float)$fund['yahooPE'] : null;
    $yahooEPS = (isset($fund['yahooEPS']) && is_numeric($fund['yahooEPS'])) ? (float)$fund['yahooEPS'] : null;
    // Market is actually loss-making on a TTM basis (e.g. recent writedown) even though the last SEC annual showed a profit.
    $marketLoss = ($yahooEPS !== null && $yahooEPS < 0);
    $peSecOnlyProfit = ($peSec !== null && $peSec > 0 && $marketLoss);
    // "P/E conflict": our SEC-based P/E differs from the market's (Yahoo TTM) by >20%, or SEC shows profit while the market shows a loss.
    $peConflict = $peSecOnlyProfit || ($peSec !== null && $yahooPE !== null && abs($peSec - $yahooPE) / $yahooPE > 0.20);
    // Displayed/scored P/E: the market TTM value when available; null when the market is loss-making; else EPS- or SEC-based.
    $peDisplayed = $marketLoss ? null : ($yahooPE !== null ? $yahooPE : ($peEps !== null ? $peEps : $peSec));
    $peUncertain = $peConflict || ($peSec !== null && $peEps !== null && min($peSec, $peEps) > 0 && abs($peSec - $peEps) / min($peSec, $peEps) > 0.30);
    // Market-cap sanity: P/S below ~0.05 (mcap tiny vs revenue) or P/E near zero on a profitable firm ⇒ market cap is almost certainly wrong.
    $marketCapSuspect = ($mcap !== null && $rev !== null && $rev > 1e8 && $mcap < $rev * 0.05)
        || ($peSec !== null && $peSec > 0 && $peSec < 1 && $net > 1e7);
    return [
        'pe'        => $peDisplayed,                 // the P/E we show/score (market TTM when available)
        'peSec'     => $peSec,                       // our SEC-annual computed P/E (cross-check)
        'marketPE'  => $yahooPE,                     // Yahoo's trailing P/E (market standard)
        'peConflict'=> $peConflict,
        'peSecOnlyProfit' => $peSecOnlyProfit,
        'marketLoss' => $marketLoss,
        'marketCapSuspect' => $marketCapSuspect,
        'peFromEps' => $peEps,
        'peUncertain' => $peUncertain,
        'pb'        => ($mcap && $eq && $eq > 0) ? $mcap / $eq : null,
        'ps'        => ($mcap && $rev && $rev > 0) ? $mcap / $rev : null,
        'evEbitda'  => ($ev !== null && $ebitda && $ebitda > 0) ? $ev / $ebitda : null,
        'pFcf'      => ($mcap && $fcf && $fcf > 0) ? $mcap / $fcf : null,           // Price/FCF — the non-REIT cash-flow multiple
        'pFfo'      => ($mcap && $ffo && $ffo > 0) ? $mcap / $ffo : null,           // REIT equivalent of P/E (only shown/scored for REITs)
        'ffoPayout' => ($ffoPerShare && $ffoPerShare > 0 && $ttmDiv) ? $ttmDiv / $ffoPerShare * 100 : null, // dividend vs FFO/share
        'fcfYield'  => ($mcap && $fcf) ? $fcf / $mcap * 100 : null,
        'payout'    => ($eps && $eps > 0 && $ttmDiv) ? $ttmDiv / $eps * 100 : null,
        'freeCashFlow' => $fcf,
        'peNeg'     => (($net !== null && $net <= 0) || $marketLoss), // loss-making (SEC or market TTM) → P/E intentionally null
    ];
}
function verdict($final, $confidence, $flags = [], $health = 50) {
    $hard = count(array_filter($flags, fn($f) => stripos($f, 'negativ') !== false || stripos($f, 'scădere') !== false));
    // Weak financial health gets a visible warning even if price/momentum lift the score.
    $weak = ($health < 40);
    $warn = $weak ? ' ⚠ Sănătate financiară slabă — verifică datoriile și fluxul de numerar.' : '';
    if ($final >= 75 && $confidence >= 55 && $hard === 0 && !$weak) return ['label'=>'Candidat puternic pentru analiză', 'tone'=>'good', 'text'=>'Scor ridicat, fundamente solide, fără red flags majore. Bun pentru watchlist și due diligence (10-K/10-Q).'];
    if ($final >= 60) return ['label'=>($weak?'Mixt — calitate bună, dar bilanț slab':'Merită analizat, dar verifică riscurile'), 'tone'=>($weak?'mid':'good'), 'text'=>'Profil peste medie. Verifică red flags, sectorul și prețul de intrare înainte de decizie.'.$warn];
    if ($final >= 45) return ['label'=>'Neutru / doar watchlist', 'tone'=>'mid', 'text'=>'Nimic care să iasă clar în evidență. Mai bine aștepți un setup mai bun.'.$warn];
    return ['label'=>'Risc ridicat / evită până la clarificare', 'tone'=>'bad', 'text'=>'Scor slab sau prea multe red flags. Risc/randament nefavorabil acum.'.$warn];
}
function yahoo_chart_raw($yahooSymbol, $range, $interval, $cacheSeconds) {
    $url = 'https://query1.finance.yahoo.com/v8/finance/chart/' . rawurlencode($yahooSymbol) . '?range=' . $range . '&interval=' . $interval;
    $json = http_get($url, (int)$cacheSeconds, ['Accept: application/json']);
    $data = json_decode($json, true);
    $res = $data['chart']['result'][0] ?? null;
    if (!$res || !isset($res['meta'])) throw new Exception('No Yahoo data for ' . $yahooSymbol);
    return $res;
}
function stooq_quote($symbol, $config) {
    $meta = find_universe($symbol);
    $ys = yahoo_symbol($symbol, $meta);
    $res = yahoo_chart_raw($ys, '5d', '1d', $config['cache_seconds_quote'] ?? 60);
    $m = $res['meta'];
    $close = num($m['regularMarketPrice'] ?? null);
    if ($close === null) throw new Exception('No Yahoo quote for ' . $symbol);
    $prev = isset($m['chartPreviousClose']) ? num($m['chartPreviousClose']) : null;
    $t = $m['regularMarketTime'] ?? null;
    return [
        'symbol' => strtoupper($symbol),
        'name' => $meta['name'] ?? ($m['shortName'] ?? strtoupper($symbol)),
        'sector' => $meta['sector'] ?? '',
        'industry' => $meta['industry'] ?? '',
        'country' => $meta['country'] ?? '',
        'exchange' => $meta['exchange'] ?? ($m['fullExchangeName'] ?? ''),
        'source' => 'Yahoo Finance',
        'currency' => $m['currency'] ?? ($meta['currency'] ?? 'USD'),
        'assetType' => asset_type($meta),
        'providerSymbol' => $ys,
        'date' => $t ? date('Y-m-d', $t) : '',
        'time' => $t ? date('H:i:s', $t) : '',
        'price' => $close,
        'open' => $prev,
        'high' => num($m['regularMarketDayHigh'] ?? null),
        'low' => num($m['regularMarketDayLow'] ?? null),
        'volume' => num($m['regularMarketVolume'] ?? null),
        'changePct' => pct($close, $prev),
    ];
}
function stooq_history($symbol, $config) {
    $meta = find_universe($symbol);
    $ys = yahoo_symbol($symbol, $meta);
    $res = yahoo_chart_raw($ys, '2y', '1d', $config['cache_seconds_history'] ?? 900);
    $ts = $res['timestamp'] ?? [];
    $q = $res['indicators']['quote'][0] ?? [];
    $out = [];
    foreach ($ts as $i => $t) {
        $c = isset($q['close'][$i]) ? num($q['close'][$i]) : null;
        if ($c === null) continue;
        $out[] = [
            'date' => date('Y-m-d', $t),
            'open' => num($q['open'][$i] ?? null),
            'high' => num($q['high'][$i] ?? null),
            'low' => num($q['low'][$i] ?? null),
            'close' => $c,
            'volume' => num($q['volume'][$i] ?? null),
        ];
    }
    return $out;
}
// Full score for a scan row, so the scanner matches the company detail exactly.
// One combined Yahoo call (2y bars + dividends) + one SEC call, both cached.
function parse_yahoo_bars_divs($body) {
    $res = $body ? (json_decode($body, true)['chart']['result'][0] ?? null) : null;
    if (!$res) return null;
    $ts = $res['timestamp'] ?? []; $q = $res['indicators']['quote'][0] ?? []; $bars = [];
    foreach ($ts as $i => $t) {
        $c = isset($q['close'][$i]) ? num($q['close'][$i]) : null;
        if ($c === null) continue;
        $bars[] = ['date'=>date('Y-m-d',$t),'open'=>num($q['open'][$i]??null),'high'=>num($q['high'][$i]??null),'low'=>num($q['low'][$i]??null),'close'=>$c,'volume'=>num($q['volume'][$i]??null)];
    }
    $divs = $res['events']['dividends'] ?? []; $cut = time() - 370*86400; $sum = 0.0;
    foreach ($divs as $d) { if (isset($d['amount']) && ($d['date'] ?? 0) >= $cut) $sum += (float)$d['amount']; }
    return ['bars'=>$bars, 'ttmDividend'=>$sum > 0 ? $sum : null];
}
// Full-score a pool of scan rows in parallel (one curl_multi batch), so the scan matches the detail.
function full_score_pool($pool, $config, $strategy = 'balanced') {
    $ua = trim($config['sec_user_agent'] ?? 'InvestIQFreeLive2026 contact@example.com');
    $reqs = []; $yurlOf = []; $surlOf = [];
    foreach ($pool as $r) {
        $sym = $r['symbol']; $meta = find_universe($sym);
        $ys = yahoo_symbol($sym, $meta);
        $yurl = 'https://query1.finance.yahoo.com/v8/finance/chart/' . rawurlencode($ys) . '?range=2y&interval=1d&events=div';
        $yurlOf[$sym] = $yurl;
        $reqs[] = ['url'=>$yurl, 'headers'=>['Accept: application/json'], 'cache'=>(int)($config['cache_seconds_history'] ?? 900)];
        if (!empty($meta['cik'])) {
            $cik = str_pad(preg_replace('/\D/', '', $meta['cik']), 10, '0', STR_PAD_LEFT);
            $surl = 'https://data.sec.gov/api/xbrl/companyfacts/CIK' . $cik . '.json';
            $surlOf[$sym] = $surl;
            $reqs[] = ['url'=>$surl, 'headers'=>['Accept: application/json', 'User-Agent: ' . $ua], 'cache'=>(int)($config['cache_seconds_sec'] ?? 86400)];
        }
    }
    $bodies = http_get_multi($reqs);
    // Authoritative market caps for the whole pool in one parallel round (fixes dual-class undercount like ARES/BRK.B). Cached 1 day.
    $poolMcaps = yahoo_market_caps_batch(array_map(fn($r)=>$r['symbol'], $pool), $config);
    foreach ($pool as $idx => $r) {
        $sym = $r['symbol']; $price = $r['price'] ?? null;
        $bd = parse_yahoo_bars_divs($bodies[$yurlOf[$sym]] ?? null);
        if (!$bd || count($bd['bars']) < 30) continue;
        $tech = technicals(array_slice($bd['bars'], -420));
        $fund = isset($surlOf[$sym]) ? sec_fundamentals($sym, $config, $bodies[$surlOf[$sym]] ?? null) : ['available'=>false];
        $income = ['ttmDividend'=>$bd['ttmDividend'], 'yield'=>($price && $bd['ttmDividend']) ? $bd['ttmDividend']/$price*100 : null];
        $mcap = resolve_market_cap($fund, $price);
        // Prefer Yahoo's authoritative market cap + market trailing P/E (catches dual-class undercount and SEC-vs-market P/E conflicts).
        $yrec = $poolMcaps[$sym] ?? ($poolMcaps[strtoupper($sym)] ?? null);
        $ymc = is_array($yrec) ? ($yrec['mcap'] ?? null) : $yrec;
        if (empty($fund['marketCap']) && $ymc && ($mcap === null || abs($mcap - $ymc) / $ymc > 0.20)) { $mcap = $ymc; $fund['marketCap'] = $ymc; }
        $fund['yahooPE'] = is_array($yrec) ? ($yrec['pe'] ?? null) : null;
        $fund['yahooEPS'] = is_array($yrec) ? ($yrec['eps'] ?? null) : null;
        $val = valuation_metrics($mcap, $fund, $income, $price);
        $secLow = strtolower($r['sector'] ?? '');
        $isReit = ($secLow === 'real estate') || (($r['assetType'] ?? '') === 'REIT');
        if ($secLow === 'financial services' || ($r['assetType'] ?? '') === 'REIT') { $val['fcfYield']=null; $val['freeCashFlow']=null; }
        $pool[$idx]['score'] = score_company($r, $tech, $fund, $income, $val, $strategy);
        $pool[$idx]['marketCap'] = $mcap;
        $pool[$idx]['dividendYield'] = $income['yield'];
        $pool[$idx]['position52w'] = $tech['position52w'] ?? ($r['position52w'] ?? null);
        $pool[$idx]['fullScored'] = true;
        // Attach the full scanned metrics (Yahoo + SEC) so the list/export can show everything, not just the score
        $pool[$idx]['metrics'] = [
            'pe'=>$val['pe']??null, 'peSec'=>$val['peSec']??null, 'peConflict'=>$val['peConflict']??false, 'peNeg'=>$val['peNeg']??false, 'marketLoss'=>$val['marketLoss']??false,
            'pb'=>$val['pb']??null, 'ps'=>$val['ps']??null, 'evEbitda'=>$val['evEbitda']??null, 'pFcf'=>$val['pFcf']??null,
            'pFfo'=>$val['pFfo']??null, 'ffoPayout'=>$val['ffoPayout']??null, 'isReit'=>$isReit,
            'fcfYield'=>$val['fcfYield']??null, 'payout'=>$val['payout']??null,
            'revenue'=>$fund['revenue']??null, 'netIncome'=>$fund['netIncome']??null,
            'profitMargin'=>$fund['profitMargin']??null, 'ebitMargin'=>$fund['ebitMargin']??null,
            'roe'=>$fund['roe']??null, 'debtEquity'=>$fund['debtEquity']??null,
            'netDebtEbitda'=>$fund['netDebtEbitda']??null, 'equityRatio'=>$fund['equityRatio']??null,
            'revenueGrowth'=>$fund['revenueGrowth']??null, 'freeCashFlow'=>$fund['freeCashFlow']??null,
            'ebitda'=>$fund['ebitda']??null, 'totalDebt'=>$fund['totalDebt']??null,
            'netDebt'=>$fund['netDebt']??null, 'cash'=>$fund['cash']??null,
            'assets'=>$fund['assets']??null, 'liabilities'=>$fund['liabilities']??null, 'equity'=>$fund['equity']??null,
            'ffo'=>$fund['ffo']??null, 'interestCoverage'=>$fund['interestCoverage']??null,
            'rsi14'=>$tech['rsi14']??null, 'aboveMA50'=>$tech['aboveMA50']??null, 'aboveMA200'=>$tech['aboveMA200']??null,
            'momentum1y'=>$tech['momentum1y']??null, 'period'=>$fund['period']??null,
            'currency'=>$fund['currency']??($r['currency']??'USD'), 'fundSource'=>$fund['source']??null, 'fundAvailable'=>!empty($fund['available']),
        ];
    }
    return $pool;
}
function moving_avg($values, $n) {
    if (count($values) < $n) return null;
    $slice = array_slice($values, -$n);
    return array_sum($slice) / $n;
}
function rsi($closes, $period = 14) {
    if (count($closes) <= $period) return null;
    $slice = array_slice($closes, -($period + 1));
    $g = 0; $l = 0;
    for ($i=1; $i<count($slice); $i++) {
        $d = $slice[$i] - $slice[$i-1];
        if ($d >= 0) $g += $d; else $l += abs($d);
    }
    if ($l == 0) return 100;
    $rs = ($g / $period) / ($l / $period);
    return 100 - (100 / (1 + $rs));
}
function technicals($history) {
    $closes = array_values(array_filter(array_map(fn($r) => num($r['close'] ?? null), $history), fn($v) => $v !== null));
    $n = count($closes);
    if ($n < 30) return ['confidence' => 25];
    $last = $closes[$n-1];
    $ma50 = moving_avg($closes, 50);
    $ma200 = moving_avg($closes, 200);
    $p30 = $n > 30 ? pct($last, $closes[$n-31]) : null;
    $p90 = $n > 90 ? pct($last, $closes[$n-91]) : null;
    $p252 = $n > 252 ? pct($last, $closes[$n-253]) : null;
    $hi52 = $n > 252 ? max(array_slice($closes, -252)) : max($closes);
    $lo52 = $n > 252 ? min(array_slice($closes, -252)) : min($closes);
    $pos52 = ($hi52 - $lo52) > 0 ? (($last - $lo52) / ($hi52 - $lo52)) * 100 : null;
    return [
        'last' => $last,
        'ma50' => $ma50,
        'ma200' => $ma200,
        'rsi14' => rsi($closes),
        'momentum30d' => $p30,
        'momentum90d' => $p90,
        'momentum1y' => $p252,
        'position52w' => $pos52,
        'high52w' => $hi52,
        'low52w' => $lo52,
        'aboveMA50' => $ma50 ? $last > $ma50 : null,
        'aboveMA200' => $ma200 ? $last > $ma200 : null,
        'confidence' => min(95, 30 + min(65, $n / 4)),
    ];
}
function sec_latest($facts, $concept, $unit = null) {
    if (!isset($facts['facts']['us-gaap'][$concept]['units'])) return null;
    $units = $facts['facts']['us-gaap'][$concept]['units'];
    if ($unit && isset($units[$unit])) $candidates = $units[$unit];
    else {
        $first = reset($units);
        $candidates = $first ?: [];
    }
    $filtered = array_filter($candidates, function($x) {
        return isset($x['val']) && isset($x['end']) && (!isset($x['form']) || in_array($x['form'], ['10-K','10-Q','20-F','40-F']));
    });
    usort($filtered, fn($a,$b) => strcmp($b['end'] ?? '', $a['end'] ?? ''));
    return $filtered ? ['value'=>num($filtered[0]['val']), 'end'=>$filtered[0]['end'] ?? '', 'form'=>$filtered[0]['form'] ?? ''] : null;
}
function sec_annual($facts, $concept, $unit = null) {
    if (!isset($facts['facts']['us-gaap'][$concept]['units'])) return null;
    $units = $facts['facts']['us-gaap'][$concept]['units'];
    $cand = ($unit && isset($units[$unit])) ? $units[$unit] : (reset($units) ?: []);
    $f = array_values(array_filter($cand, function($x) {
        if (!isset($x['val']) || !isset($x['end'])) return false;
        if (isset($x['form']) && !in_array($x['form'], ['10-K','20-F','40-F'])) return false;
        if (isset($x['start'])) { $d = (strtotime($x['end']) - strtotime($x['start'])) / 86400; if ($d < 300) return false; }
        return true;
    }));
    usort($f, fn($a,$b) => strcmp($b['end'] ?? '', $a['end'] ?? ''));
    return $f ? ['value'=>num($f[0]['val']), 'end'=>$f[0]['end'] ?? ''] : null;
}
// Pick the annual value across several concepts with the MOST RECENT period end
// (companies switch XBRL tags over time, e.g. Revenues -> RevenueFromContract..., leaving stale old tags).
function sec_annual_best($facts, $concepts, $unit = 'USD') {
    $best = null;
    foreach ($concepts as $c) {
        $v = sec_annual($facts, $c, $unit);
        if (!$v) continue;
        if ($best === null || strcmp($v['end'], $best['end']) > 0 || ($v['end'] === $best['end'] && ($v['value'] ?? 0) > ($best['value'] ?? 0))) $best = $v;
    }
    return $best;
}
function sec_series_best($facts, $concepts, $unit = 'USD') {
    $best = []; $bestEnd = '';
    foreach ($concepts as $c) {
        $s = sec_series($facts, $c, $unit);
        if (!$s) continue;
        $end = $s[count($s)-1]['end'] ?? '';
        if (strcmp($end, $bestEnd) > 0) { $best = $s; $bestEnd = $end; }
    }
    return $best;
}
function sec_series($facts, $concept, $unit = null) {
    if (!isset($facts['facts']['us-gaap'][$concept]['units'])) return [];
    $units = $facts['facts']['us-gaap'][$concept]['units'];
    $candidates = $unit && isset($units[$unit]) ? $units[$unit] : (reset($units) ?: []);
    $out=[];
    foreach ($candidates as $x) {
        if (!isset($x['val']) || !isset($x['end'])) continue;
        if (isset($x['form']) && !in_array($x['form'], ['10-K','20-F','40-F'])) continue;
        $out[] = ['value'=>num($x['val']), 'end'=>$x['end']];
    }
    usort($out, fn($a,$b)=>strcmp($a['end'], $b['end']));
    return $out;
}
// ---- Yahoo authenticated GET (needs cookie + crumb). Shared by quoteSummary + fundamentals-timeseries.
function yahoo_ua() { return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Safari/537.36'; }
function yahoo_crumb($force = false) {
    if (!function_exists('curl_init')) return '';
    $ua = yahoo_ua();
    $cookieFile = cache_path('yahoo_cookiejar');
    $crumbFile = cache_path('yahoo_crumb');
    if (!$force && file_exists($crumbFile) && (time() - filemtime($crumbFile)) < 3600) {
        $c = trim(@file_get_contents($crumbFile));
        if ($c !== '' && stripos($c, '<') === false) return $c;
    }
    $ch = curl_init('https://fc.yahoo.com');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_COOKIEJAR=>$cookieFile, CURLOPT_COOKIEFILE=>$cookieFile, CURLOPT_USERAGENT=>$ua, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>true]);
    curl_exec($ch); curl_close($ch);
    $ch = curl_init('https://query1.finance.yahoo.com/v1/test/getcrumb');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_COOKIEJAR=>$cookieFile, CURLOPT_COOKIEFILE=>$cookieFile, CURLOPT_USERAGENT=>$ua, CURLOPT_TIMEOUT=>12]);
    $crumb = trim((string)curl_exec($ch)); curl_close($ch);
    if ($crumb !== '' && stripos($crumb, '<') === false) @file_put_contents($crumbFile, $crumb);
    return $crumb;
}
function yahoo_crumbed_get($url) {
    if (!function_exists('curl_init')) return null;
    $ua = yahoo_ua();
    $cookieFile = cache_path('yahoo_cookiejar');
    $do = function($crumb) use ($ua, $cookieFile, $url) {
        $u = $url . (strpos($url, '?') !== false ? '&' : '?') . 'crumb=' . rawurlencode($crumb);
        $ch = curl_init($u);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_COOKIEJAR=>$cookieFile, CURLOPT_COOKIEFILE=>$cookieFile, CURLOPT_USERAGENT=>$ua, CURLOPT_TIMEOUT=>15, CURLOPT_HTTPHEADER=>['Accept: application/json']]);
        $body = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$status, $body];
    };
    $crumb = yahoo_crumb(false);
    if ($crumb === '') return null;
    list($status, $body) = $do($crumb);
    if ($status === 401 || $status === 403 || ($body && stripos($body, 'Invalid Cookie') !== false)) {
        $crumb = yahoo_crumb(true); // stale crumb — refresh once
        if ($crumb === '') return null;
        list($status, $body) = $do($crumb);
    }
    return ($status >= 400 || !$body) ? null : $body;
}
function yahoo_quote_summary($yahooSymbol, $modules, $config) {
    $url = 'https://query2.finance.yahoo.com/v10/finance/quoteSummary/' . rawurlencode($yahooSymbol) . '?modules=' . rawurlencode($modules);
    $body = yahoo_crumbed_get($url);
    if (!$body) return null;
    $j = json_decode($body, true);
    $res = $j['quoteSummary']['result'] ?? null;
    return ($res && isset($res[0])) ? $res[0] : null;
}
// Fetch the latest reported value for each balance-sheet / cash-flow line from Yahoo's fundamentals-timeseries.
function yahoo_timeseries_latest($yahooSymbol, $types) {
    $p2 = time(); $p1 = $p2 - 220000000; // ~7 years back
    $url = 'https://query2.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/' . rawurlencode($yahooSymbol)
        . '?symbol=' . rawurlencode($yahooSymbol) . '&type=' . rawurlencode($types) . '&period1=' . $p1 . '&period2=' . $p2 . '&merge=false';
    $body = yahoo_crumbed_get($url);
    if (!$body) return [];
    $j = json_decode($body, true);
    $res = $j['timeseries']['result'] ?? [];
    $out = [];
    foreach ($res as $item) {
        $type = $item['meta']['type'][0] ?? null;
        if (!$type || empty($item[$type]) || !is_array($item[$type])) continue;
        $vals = array_filter($item[$type], fn($v) => is_array($v) && isset($v['reportedValue']['raw']));
        if (!$vals) continue;
        $last = end($vals);
        $out[$type] = $last['reportedValue']['raw'];
    }
    return $out;
}
// Authoritative market cap + market trailing P/E from Yahoo (quoteSummary 'summaryDetail'). Cached 1 day.
// Returns ['mcap'=>float|null, 'pe'=>float|null].
function yahoo_market_info($symbol, $config) {
    if (empty($config['enable_yahoo_fallback'])) return ['mcap'=>null, 'pe'=>null];
    $meta = find_universe($symbol);
    $ys = yahoo_symbol($symbol, $meta);
    $cacheFile = cache_path('yminfo_' . $ys);
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
        $d = json_decode(@file_get_contents($cacheFile), true);
        if (is_array($d)) return $d;
    }
    $r = yahoo_quote_summary($ys, 'summaryDetail,defaultKeyStatistics', $config);
    $rec = ['mcap'=>null, 'pe'=>null, 'eps'=>null];
    if ($r) {
        $parsed = yahoo_parse_market_info(json_encode(['quoteSummary'=>['result'=>[$r]]]));
        if ($parsed) $rec = $parsed;
    }
    if ($rec['mcap'] !== null || $rec['pe'] !== null || $rec['eps'] !== null) @file_put_contents($cacheFile, json_encode($rec));
    return $rec;
}
// Parse market cap + trailing P/E + trailing EPS from a quoteSummary result (summaryDetail + defaultKeyStatistics).
function yahoo_parse_market_info($body) {
    $j = json_decode($body, true);
    $res = $j['quoteSummary']['result'][0] ?? null;
    if (!is_array($res)) return null;
    $sd = $res['summaryDetail'] ?? []; $ks = $res['defaultKeyStatistics'] ?? [];
    $raw = function($a, $k) { $v = $a[$k] ?? null; return is_array($v) ? ($v['raw'] ?? null) : $v; };
    $mc = $raw($sd, 'marketCap'); $pe = $raw($sd, 'trailingPE'); $eps = $raw($ks, 'trailingEps');
    return ['mcap'=>($mc && $mc > 0) ? (float)$mc : null, 'pe'=>($pe && $pe > 0) ? (float)$pe : null, 'eps'=>(is_numeric($eps) ? (float)$eps : null)];
}
// Parallel authoritative market cap + trailing P/E from Yahoo, with cookie+crumb. Cached 1 day. One round for the whole pool.
// Returns map sym => ['mcap'=>float|null, 'pe'=>float|null] (Yahoo's reported market-standard trailing P/E).
function yahoo_market_caps_batch($symbols, $config) {
    if (empty($config['enable_yahoo_fallback']) || !function_exists('curl_multi_init')) return [];
    $out = []; $toFetch = [];
    foreach (array_unique($symbols) as $sym) {
        $meta = find_universe($sym); $ys = yahoo_symbol($sym, $meta);
        $cf = cache_path('yminfo_' . $ys);
        if (file_exists($cf) && (time() - filemtime($cf)) < 86400) { $d = json_decode(@file_get_contents($cf), true); if (is_array($d)) { $out[$sym] = $d; continue; } }
        $toFetch[$sym] = $ys;
    }
    if (!$toFetch) return $out;
    $crumb = yahoo_crumb(false);
    if ($crumb === '') return $out;
    $ua = yahoo_ua(); $cookieFile = cache_path('yahoo_cookiejar');
    $mh = curl_multi_init(); $handles = [];
    foreach ($toFetch as $sym => $ys) {
        $url = 'https://query2.finance.yahoo.com/v10/finance/quoteSummary/' . rawurlencode($ys) . '?modules=summaryDetail,defaultKeyStatistics&crumb=' . rawurlencode($crumb);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_COOKIEFILE=>$cookieFile, CURLOPT_USERAGENT=>$ua, CURLOPT_TIMEOUT=>18, CURLOPT_HTTPHEADER=>['Accept: application/json']]);
        curl_multi_add_handle($mh, $ch); $handles[$sym] = $ch;
    }
    $running = null;
    do { curl_multi_exec($mh, $running); curl_multi_select($mh, 1.0); } while ($running > 0);
    foreach ($handles as $sym => $ch) {
        $body = curl_multi_getcontent($ch); $st = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_multi_remove_handle($mh, $ch); curl_close($ch);
        if ($st < 400 && $body) {
            $rec = yahoo_parse_market_info($body);
            if ($rec) { $out[$sym] = $rec; @file_put_contents(cache_path('yminfo_' . $toFetch[$sym]), json_encode($rec)); }
        }
    }
    curl_multi_close($mh);
    return $out;
}
// Yahoo fundamentals fallback: maps quoteSummary to the same shape as sec_fundamentals. TTM figures.
function yahoo_fundamentals($symbol, $config) {
    if (empty($config['enable_yahoo_fallback'])) return ['available'=>false, 'source'=>'Yahoo Finance', 'reason'=>'Yahoo fallback dezactivat'];
    $meta = find_universe($symbol);
    $ys = yahoo_symbol($symbol, $meta);
    $cacheFile = cache_path('yfund_' . $ys);
    $cs = (int)($config['cache_seconds_sec'] ?? 86400);
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cs) {
        $cached = json_decode(@file_get_contents($cacheFile), true);
        // schema gate: ignore caches written by older code (missing timeseries balance-sheet fields)
        if (is_array($cached) && ($cached['schema'] ?? 0) >= 4) return $cached;
    }
    $r = yahoo_quote_summary($ys, 'financialData,defaultKeyStatistics,summaryDetail', $config);
    if (!$r) return ['available'=>false, 'source'=>'Yahoo Finance', 'reason'=>'quoteSummary indisponibil (simbol negăsit sau Yahoo a blocat cererea)'];
    $fd = $r['financialData'] ?? []; $ks = $r['defaultKeyStatistics'] ?? []; $sd = $r['summaryDetail'] ?? [];
    $raw = function($a, $k) { $v = $a[$k] ?? null; return is_array($v) ? ($v['raw'] ?? null) : $v; };
    // Authoritative market cap reported by Yahoo — correct for dual-class (BRK) and special cases where shares×price breaks.
    $marketCap = $raw($sd, 'marketCap');
    $revenue = $raw($fd, 'totalRevenue');
    $netIncome = $raw($ks, 'netIncomeToCommon');
    $ebitda = $raw($fd, 'ebitda');
    $profitMargins = $raw($fd, 'profitMargins');
    $operatingMargins = $raw($fd, 'operatingMargins');
    $roe = $raw($fd, 'returnOnEquity');
    $cash = $raw($fd, 'totalCash');
    $totalDebt = $raw($fd, 'totalDebt');
    $de = $raw($fd, 'debtToEquity'); // Yahoo gives this as a percentage
    $growth = $raw($fd, 'revenueGrowth');
    $fcf = $raw($fd, 'freeCashflows');
    $shares = $raw($ks, 'sharesOutstanding');
    $bookValue = $raw($ks, 'bookValue'); // book value per share
    $eps = $raw($ks, 'trailingEps');
    $equityDerived = ($bookValue !== null && $shares) ? $bookValue * $shares : null;
    $netDebt = ($totalDebt !== null) ? ($totalDebt - ($cash ?? 0)) : null;
    // FFO ≈ Net Income + D&A; D&A derived from EBITDA − EBIT (Yahoo doesn't expose D&A directly)
    $ebitDerived = ($operatingMargins !== null && $revenue) ? $operatingMargins * $revenue : null;
    $daDerived = ($ebitda !== null && $ebitDerived !== null) ? ($ebitda - $ebitDerived) : null;
    $ffo = ($netIncome !== null && $daDerived !== null) ? ($netIncome + $daDerived) : null;
    $ffoPerShare = ($ffo !== null && $shares) ? ($ffo / $shares) : null;
    // Real balance-sheet + FCF from fundamentals-timeseries (quoteSummary no longer returns these)
    $ts = yahoo_timeseries_latest($ys, 'annualTotalAssets,annualTotalLiabilitiesNetMinorityInterest,annualStockholdersEquity,trailingFreeCashFlow,annualFreeCashFlow');
    $assets = $ts['annualTotalAssets'] ?? null;
    $liabilities = $ts['annualTotalLiabilitiesNetMinorityInterest'] ?? null;
    // Prefer the reported equity from the balance sheet; fall back to bookValue × shares
    $equity = $ts['annualStockholdersEquity'] ?? $equityDerived;
    // Derive any still-missing balance-sheet leg from the accounting identity Assets = Liabilities + Equity
    if ($assets === null && $liabilities !== null && $equity !== null) $assets = $liabilities + $equity;
    if ($liabilities === null && $assets !== null && $equity !== null) $liabilities = $assets - $equity;
    if ($equity === null && $assets !== null && $liabilities !== null) $equity = $assets - $liabilities;
    if ($fcf === null) $fcf = $ts['trailingFreeCashFlow'] ?? ($ts['annualFreeCashFlow'] ?? null);
    $equityRatio = ($equity !== null && $assets) ? ($equity / $assets * 100) : null;
    $out = [
        'available'=>($revenue !== null || $netIncome !== null || $ebitda !== null),
        'schema'=>4,
        'source'=>'Yahoo Finance',
        'cik'=>null,
        'sharesOutstanding'=>$shares,
        'marketCap'=>$marketCap,
        'period'=>'TTM',
        'revenue'=>$revenue,
        'netIncome'=>$netIncome,
        'assets'=>$assets,
        'liabilities'=>$liabilities,
        'equity'=>$equity,
        'cash'=>$cash,
        'longTermDebt'=>$totalDebt,
        'totalDebt'=>$totalDebt,
        'epsDiluted'=>$eps,
        'freeCashFlow'=>$fcf,
        'profitMargin'=>($profitMargins !== null) ? $profitMargins * 100 : null,
        'roe'=>($roe !== null) ? $roe * 100 : null,
        'debtEquity'=>($de !== null) ? $de / 100 : null,
        'revenueGrowth'=>($growth !== null) ? $growth * 100 : null,
        'ebit'=>null,
        'ebitMargin'=>($operatingMargins !== null) ? $operatingMargins * 100 : null,
        'ebitda'=>$ebitda,
        'netDebt'=>$netDebt,
        'netDebtEbitda'=>($ebitda && $ebitda > 0 && $netDebt !== null) ? ($netDebt / $ebitda) : null,
        'equityRatio'=>$equityRatio,
        'da'=>$daDerived,
        'interestExpense'=>null,
        'interestCoverage'=>null,
        'ffo'=>$ffo,
        'ffoPerShare'=>$ffoPerShare,
        'currency'=>$raw($fd, 'financialCurrency'),
    ];
    if (!empty($out['available'])) @file_put_contents($cacheFile, json_encode($out));
    else $out['reason'] = 'quoteSummary fără date financiare utile';
    return $out;
}
function sec_fundamentals($symbol, $config, $preJson = false) {
    $meta = find_universe($symbol);
    if (!$meta || empty($meta['cik'])) return ['available'=>false, 'source'=>'SEC EDGAR', 'reason'=>'CIK missing in local universe'];
    $cik = str_pad(preg_replace('/\D/', '', $meta['cik']), 10, '0', STR_PAD_LEFT);
    if ($preJson === false) {
        $ua = trim($config['sec_user_agent'] ?? 'InvestIQFreeLive2026 contact@example.com');
        $url = 'https://data.sec.gov/api/xbrl/companyfacts/CIK' . $cik . '.json';
        $json = http_get($url, (int)($config['cache_seconds_sec'] ?? 86400), ['Accept: application/json', 'User-Agent: ' . $ua]);
    } else {
        $json = $preJson; // pre-fetched body (or null if the parallel fetch failed)
    }
    $facts = $json ? json_decode($json, true) : null;
    if (!$facts) return ['available'=>false, 'source'=>'SEC EDGAR', 'reason'=>'Invalid SEC response'];
    // Income-statement & cash-flow items: use ANNUAL (10-K) values so ratios aren't distorted by quarterly figures
    $revConcepts = ['RevenueFromContractWithCustomerExcludingAssessedTax','Revenues','SalesRevenueNet','RevenueFromContractWithCustomerIncludingAssessedTax'];
    $rev = sec_annual_best($facts, $revConcepts, 'USD');
    $net = sec_annual($facts, 'NetIncomeLoss', 'USD');
    $eps = sec_annual($facts, 'EarningsPerShareDiluted', 'USD/shares');
    $ocf = sec_annual($facts, 'NetCashProvidedByUsedInOperatingActivities', 'USD');
    $capex = sec_annual($facts, 'PaymentsToAcquirePropertyPlantAndEquipment', 'USD');
    $ebit = sec_annual($facts, 'OperatingIncomeLoss', 'USD');
    $da = sec_annual($facts, 'DepreciationDepletionAndAmortization', 'USD') ?: sec_annual($facts, 'DepreciationAmortizationAndAccretionNet', 'USD') ?: sec_annual($facts, 'DepreciationAndAmortization', 'USD');
    // Balance-sheet items are point-in-time: latest snapshot is correct
    $assets = sec_latest($facts, 'Assets', 'USD');
    $liab = sec_latest($facts, 'Liabilities', 'USD');
    $equity = sec_latest($facts, 'StockholdersEquity', 'USD') ?: sec_latest($facts, 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest', 'USD');
    $cash = sec_latest($facts, 'CashAndCashEquivalentsAtCarryingValue', 'USD') ?: sec_latest($facts, 'CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents', 'USD');
    $debt = sec_latest($facts, 'LongTermDebt', 'USD') ?: sec_latest($facts, 'LongTermDebtAndFinanceLeaseObligations', 'USD');
    $debtCurrent = sec_latest($facts, 'LongTermDebtCurrent', 'USD') ?: sec_latest($facts, 'DebtCurrent', 'USD');
    $fcf = (($ocf['value'] ?? null) !== null) ? ($ocf['value'] - ($capex['value'] ?? 0)) : null;
    // Derived: EBIT margin, EBITDA, Net Debt/EBITDA, Equity ratio
    $ebitV = $ebit['value'] ?? null;
    $ebitda = ($ebitV !== null && ($da['value'] ?? null) !== null) ? ($ebitV + $da['value']) : null;
    $totalDebt = (($debt['value'] ?? null) !== null) ? ($debt['value'] + ($debtCurrent['value'] ?? 0)) : null;
    $revSeries = sec_series_best($facts, $revConcepts, 'USD');
    $growth = null;
    if (count($revSeries) >= 2) {
        $last = $revSeries[count($revSeries)-1]['value'];
        $prev = $revSeries[count($revSeries)-2]['value'];
        $growth = pct($last, $prev);
    }
    $revenue = $rev['value'] ?? null; $netIncome = $net['value'] ?? null; $eq = $equity['value'] ?? null;
    $shares = null;
    if (isset($facts['facts']['dei']['EntityCommonStockSharesOutstanding']['units']['shares'])) {
        $sh = $facts['facts']['dei']['EntityCommonStockSharesOutstanding']['units']['shares'];
        usort($sh, fn($a,$b)=>strcmp($b['end'] ?? '', $a['end'] ?? ''));
        $shares = num($sh[0]['val'] ?? null);
    }
    if ($shares === null) {
        $cso = sec_latest($facts, 'CommonStockSharesOutstanding', 'shares');
        $shares = $cso['value'] ?? null;
    }
    // REIT-relevant: FFO (Funds From Operations) ≈ Net Income + Depreciation&Amortization; interest coverage = EBIT ÷ interest expense
    $interest = sec_annual($facts, 'InterestExpense', 'USD') ?: sec_annual($facts, 'InterestExpenseDebt', 'USD') ?: sec_annual($facts, 'InterestAndDebtExpense', 'USD');
    $interestV = $interest['value'] ?? null;
    $ffo = ($netIncome !== null && ($da['value'] ?? null) !== null) ? ($netIncome + $da['value']) : null;
    $ffoPerShare = ($ffo !== null && $shares) ? ($ffo / $shares) : null;
    $interestCoverage = ($ebitV !== null && $interestV && $interestV > 0) ? ($ebitV / $interestV) : null;
    // Cap absurd interest coverage (interest expense ≈ 0 ⇒ thousands×) — 100×+ just means "no debt burden"
    if ($interestCoverage !== null && $interestCoverage > 100) $interestCoverage = 100;
    return [
        'available'=>true,
        'source'=>'SEC EDGAR',
        'cik'=>$cik,
        'sharesOutstanding'=>$shares,
        'period'=>$rev['end'] ?? ($net['end'] ?? ''),
        'revenue'=>$revenue,
        'netIncome'=>$netIncome,
        'assets'=>$assets['value'] ?? null,
        'liabilities'=>$liab['value'] ?? null,
        'equity'=>$eq,
        'cash'=>$cash['value'] ?? null,
        'longTermDebt'=>$debt['value'] ?? null,
        'totalDebt'=>$totalDebt,
        'epsDiluted'=>$eps['value'] ?? null,
        'freeCashFlow'=>$fcf,
        'profitMargin'=>$revenue ? ($netIncome / $revenue * 100) : null,
        'roe'=>$eq ? ($netIncome / $eq * 100) : null,
        // Debt/Equity = financial debt ÷ equity (consistent with Yahoo + the score thresholds; not dependent on the often-missing Liabilities tag)
        'debtEquity'=>($eq && $eq > 0 && $totalDebt !== null) ? ($totalDebt / $eq) : null,
        'revenueGrowth'=>$growth,
        'ebit'=>$ebitV,
        'ebitMargin'=>($revenue && $ebitV !== null) ? ($ebitV / $revenue * 100) : null,
        'ebitda'=>$ebitda,
        'netDebt'=>($totalDebt !== null) ? ($totalDebt - ($cash['value'] ?? 0)) : null,
        'netDebtEbitda'=>($ebitda && $ebitda > 0 && $totalDebt !== null) ? (($totalDebt - ($cash['value'] ?? 0)) / $ebitda) : null,
        'equityRatio'=>($eq !== null && ($assets['value'] ?? null)) ? ($eq / $assets['value'] * 100) : null,
        'da'=>$da['value'] ?? null,
        'interestExpense'=>$interestV,
        'interestCoverage'=>$interestCoverage,
        'ffo'=>$ffo,
        'ffoPerShare'=>$ffoPerShare,
    ];
}
function clamp_score($v) { return max(0, min(100, round($v, 1))); }
function score_company($quote, $tech, $fund, $income = null, $val = null, $strategy = 'balanced') {
    $quality = 50; $valuation = 50; $growth = 50; $health = 50; $momentum = 50; $dividend = 40; $risk = 0; $confidence = 45; $flags = []; $explain = [];
    $sectorL = strtolower($quote['sector'] ?? '');
    $isReit = (($quote['assetType'] ?? '') === 'REIT') || $sectorL === 'real estate';
    $isUtility = $sectorL === 'utilities';
    $isFin = ($sectorL === 'financial services') || (($quote['assetType'] ?? '') === 'REIT');
    // P/E comes from valuation_metrics: $val['pe'] is the market TTM P/E when available (null if market is loss-making).
    $price = $quote['price'] ?? null;
    $peEff = $val['pe'] ?? null;            // market-standard P/E used for scoring/display
    $peSec = $val['peSec'] ?? null;         // our SEC-annual cross-check
    $marketPE = $val['marketPE'] ?? null;
    $peConflict = !empty($val['peConflict']);
    $peUncertain = !empty($val['peUncertain']);
    // SEC shows a profit but the market is loss-making on a TTM basis (recent writedown) — valuation on profit doesn't apply.
    if (!empty($val['peSecOnlyProfit'])) { $flags[] = 'P/E conflict — SEC arată profit (P/E ' . round($peSec,1) . ') dar piața e pe pierdere pe TTM (EPS TTM negativ, probabil writedown); P/E pe profit nu se aplică'; $confidence -= 12; }
    // ROE/P-B become meaningless when equity is tiny or negative (buybacks, accumulated deficits): don't treat as quality.
    $eqVal = $fund['equity'] ?? null; $erVal = $fund['equityRatio'] ?? null; $roeVal = $fund['roe'] ?? null; $pbVal = $val['pb'] ?? null;
    $roeDistorted = ($roeVal !== null && (abs($roeVal) > 60))
        || ($pbVal !== null && ($pbVal > 20 || $pbVal < 0))
        || ($erVal !== null && $erVal < 10)
        || ($eqVal !== null && $eqVal <= 0);
    $growthBad = false; $missingKeys = 0; // set inside the fundamentals block; initialised here for the uncertainty check
    // INVALID DATA: market cap clearly wrong ⇒ every multiple is garbage. Don't score valuation; flag the company.
    $mcapBad = !empty($val['marketCapSuspect']);
    if ($mcapBad) { $flags[] = '⛔ DATE INVALIDE — market cap/preț par greșite, evaluarea (P/E, P/B, P/S) nu e de încredere; scor de evaluare neutru'; $confidence -= 25; }
    if (!$mcapBad && $isReit && ($val['pFfo'] ?? null) !== null) {
        // REIT: evaluare pe P/FFO (echivalentul P/E), nu pe P/E — profitul net e distorsionat de amortizare
        $pffo = $val['pFfo']; $confidence += 8;
        if ($pffo < 13) { $valuation += 22; $explain[] = 'P/FFO scăzut (' . round($pffo,1) . ') — REIT ieftin față de cash-flow.'; }
        elseif ($pffo < 18) { $valuation += 10; $explain[] = 'P/FFO rezonabil (' . round($pffo,1) . ').'; }
        elseif ($pffo < 22) { $valuation += 0; $explain[] = 'P/FFO ridicat (' . round($pffo,1) . ').'; }
        else { $valuation -= 14; $explain[] = 'P/FFO mare (' . round($pffo,1) . ') — REIT scump.'; }
        // La REIT, sustenabilitatea dividendului se judecă pe FFO payout, nu pe profitul net (care iese mereu >100%)
        if (($val['ffoPayout'] ?? null) !== null) {
            if ($val['ffoPayout'] > 100) $flags[] = 'FFO payout peste 100% — dividendul depășește FFO (nesustenabil)';
            elseif ($val['ffoPayout'] < 90) { $dividend += 6; $explain[] = 'FFO payout sub 90% — dividend acoperit confortabil.'; }
        }
    } elseif (!$mcapBad && $peEff !== null) {
        $pe = $peEff; $confidence += 8;  // market TTM P/E
        // P/E conflict (our SEC P/E vs the market's differ a lot): use the market P/E but don't hand out a big valuation bonus on a contested number.
        if ($peConflict) {
            $flags[] = 'P/E conflict — piață (TTM) ' . ($marketPE !== null ? round($marketPE,1) : '—') . ' vs SEC ' . ($peSec !== null ? round($peSec,1) : '—') . ' (an fiscal vs TTM/one-off); folosesc valoarea de piață, fără bonus automat';
            $confidence -= 12;
        }
        if ($pe < 12) { $valuation += ($peConflict ? 10 : 24); $explain[] = 'P/E scăzut (' . round($pe,1) . ') — evaluare atractivă.'; }
        elseif ($pe < 20) { $valuation += 12; $explain[] = 'P/E rezonabil (' . round($pe,1) . ').'; }
        elseif ($pe < 30) { $valuation += 0; $explain[] = 'P/E ridicat (' . round($pe,1) . ') — piața cere creștere.'; }
        elseif ($pe < 50) { $valuation -= 14; $explain[] = 'P/E mare (' . round($pe,1) . ') — scump, riscant fără creștere puternică.'; }
        else { $valuation -= 24; $flags[] = 'P/E foarte mare (>50) — evaluare exigentă'; }
        if (($val['pb'] ?? null) !== null && $val['pb'] < 1.5 && !$roeDistorted) $valuation += 6;
        // Extreme multiples = speculative/growth, not a normal value case — extra penalty + flag (e.g. very high P/E AND EV/EBITDA).
        $evb = $val['evEbitda'] ?? null;
        if (($pe > 60) || ($evb !== null && $evb > 50)) { $valuation -= 10; $risk += 6; $flags[] = 'Evaluare speculativă — multipli extremi (P/E ' . round($pe) . ($evb!==null?'×, EV/EBITDA '.round($evb).'×':'×') . '); de tratat ca growth, nu ca valoare'; }
        // FCF yield: not a clean quality signal for utilities (lumpy regulated capex) — only reward for normal firms
        if (!$isUtility && ($val['fcfYield'] ?? null) !== null && $val['fcfYield'] > 5) { $quality += 6; $explain[] = 'Free cash flow yield bun (' . round($val['fcfYield'],1) . '%).'; }
        // Expensive on a cash basis: high P/E AND very low FCF yield ⇒ quality shouldn't fully lift the score (e.g. great-but-pricey defensives).
        if (!$isUtility && !$isReit && !$isFin && ($val['fcfYield'] ?? null) !== null && $val['fcfYield'] < 2.5 && $peEff !== null && $peEff > 22) {
            $valuation -= 8; $flags[] = 'Scumpă pe cash-flow — FCF yield ' . round($val['fcfYield'],1) . '% și P/E ' . round($peEff) . '; calitatea bună e deja în preț';
        }
        if (($val['payout'] ?? null) !== null && $val['payout'] > 100 && !$isReit) $flags[] = 'Payout peste 100% — dividendul depășește profitul (nesustenabil pe termen lung)';
    }
    $dy = $income['yield'] ?? null;
    if ($dy !== null) {
        $confidence += 6;
        if ($dy >= 2 && $dy <= 9) { $dividend += min(35, $dy * 5); $explain[] = 'Dividend yield aproximativ ' . round($dy, 2) . '% (din plățile ultimelor 12 luni).'; }
        elseif ($dy > 9) { $dividend += 15; $flags[] = 'Yield foarte mare (>9%) — verifică sustenabilitatea dividendului'; }
        // Dividend is an advantage only if SUSTAINABLE: an unsustainable payout (>100%) is a risk, not a plus.
        $payoutV = $isReit ? ($val['ffoPayout'] ?? null) : ($val['payout'] ?? null);
        if ($payoutV !== null) {
            if ($payoutV > 100) { $dividend -= 22; $risk += 5; $flags[] = 'Dividend nesustenabil — payout ' . round($payoutV) . '% (peste profit' . ($isReit?'/FFO':'') . '); risc de tăiere'; }
            elseif ($payoutV > 90) { $dividend -= 8; $flags[] = 'Payout ridicat (' . round($payoutV) . '%) — marjă mică de siguranță pentru dividend'; }
        }
    }
    if (!empty($fund['available'])) {
        $confidence += 25;
        if (($fund['profitMargin'] ?? null) !== null) { $quality += min(25, max(-20, $fund['profitMargin'])); $explain[] = 'Profit margin din SEC: ' . round($fund['profitMargin'],1) . '%'; }
        // ROE counts as quality only when it's economically meaningful (not blown up by a tiny equity base)
        if (($fund['roe'] ?? null) !== null) {
            if ($roeDistorted) { $flags[] = 'ROE/P-B distorsionate de capital propriu foarte mic — nerelevante ca semn de calitate'; $confidence -= 5; }
            else { $quality += min(20, max(-20, $fund['roe'] / 1.5)); }
        }
        // Banks/insurers (financial services) are leveraged by design — Debt/Equity & Net Debt/EBITDA aren't comparable to industrials.
        if (($fund['debtEquity'] ?? null) !== null && !$isFin) { $health += $fund['debtEquity'] < 1 ? 18 : ($fund['debtEquity'] < 2 ? 5 : -20); if ($fund['debtEquity'] > 2 && !$isUtility) $flags[] = 'Datorii mari față de equity'; }
        // Net Debt/EBITDA — key leverage gauge (especially utilities/REITs). Higher thresholds for capital-intensive sectors. N/A for financials.
        $nde = $fund['netDebtEbitda'] ?? null;
        if ($nde !== null && $nde > 0 && !$isFin) {
            $hi = ($isUtility || $isReit) ? 7 : 4.5; $mid = ($isUtility || $isReit) ? 5 : 3;
            if ($nde > $hi) { $health -= 14; $risk += 6; $flags[] = '⚠ Datorie grea: Net Debt/EBITDA ' . round($nde,1) . '×'; }
            elseif ($nde > 5) { $health -= 6; $risk += 3; $flags[] = '⚠ Net Debt/EBITDA ridicat (' . round($nde,1) . '×)' . (($isUtility||$isReit) ? ' — frecvent la sector, dar sensibil la dobânzi' : ' — datorie mare'); }
            elseif ($nde < $mid) { $health += 6; }
        }
        // Net cash (more cash than debt) is a balance-sheet strength — small bonus.
        $netDebtV = $fund['netDebt'] ?? null;
        if ($netDebtV !== null && $netDebtV < 0 && !$isFin) { $health += 8; $explain[] = 'Poziție de cash net (mai mult cash decât datorii) — bilanț solid.'; }
        // Interest coverage — can the firm pay its interest? Critical for leveraged utilities/REITs.
        $ic = $fund['interestCoverage'] ?? null;
        if ($ic !== null) {
            if ($ic < 2) { $health -= 16; $risk += 9; $flags[] = '⚠ Acoperirea dobânzii slabă (' . round($ic,1) . '×) — abia își plătește dobânzile'; }
            elseif ($ic < 3) { $health -= 5; $risk += 3; $flags[] = '⚠ Acoperirea dobânzii sub 3× (' . round($ic,1) . '×) — marjă mică la dobânzi'; }
            elseif ($ic > 5) { $health += 6; }
        }
        // Revenue growth sanity: implausible values (< -50% or > 150% on a real revenue base) are almost always XBRL mis-extraction. Don't score them.
        $rg = $fund['revenueGrowth'] ?? null;
        $growthBad = ($rg !== null && ($rg < -50 || $rg > 150) && ($fund['revenue'] ?? 0) > 1e8);
        if ($rg !== null && !$growthBad) { $growth += max(-25, min(25, $rg)); $explain[] = 'Revenue growth aproximat: ' . round($rg,1) . '%'; if ($rg < -5) $flags[] = 'Venituri în scădere'; }
        elseif ($growthBad) { $flags[] = 'Creștere ' . round($rg) . '% — probabil one-off / base effect (an anterior pe pierdere, restructurare sau extragere XBRL eronată); ignorată, NU recompensată'; $confidence -= 6; }
        if (($fund['profitMargin'] ?? 0) < 0) $flags[] = 'Profitabilitate negativă în ultimul raport SEC';
        // Solvency backstop via equity ratio — catches highly-leveraged firms even when Debt/Equity is missing. Skipped for banks.
        $er = $fund['equityRatio'] ?? null;
        if ($er !== null && !$isFin) {
            if ($isUtility) {
                // Utilities are leveraged by nature (~30% equity is normal); only flag EXTREME thin capitalization (below ~12%).
                if ($er < 12) { $health -= 18; $risk += 6; $flags[] = 'Capitalizare foarte subțire chiar și pentru o utilitate (equity ratio ' . round($er,1) . '%)'; }
                elseif ($er < 20) { $health -= 6; }
            } else {
                if ($er >= 50) { $health += 12; }
                elseif ($er >= 30) { $health += 4; }
                elseif ($er >= 15) { $health -= 12; $flags[] = 'Capital propriu modest față de active (equity ratio ' . round($er) . '%)'; }
                else { $health -= 26; $risk += 6; $flags[] = 'Firmă fragil capitalizată — equity ratio sub 15% (' . round($er,1) . '%)'; }
                // High ROE on a thin equity base is leverage, not quality — temper it and flag it.
                if ($er < 20 && ($fund['roe'] ?? 0) > 15 && !$roeDistorted) { $quality -= 10; $flags[] = 'ROE umflat de datorii (bază mică de capital propriu)'; }
            }
        }
        // Negative free cash flow: a red flag for normal firms; softer for utilities (lumpy regulated capex), suppressed for banks/REITs.
        $fcfVal = $fund['freeCashFlow'] ?? null;
        if ($fcfVal !== null && $fcfVal < 0 && !$isFin) {
            if ($isUtility) { $risk += 6; $health -= 8; $flags[] = '⚠ Utility cu FCF negativ — des din capex reglementat, dar verifică Net Debt/EBITDA și acoperirea dobânzii înainte să o consideri „de analizat"'; }
            else { $risk += 12; $health -= 8; $flags[] = 'Free cash flow negativ — firma arde numerar'; }
        }
        // Heavily-indebted utility (high Net Debt/EBITDA) gets a visible warning even if leverage is "normal" for the sector.
        if ($isUtility && ($fund['netDebtEbitda'] ?? null) !== null && $fund['netDebtEbitda'] > 6) { $health -= 8; $flags[] = '⚠ Utility cu datorie mare (Net Debt/EBITDA ' . round($fund['netDebtEbitda'],1) . '×) — sensibilă la dobânzi'; }
        // Negative equity (accumulated deficit / heavy buybacks) = distorted balance sheet → cap health hard.
        if ($eqVal !== null && $eqVal < 0) { $health = min($health, 20); $flags[] = 'Capital propriu negativ — bilanț distorsionat (ROE/P-B nerelevante)'; }
        // Missing key data must NOT read as zero risk — incomplete fundamentals = uncertainty.
        // For financials, leverage metrics legitimately don't apply, so judge completeness on income-statement metrics instead.
        $keyMetrics = $isFin ? ['profitMargin','roe','revenueGrowth'] : ['netDebtEbitda','debtEquity','ebitda','freeCashFlow','equityRatio'];
        $missingKeys = 0;
        foreach ($keyMetrics as $mk) if (($fund[$mk] ?? null) === null) $missingKeys++;
        if (($val['pe'] ?? null) === null && ($val['pFfo'] ?? null) === null) $missingKeys++;
        // Confidence must drop for EVERY important missing metric — can't claim near-100% certainty on incomplete data.
        if ($missingKeys > 0) $confidence -= $missingKeys * 6;
        if ($missingKeys >= 3) { $risk += 7; $flags[] = 'Date financiare incomplete (' . $missingKeys . ' indicatori-cheie lipsă) — scor mai puțin sigur'; }
        // VALUE TRAP: a tempting yield backed by weak fundamentals (risky payout, heavy debt, weak balance sheet).
        $dyV = $income['yield'] ?? null; $payoutVT = $isReit ? ($val['ffoPayout'] ?? null) : ($val['payout'] ?? null);
        if ($dyV !== null && $dyV >= 3.5) {
            $trapReasons = [];
            if ($payoutVT !== null && $payoutVT > 90) $trapReasons[] = 'payout ' . round($payoutVT) . '%';
            if (($fund['netDebtEbitda'] ?? null) !== null && $fund['netDebtEbitda'] > 4) $trapReasons[] = 'Net Debt/EBITDA ' . round($fund['netDebtEbitda'],1) . '×';
            if ($eqVal !== null && $eqVal < 0) $trapReasons[] = 'equity negativ';
            if (($fund['revenueGrowth'] ?? null) !== null && !$growthBad && $fund['revenueGrowth'] < -3) $trapReasons[] = 'venituri în scădere';
            if (count($trapReasons) >= 1 && $health < 50) { $risk += 5; $flags[] = '⚠ Posibilă capcană de valoare (value trap) — yield ' . round($dyV,1) . '% dar fundamente slabe: ' . implode(', ', $trapReasons); }
        }
    } else {
        $flags[] = 'Fundamente SEC indisponibile pentru acest ticker/univers';
    }
    if (($tech['aboveMA50'] ?? null) !== null) { $momentum += $tech['aboveMA50'] ? 12 : -12; if (!$tech['aboveMA50']) $flags[] = 'Sub media mobilă de 50 zile'; }
    if (($tech['aboveMA200'] ?? null) !== null) { $momentum += $tech['aboveMA200'] ? 16 : -18; if (!$tech['aboveMA200']) $flags[] = 'Sub media mobilă de 200 zile'; }
    if (($tech['momentum90d'] ?? null) !== null) $momentum += max(-20, min(20, $tech['momentum90d'] / 2));
    // 52w position contributes less (it overlaps with the MA signals and a high position is partly "stretched price", not pure momentum)
    if (($tech['position52w'] ?? null) !== null) $momentum += (($tech['position52w'] - 50) / 5);
    $pos = $tech['position52w'] ?? null; $rsiV = $tech['rsi14'] ?? null;
    // Near the 52w high but without short-term momentum confirmation (neutral RSI) = stretched price, not a strong uptrend — cap it.
    if ($pos !== null && $pos > 85 && $rsiV !== null && $rsiV < 58) { $momentum = min($momentum, 82); $explain[] = 'Aproape de maxim 52s dar RSI neutru (' . round($rsiV) . ') — momentum tratat prudent (preț posibil întins).'; }
    if ($pos !== null && $pos > 92) { $risk += 4; }
    if ($rsiV !== null) {
        if ($rsiV > 75) { $risk += 8; $flags[] = 'RSI foarte ridicat / posibil supra-cumpărat'; }
        if ($rsiV < 30) { $risk += 6; $flags[] = 'RSI foarte scăzut / posibil falling knife'; }
    }
    if (($quote['volume'] ?? 0) !== null && $quote['volume'] < 250000) { $risk += 12; $flags[] = 'Volum redus'; }
    // Cheap-looking but crashing: strong fundamentals + price near 52w low / no momentum = possible "falling knife" — flag, don't just reward valuation.
    if ($valuation >= 60 && $pos !== null && $pos < 20 && $momentum < 35) { $risk += 5; $flags[] = 'Pare ieftină dar prețul e în cădere (lângă minim 52s, fără momentum) — verifică motivul (posibil „falling knife")'; }
    $confidence += (($tech['confidence'] ?? 0) / 4);
    $quality = clamp_score($quality); $valuation = clamp_score($valuation); $growth = clamp_score($growth); $health = clamp_score($health); $momentum = clamp_score($momentum); $dividend = clamp_score($dividend);
    // Fundamental scanner: quality + financial health dominate; momentum is a secondary factor, not the main driver.
    $opportunity = ($quality*.23 + $valuation*.14 + $growth*.12 + $health*.20 + $momentum*.15 + $dividend*.08 + 50*.08);
    if ($strategy === 'opportunity') {
        // "Oportunități cu perspectivă": ieftin (valuation) + afacere bună (quality) + creștere, momentum contează puțin
        $opportunity = $valuation*.27 + $quality*.22 + $growth*.18 + $health*.15 + $dividend*.06 + $momentum*.12;
        // sinergie: ieftin ȘI de calitate = oportunitatea reală (nu „capcană de valoare")
        if ($valuation >= 60 && $quality >= 58) { $opportunity += min(9, (($valuation-60)+($quality-58))/7); $explain[] = 'Combinație rară: ieftină și de calitate — posibilă oportunitate.'; }
        // bătută la pământ dar solidă fundamental = intrare la preț bun, cu spațiu de revenire
        $pos = $tech['position52w'] ?? null;
        if ($pos !== null && $pos < 45 && $quality >= 55 && $health >= 55) { $opportunity += min(6, (45-$pos)/6); $explain[] = 'Aproape de minimul de 52s, dar cu fundamente solide — potențial de revenire.'; }
    }
    $final = clamp_score($opportunity - $risk);
    // Red-flag override: weak financial health (high leverage, negative FCF, thin/negative equity) must NOT be masked
    // by strong momentum or cheap valuation. A fundamentally fragile company can't read as a strong candidate.
    if ($health < 35) { $final = min($final, 57); }            // capped out of "Interesant" territory
    if ($health < 22) { $final = min($final, 47); }            // weak balance sheet → "de evitat" zone
    if (($eqVal ?? null) !== null && $eqVal < 0) { $final = min($final, 45); } // negative equity = serious red flag
    if ($mcapBad) { $final = min($final, 45); }                // invalid valuation data — can't be a real candidate
    // Unsustainable dividend or extreme negative ROE can't read above the Neutru/risc zone without a clear justification.
    $payoutCap = $isReit ? ($val['ffoPayout'] ?? null) : ($val['payout'] ?? null);
    if (($payoutCap !== null && $payoutCap > 100) || ($roeVal !== null && $roeVal < -50)) { $final = min($final, 52); }
    $final = clamp_score($final);
    $conf = clamp_score($confidence);
    // "Scor incert": when key inputs are flagged uncertain/incomplete or confidence is low, the score shouldn't be read as firm.
    $uncertain = $mcapBad || $peUncertain || $growthBad || (($missingKeys ?? 0) >= 3) || $conf < 45;
    if ($uncertain) $flags[] = '⚠ Scor incert — unele date-cheie sunt incerte sau lipsă; tratează scorul cu rezervă';
    $flags = array_values(array_unique($flags));
    return [
        'final'=>$final,
        'quality'=>$quality,
        'valuation'=>$valuation,
        'growth'=>$growth,
        'health'=>$health,
        'momentum'=>$momentum,
        'dividend'=>$dividend,
        'riskPenalty'=>clamp_score($risk),
        'confidence'=>$conf,
        'uncertain'=>$uncertain,
        'flags'=>$flags,
        'explain'=>$explain,
        'verdict'=>verdict($final, $conf, $flags, $health),
    ];
}

function stooq_quotes_batch($symbols, $config) {
    $symbols = array_values(array_unique(array_filter($symbols)));
    if (!$symbols) return [];
    $map = [];
    $yahooList = [];
    foreach ($symbols as $symbol) {
        $meta = find_universe($symbol);
        $ys = yahoo_symbol($symbol, $meta);
        $yahooList[] = $ys;
        $map[strtoupper($ys)] = ['symbol'=>strtoupper($symbol), 'meta'=>$meta];
    }
    $out = [];
    foreach (array_chunk($yahooList, 20) as $chunk) {
        $url = 'https://query1.finance.yahoo.com/v7/finance/spark?symbols=' . rawurlencode(implode(',', $chunk)) . '&range=5d&interval=1d';
        try {
            $json = http_get($url, (int)($config['cache_seconds_quote'] ?? 60), ['Accept: application/json']);
        } catch (Throwable $e) { continue; }
        $data = json_decode($json, true);
        $results = $data['spark']['result'] ?? [];
        foreach ($results as $item) {
            $m = $item['response'][0]['meta'] ?? null;
            if (!$m) continue;
            $info = $map[strtoupper($m['symbol'] ?? '')] ?? null;
            if (!$info) continue;
            $close = num($m['regularMarketPrice'] ?? null);
            if ($close === null) continue;
            $prev = isset($m['chartPreviousClose']) ? num($m['chartPreviousClose']) : null;
            $hi52 = num($m['fiftyTwoWeekHigh'] ?? null);
            $lo52 = num($m['fiftyTwoWeekLow'] ?? null);
            $pos52 = ($hi52 !== null && $lo52 !== null && ($hi52 - $lo52) > 0) ? (($close - $lo52) / ($hi52 - $lo52)) * 100 : null;
            $meta = $info['meta'] ?: [];
            $t = $m['regularMarketTime'] ?? null;
            $out[$info['symbol']] = [
                'high52' => $hi52,
                'low52' => $lo52,
                'position52w' => $pos52,
                'symbol' => $info['symbol'],
                'name' => $meta['name'] ?? ($m['shortName'] ?? $info['symbol']),
                'sector' => $meta['sector'] ?? '',
                'industry' => $meta['industry'] ?? '',
                'country' => $meta['country'] ?? '',
                'exchange' => $meta['exchange'] ?? ($m['fullExchangeName'] ?? ''),
                'source' => 'Yahoo Finance batch',
                'currency' => $m['currency'] ?? ($meta['currency'] ?? 'USD'),
                'assetType' => asset_type($meta),
                'providerSymbol' => strtoupper($m['symbol'] ?? ''),
                'date' => $t ? date('Y-m-d', $t) : '',
                'time' => $t ? date('H:i:s', $t) : '',
                'price' => $close,
                'open' => $prev,
                'high' => num($m['regularMarketDayHigh'] ?? null),
                'low' => num($m['regularMarketDayLow'] ?? null),
                'volume' => num($m['regularMarketVolume'] ?? null),
                'changePct' => pct($close, $prev),
            ];
        }
    }
    return $out;
}
function quick_scan_score($quote, $meta, $strategy='balanced') {
    $sector = strtolower($meta['sector'] ?? $quote['sector'] ?? '');
    $change = $quote['changePct'] ?? 0;
    $volume = $quote['volume'] ?? null;
    $quality = 52; $valuation = 50; $growth = 50; $health = 52; $momentum = 50; $dividend = 40; $risk = 0; $confidence = 58; $flags=[]; $explain=[];
    $defensiveSectors = ['consumer defensive', 'healthcare', 'utilities'];
    if (in_array($sector, $defensiveSectors, true)) { $quality += 10; $health += 12; $explain[] = 'Sector defensiv: ' . ($meta['sector'] ?? ''); }
    if ($sector === 'real estate') { $dividend += 8; $explain[] = 'Expunere real estate / REIT-like din universul local.'; }
    if ($change !== null) { $momentum += max(-14, min(14, $change * 2)); }
    if ($volume !== null) {
        if ($volume < 250000) { $risk += 10; $flags[]='Volum redus'; }
        if ($volume > 1000000) { $confidence += 8; }
    } else { $confidence -= 8; $flags[]='Volum indisponibil'; }
    if (($quote['price'] ?? 0) < 5) { $risk += 15; $flags[]='Preț sub 5 USD'; }
    $quality=clamp_score($quality); $valuation=clamp_score($valuation); $growth=clamp_score($growth); $health=clamp_score($health); $momentum=clamp_score($momentum); $dividend=clamp_score($dividend);
    if ($strategy === 'defensive') $opportunity = $health*.38 + $quality*.34 + $momentum*.12 + $dividend*.08 + $confidence*.08;
    elseif ($strategy === 'momentum') $opportunity = $momentum*.65 + $confidence*.15 + $quality*.10 + $health*.10;
    elseif ($strategy === 'realestate') $opportunity = $dividend*.25 + $health*.25 + $quality*.20 + $momentum*.15 + $confidence*.15;
    // 'opportunity': pool larg, bazat pe calitate/sănătate, FĂRĂ a penaliza momentumul (ca firmele ieftine bătute la pământ să ajungă la scoringul complet, unde se uită la preț/fundamente)
    elseif ($strategy === 'opportunity') $opportunity = $quality*.34 + $health*.30 + $valuation*.12 + $dividend*.10 + $confidence*.14;
    else $opportunity = $quality*.20 + $valuation*.15 + $growth*.10 + $health*.20 + $momentum*.25 + $dividend*.05 + $confidence*.05;
    $final = clamp_score($opportunity - $risk);
    $conf = clamp_score($confidence);
    $flags = array_values(array_unique($flags));
    return [
        'final'=>$final,
        'quality'=>$quality,
        'valuation'=>$valuation,
        'growth'=>$growth,
        'health'=>$health,
        'momentum'=>$momentum,
        'dividend'=>$dividend,
        'riskPenalty'=>clamp_score($risk),
        'confidence'=>$conf,
        'flags'=>$flags,
        'explain'=>$explain,
        'verdict'=>verdict($final, $conf, $flags, $health),
    ];
}

function search_universe($q, $limit=30) {
    $q = strtolower($q);
    $rows=[];
    foreach (universe() as $r) {
        $hay = strtolower($r['symbol'].' '.$r['name'].' '.$r['sector'].' '.$r['industry']);
        if ($q === '' || strpos($hay, $q) !== false) $rows[]=$r;
        if (count($rows) >= $limit) break;
    }
    return $rows;
}
function yahoo_search($q, $config) {
    if (empty($config['enable_yahoo_fallback'])) return [];
    $url = 'https://query1.finance.yahoo.com/v1/finance/search?q=' . rawurlencode($q) . '&quotesCount=12&newsCount=0&listsCount=0';
    $json = http_get($url, (int)($config['cache_seconds_yahoo'] ?? 300), ['Accept: application/json']);
    $data = json_decode($json, true);
    $out=[];
    foreach (($data['quotes'] ?? []) as $x) {
        if (empty($x['symbol'])) continue;
        $out[] = [
            'symbol'=>$x['symbol'],
            'name'=>$x['shortname'] ?? ($x['longname'] ?? $x['symbol']),
            'sector'=>'', 'industry'=>'', 'country'=>'', 'exchange'=>$x['exchDisp'] ?? '',
            'stooq'=>strtolower(str_replace('.', '-', $x['symbol'])) . '.us',
            'cik'=>'', 'source'=>'Yahoo search fallback'
        ];
    }
    return $out;
}
$action = clean(q('action','status'), 40);
try {
    switch($action) {
        case 'status':
            json_response([
                'ok'=>true,
                'mode'=>'free-live-no-api-key',
                'sources'=>['Yahoo Finance chart/spark quotes & history','SEC EDGAR companyfacts'],
                'php'=>PHP_VERSION,
                'universeCount'=>count(universe()),
                'universeSource'=>'S&P 500 (listă oficială, sector GICS + CIK) + REIT-uri și ETF-uri europene/US adăugate',
                'cache'=>['quote'=>$config['cache_seconds_quote'],'history'=>$config['cache_seconds_history'],'sec'=>$config['cache_seconds_sec']],
            ]);
        case 'universe':
            json_response(['data'=>universe()]);
        case 'search':
            $term = clean(q('q',''), 80);
            $local = search_universe($term, 30);
            $yahoo=[];
            if ($term !== '') { try { $yahoo = yahoo_search($term, $config); } catch (Throwable $e) { $yahoo=[]; } }
            json_response(['data'=>array_values(array_merge($local, $yahoo)), 'localCount'=>count($local), 'fallbackCount'=>count($yahoo)]);
        case 'quote':
            $symbol = strtoupper(clean(q('symbol',''), 30));
            if (!$symbol) json_response(['error'=>'Missing symbol'], 400);
            json_response(['data'=>stooq_quote($symbol, $config)]);
        case 'chart':
            $symbol = strtoupper(clean(q('symbol',''), 30));
            $days = max(30, min(1500, (int)q('days',365)));
            if (!$symbol) json_response(['error'=>'Missing symbol'], 400);
            $history = stooq_history($symbol, $config);
            $history = array_slice($history, -$days);
            json_response(['data'=>$history, 'technicals'=>technicals($history), 'source'=>'Stooq']);
        case 'company':
            $symbol = strtoupper(clean(q('symbol',''), 30));
            if (!$symbol) json_response(['error'=>'Missing symbol'], 400);
            $quote = stooq_quote($symbol, $config);
            $history = array_slice(stooq_history($symbol, $config), -420);
            $tech = technicals($history);
            $fund = [];
            try { $fund = sec_fundamentals($symbol, $config); } catch(Throwable $e) { $fund = ['available'=>false,'source'=>'SEC EDGAR','reason'=>$e->getMessage()]; }
            // Fallback to Yahoo fundamentals when SEC has no data (non-US companies without CIK)
            if (empty($fund['available'])) {
                $secReason = $fund['reason'] ?? '';
                try {
                    $yf = yahoo_fundamentals($symbol, $config);
                    if (!empty($yf['available'])) $fund = $yf;
                    else $fund['reason'] = trim($secReason . ' · Yahoo: ' . ($yf['reason'] ?? 'indisponibil'), ' ·');
                } catch(Throwable $e) { /* keep SEC-unavailable result */ }
            }
            $income = yahoo_dividend_info($symbol, $quote['price'] ?? null, $config);
            $mcap = resolve_market_cap($fund, $quote['price'] ?? null);
            // Cross-check market cap + trailing P/E with Yahoo (the market standard). Fixes dual-class (BRK.B), missing shares (ABNB), and SEC-annual vs market-TTM P/E conflicts (STZ, CAG).
            $yinfo = ['mcap'=>null, 'pe'=>null];
            try { $yinfo = yahoo_market_info($symbol, $config); } catch (Throwable $e) {}
            if (empty($fund['marketCap']) && !empty($yinfo['mcap']) && ($mcap === null || abs($mcap - $yinfo['mcap']) / $yinfo['mcap'] > 0.20)) {
                $mcap = $yinfo['mcap']; $fund['marketCap'] = $yinfo['mcap'];
            }
            $fund['yahooPE'] = $yinfo['pe']; $fund['yahooEPS'] = $yinfo['eps'] ?? null;
            $quote['marketCap'] = $mcap;
            $valuation = valuation_metrics($mcap, $fund, $income, $quote['price'] ?? null);
            // FCF is not meaningful for banks/insurers/REITs (capex means something different there)
            $secLow = strtolower($quote['sector'] ?? '');
            if ($secLow === 'financial services' || ($quote['assetType'] ?? '') === 'REIT') { $valuation['fcfYield'] = null; $valuation['freeCashFlow'] = null; }
            $score = score_company($quote, $tech, $fund, $income, $valuation);
            json_response(['data'=>['quote'=>$quote,'history'=>$history,'technicals'=>$tech,'fundamentals'=>$fund,'income'=>$income,'valuation'=>$valuation,'score'=>$score]]);
        case 'diagnostics':
            $external = ['ok'=>false, 'message'=>'not tested'];
            try {
                $qtest = stooq_quotes_batch(['AAPL'], $config);
                $external = ['ok'=>!empty($qtest), 'message'=>!empty($qtest) ? 'Yahoo Finance reachable' : 'Yahoo Finance returned empty data'];
            } catch(Throwable $e) {
                $external = ['ok'=>false, 'message'=>$e->getMessage()];
            }
            json_response([
                'ok'=>true,
                'php'=>PHP_VERSION,
                'api'=>'api.php is reachable',
                'external'=>$external,
                'universeCount'=>count(universe()),
                'cacheWritable'=>is_writable(__DIR__ . '/cache') || @mkdir(__DIR__ . '/cache',0755,true),
            ]);
        case 'screener':
            $sector = strtolower(clean(q('sector',''), 80));
            $strategy = strtolower(clean(q('strategy','balanced'), 40));
            $region = strtolower(clean(q('region','all'), 10));
            $sort = strtolower(clean(q('sort','score'), 20));
            $minYield = (float)q('minYield', 0);
            $limit = max(5, min((int)($config['max_scan_limit'] ?? 80), (int)q('limit', 30)));
            $minPrice = (float)q('minPrice', 1);
            $candidates = [];
            foreach (universe() as $r) {
                $isRealEstate = strtolower($r['sector']) === 'real estate' || stripos($r['industry'] ?? '', 'real estate') !== false;
                if ($sector !== '' && $sector !== 'all' && strtolower($r['sector']) !== $sector) continue;
                if ($strategy === 'realestate' && !$isRealEstate) continue;
                if ($region === 'us' && region_of($r) !== 'US') continue;
                if ($region === 'eu' && region_of($r) !== 'EU') continue;
                $candidates[] = $r;
            }
            $maxCandidates = max($limit * 4, 80);
            $candidates = array_slice($candidates, 0, min($maxCandidates, 240));
            $symbols = array_map(fn($r)=>$r['symbol'], $candidates);
            $quotes = stooq_quotes_batch($symbols, $config);
            $rows = [];
            foreach ($candidates as $r) {
                $sym = strtoupper($r['symbol']);
                if (empty($quotes[$sym])) continue;
                $quote = $quotes[$sym];
                if (($quote['price'] ?? 0) < $minPrice) continue;
                $score = quick_scan_score($quote, $r, $strategy);
                $rows[] = array_merge($quote, ['score'=>$score, 'technicals'=>['confidence'=>60], 'fastScan'=>true]);
            }
            // Pick a pool by the fast score, then FULL-SCORE it (same score the company detail uses),
            // so the scan never contradicts the detail. dividendYield comes from full scoring too.
            usort($rows, fn($a,$b)=>($b['score']['final'] ?? 0) <=> ($a['score']['final'] ?? 0));
            $pool = array_slice($rows, 0, min(max($limit * 2, 20), 50));
            $pool = full_score_pool($pool, $config, $strategy);
            if ($minYield > 0) $pool = array_values(array_filter($pool, fn($r)=>($r['dividendYield'] ?? 0) >= $minYield));
            $cmp = [
                'yield' => fn($a,$b)=>($b['dividendYield'] ?? -1) <=> ($a['dividendYield'] ?? -1),
                'low52' => fn($a,$b)=>($a['position52w'] ?? 999) <=> ($b['position52w'] ?? 999),
                'high52' => fn($a,$b)=>($b['position52w'] ?? -1) <=> ($a['position52w'] ?? -1),
            ][$sort] ?? fn($a,$b)=>($b['score']['final'] ?? 0) <=> ($a['score']['final'] ?? 0);
            usort($pool, $cmp);
            $rows = array_slice($pool, 0, $limit);
            json_response(['data'=>$rows, 'strategy'=>$strategy, 'sort'=>$sort, 'source'=>'Yahoo Finance + SEC (scor complet)', 'mode'=>'full-score-scan', 'scanned'=>count($candidates)]);
        case 'benchmark':
            $symbol = strtoupper(clean(q('symbol',''), 30));
            if (!$symbol) json_response(['error'=>'Missing symbol'], 400);
            $meta = find_universe($symbol);
            if (!$meta) json_response(['data'=>['available'=>false, 'reason'=>'Simbol necunoscut']]);
            $sector = strtolower($meta['sector'] ?? '');
            $peers = [];
            foreach (universe() as $r) {
                if (strtolower($r['sector']) !== $sector || $sector === '') continue;
                if (region_of($r) !== 'US' || empty($r['cik'])) continue;
                $peers[] = strtoupper($r['symbol']);
            }
            if (count($peers) < 3) json_response(['data'=>['available'=>false, 'sector'=>$meta['sector'] ?? '', 'reason'=>'Prea puține companii comparabile cu fundamente SEC în acest sector']]);
            $peers = array_slice($peers, 0, 22);
            $quotes = stooq_quotes_batch($peers, $config);
            // Fetch all peers' SEC fundamentals in parallel (gzip + curl_multi)
            $ua = trim($config['sec_user_agent'] ?? 'InvestIQFreeLive2026 contact@example.com');
            $reqs = []; $surlOf = [];
            foreach ($peers as $sym) {
                $pm = find_universe($sym);
                $cik = str_pad(preg_replace('/\D/', '', $pm['cik']), 10, '0', STR_PAD_LEFT);
                $surl = 'https://data.sec.gov/api/xbrl/companyfacts/CIK' . $cik . '.json';
                $surlOf[$sym] = $surl;
                $reqs[] = ['url'=>$surl, 'headers'=>['Accept: application/json', 'User-Agent: ' . $ua], 'cache'=>(int)($config['cache_seconds_sec'] ?? 86400)];
            }
            $bodies = http_get_multi($reqs);
            $rows = [];
            foreach ($peers as $sym) {
                if (empty($quotes[$sym])) continue;
                $price = $quotes[$sym]['price'] ?? null;
                $f = sec_fundamentals($sym, $config, $bodies[$surlOf[$sym]] ?? null);
                if (empty($f['available'])) continue;
                $shares = $f['sharesOutstanding'] ?? null;
                $mcap = ($shares && $price) ? $shares * $price : null;
                $rows[] = [
                    'pe' => ($mcap && ($f['netIncome'] ?? 0) > 0) ? $mcap / $f['netIncome'] : null,
                    'pb' => ($mcap && ($f['equity'] ?? 0) > 0) ? $mcap / $f['equity'] : null,
                    'margin' => $f['profitMargin'] ?? null,
                    'roe' => $f['roe'] ?? null,
                ];
            }
            $median = function($vals) {
                $a = array_values(array_filter($vals, fn($x) => $x !== null && is_finite($x)));
                sort($a); $n = count($a);
                if (!$n) return null;
                return $n % 2 ? $a[intdiv($n,2)] : ($a[$n/2 - 1] + $a[$n/2]) / 2;
            };
            json_response(['data'=>[
                'available' => count($rows) >= 3,
                'sector' => $meta['sector'] ?? '',
                'count' => count($rows),
                'median' => [
                    'pe' => $median(array_column($rows,'pe')),
                    'pb' => $median(array_column($rows,'pb')),
                    'margin' => $median(array_column($rows,'margin')),
                    'roe' => $median(array_column($rows,'roe')),
                ],
            ]]);
        case 'ai':
            // Sends the company's financial data to Ollama and returns its opinion (server-side call avoids mixed-content/CORS).
            $raw = file_get_contents('php://input');
            $payload = json_decode($raw, true);
            if (!is_array($payload)) json_response(['error'=>'Body JSON invalid sau gol'], 400);
            $prompt = build_ai_prompt($payload);
            $url = $config['ollama_url'] ?? '';
            if (!$url) json_response(['error'=>'Ollama nu este configurat'], 503);
            $req = [
                'model'    => $config['ollama_model'] ?? 'llama3.2',
                'message'  => $prompt,                                   // custom-wrapper contract
                'messages' => [['role'=>'user', 'content'=>$prompt]],    // native Ollama contract
                'stream'   => false,
            ];
            try {
                $body = http_post_json($url, $req, (int)($config['ollama_timeout'] ?? 60));
            } catch (Throwable $e) {
                $code = (int)$e->getCode();
                $msg = ($code === 502 || $code === 503 || $code === 504 || $code === 0)
                    ? 'Serviciul AI nu a răspuns la timp — serverul Ollama e momentan lent sau oprit. Încearcă din nou peste un minut.'
                    : 'Nu pot contacta serviciul AI.';
                json_response(['error'=>$msg, 'detail'=>$e->getMessage()], 502);
            }
            $reply = extract_ai_reply($body);
            if ($reply === '') json_response(['error'=>'Serviciul AI a răspuns gol', 'detail'=>substr($body,0,200)], 502);
            json_response(['reply'=>$reply, 'model'=>$config['ollama_model'] ?? null]);
        default:
            json_response(['error'=>'Unknown action','action'=>$action],404);
    }
} catch(Throwable $e) {
    json_response(['error'=>'Server error','detail'=>$e->getMessage()], 500);
}
