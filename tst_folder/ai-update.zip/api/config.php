<?php
/**
 * InvestIQ Free Live 2026 configuration
 * No paid API key required.
 * SEC requests require a User-Agent that identifies your app/contact.
 */
return [
    'cache_seconds_quote' => 60,
    'cache_seconds_history' => 900,
    'cache_seconds_sec' => 86400,
    'cache_seconds_yahoo' => 300,
    'max_scan_limit' => 80,
    'sec_user_agent' => 'InvestIQFreeLive2026 contact@example.com',
    'enable_yahoo_fallback' => true,
    // Ollama AI opinion endpoint (called server-side so the HTTPS page can reach an http:// host without mixed-content/CORS issues).
    'ollama_url' => 'https://ollama.andivio.com/api/chat',
    'ollama_model' => 'llama3.2',
    'ollama_timeout' => 60,
];
